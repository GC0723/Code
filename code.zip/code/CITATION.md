# Citation

**Before public release, replace every angle-bracket placeholder with the study's real metadata. Remove any entry that is not applicable.**

## Cite the associated paper

```bibtex
@article{<PAPER_CITATION_KEY>,
  title   = {<PAPER_TITLE>},
  author  = {<COMPLETE_AUTHOR_LIST>},
  journal = {<JOURNAL_NAME>},
  year    = {<PUBLICATION_YEAR>},
  volume  = {<VOLUME>},
  number  = {<ISSUE>},
  pages   = {<PAGES_OR_ARTICLE_NUMBER>},
  doi     = {<PAPER_DOI>}
}
```

## Cite this software release

```bibtex
@software{<SOFTWARE_CITATION_KEY>,
  title        = {LLM-assisted literature extraction and validation pipeline},
  author       = {<COMPLETE_AUTHOR_LIST>},
  year         = {2026},
  version      = {2.0},
  doi          = {<REPOSITORY_OR_ZENODO_DOI>},
  url          = {<PUBLIC_REPOSITORY_URL>},
  license      = {MIT}
}
```

If the journal provides its own software-citation format, use that format and include the same paper DOI, repository URL, release version, and archive DOI. Do not cite an unversioned development branch when a fixed release is available.
