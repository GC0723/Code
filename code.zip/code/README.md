# LLM-assisted literature extraction and validation pipeline

Release 2.0 · Python 3.10+ · MIT License

[中文复现指南](docs/中文复现指南.md) · [Input/output schema](docs/DATA_SCHEMA.md) · [Publication checklist](docs/PUBLICATION_CHECKLIST.md) · [Verification](docs/VALIDATION.md) · [Citation](CITATION.md)

## Overview

This repository contains the code used to screen ecosystem services valuation (ESV) literature, extract structured variables from titles and abstracts, normalize place names, geocode study areas and author affiliations, compute author–study-area distances, and validate automatic coding against independently annotated full texts.

The release includes:

- a nine-step main pipeline (`step0` to `step8`);
- eight versioned prompts and JSON Schemas in `llm_prompts.py`;
- a full-text sampling, adjudication, and validation workflow (`stepFT1` to `stepFT3`);
- complete prompt catalogues with SHA1 fingerprints;
- three offline test suites covering configuration, data flow, HTTP behavior, resumability, and validation metrics.

**No bibliographic records, full-text PDFs, annotations, API credentials, or generated research results are included.** The release is anonymized: it contains no personal names, contact details, local usernames, or machine-specific paths. Test fixtures use generic labels such as `Author A`. Users must supply their own lawfully obtained data and LLM credentials.

## Workflow

```text
WoS-compatible metadata: data/all.xlsx
        |
        v
Step 0: relevance screening
        |-- results/0_Relevance_out.xlsx  (all records; audit trail)
        `-- results/0_Corpus_ESV.xlsx     (analytical corpus)
                    |
          +---------+--------------------+
          |                              |
          v                              v
Step 1: study-area extraction     Step 2: affiliation normalization
          |                              |
Step 3: place-name normalization         |
          |                              |
Step 4: ecosystem classification         |
          |                              |
Step 5: ecosystem-service classification |
          |                              |
Step 6: theory/practice orientation      |
          |                              |
          +--------------+---------------+
                         v
Step 7: GIS geocoding; Step 2 results are joined by paper ID when needed
                         |
                         v
Step 8: author–study-area distance

Full-text validation:
Step FT1 sampling/blinding -> independent human annotation -> gold standard
Step FT2 LLM full-text adjudication (audit only)
Step FT3 precision/recall/F1/kappa/bootstrap confidence intervals
```

Steps 1–6 and FT2 call an LLM. Steps 7–8, FT1, FT3, and all supplied tests can run without LLM API calls. Step 7 is fully offline with `--provider none` or `--provider gazetteer`.

## Repository layout

```text
.
├── llm_prompts.py                       Prompt registry, taxonomies, JSON Schemas
├── llm_utils.py                         Configuration, API client, table I/O, audit tools
├── llm_pipeline.py                      Batch processing, retries, checkpoints, concurrency
├── pdf_text.py                          PDF text-extraction backends
├── step0.* … step8.*                    Main pipeline
├── stepFT1.* … stepFT3.*                Full-text validation workflow
├── stepA1.prompt_catalog_export.py      Prompt-archive exporter
├── stepT1.*, stepT2.*, stepT3.*         Offline tests
├── prompt_catalog.md/json              Prompt versions and fingerprints
├── prompt_catalog_full.md              Complete prompt text for supplementary material
├── data/                               User-supplied input data (not distributed)
├── results/                            Generated outputs (not distributed)
└── docs/                               Reproduction and publication documentation
```

Script names containing dots are intentional. Run them as files, for example `python step0.relevance_screening.py`; do not import them as ordinary Python package modules.

## Installation

### 1. Create an environment

```bash
python -m venv .venv
source .venv/bin/activate          # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Python 3.10 or later is required. For optional PDF, geodesic, and online-geocoding support:

```bash
python -m pip install -r requirements-optional.txt
```

PDF extraction can also use the external `pdftotext` executable from Poppler. The code automatically tries `pdftotext`, PyMuPDF, pypdf, and pdfminer.

### 2. Configure the run

```bash
cp .env.example .env               # Windows: copy .env.example .env
```

Edit `.env`:

1. set `LLM_PROVIDER` and the corresponding API key;
2. place the input table at `data/all.xlsx`, or change `PATH_INPUT_CORPUS`;
3. keep `LLM_TEMPERATURE=0` for the reported workflow;
4. keep `GEOCODER=none` for offline geocoding, or configure an identifiable Nominatim user agent and email.

Environment variables take precedence over `.env`. Run commands from the repository root so relative paths resolve consistently. `.env` is excluded by `.gitignore`; never publish credentials.

### 3. Verify the installation before spending API credits

```bash
python stepT3.smoke_test.py
python stepT2.integration_test.py
python stepT1.mock_llm_pipeline_test.py
```

All three suites are offline. The mock test starts a local HTTP server and does not contact an LLM provider. Temporary test fixtures are removed automatically unless `--keep` is supplied where supported.

## Input data

The default input is an Excel workbook at `data/all.xlsx`. CSV is also supported by the table reader. The recommended columns are:

| Column | Requirement | Purpose |
|---|---|---|
| `UT` | Strongly recommended; alternatively DOI or another unique ID | Record linkage, resume auditing, Step 2/7 merge |
| `Article Title` or `Title` | Recommended | Relevance and classification context |
| `Abstract` | Required for abstract-based steps | Main LLM input |
| `Addresses` | Required for affiliation/distance analysis | WoS author-address text |
| `Affiliations` | Recommended | Additional affiliation text |

The ID must be non-empty and unique in each table used for the Step 2/7 merge. See [DATA_SCHEMA.md](docs/DATA_SCHEMA.md) for accepted aliases and output fields.

## Running the main pipeline

With the paths in `.env.example`, run:

```bash
python step0.relevance_screening.py
python step1.study_area_extraction.py
python step2.affiliation_geolocation_llm.py
python step3.study_area_normalization.py
python step4.ecosystem_classification.py
python step5.esv_service_classification.py
python step6.theory_practice_orientation.py

# Use the Step 6 table as the main table and join the parallel Step 2 output.
python step7.gis_geocoding.py \
  --input results/6_Orientation_out.xlsx \
  --affiliation-input results/2_Affiliations_out.xlsx \
  --provider none

python step8.author_studyarea_distance.py
```

Step 7 also attempts the configured Step 2 output automatically when the main table lacks `affil_*` columns. An explicit `--affiliation-input` is recommended in archived commands because it makes the data lineage clear.

To regenerate the prompt archive after any intentional prompt change:

```bash
python stepA1.prompt_catalog_export.py --full
```

### Common options

Most pipeline scripts support:

| Option | Meaning |
|---|---|
| `--input PATH`, `--output PATH` | Override configured table paths |
| `--limit N` | Process at most N records |
| `--sample N --seed S` | Reproducible random row sample |
| `--workers N` | Concurrent API workers; default 1 is easiest to audit |
| `--force` | Reprocess completed rows and incur new API charges |
| `--dry-run` | Validate input and columns without LLM calls |

Use `python SCRIPT --help` for script-specific options. When resuming, completed rows are skipped and failed rows marked `__FAILED__` are retried. Do not change the prompt, model, input table, or row order midway through a run unless you intentionally start a new output dataset.

## Full-text validation

```bash
# 1. Build a blinded annotation sample; choose n for the study design.
python stepFT1.fulltext_sample_builder.py \
  --input results/6_Orientation_out.xlsx \
  --n 412 --stratify orientation_primary --blind \
  --pdf-dir data/fulltext --check-pdfs

# 2. Complete independent human annotation and adjudication outside the pipeline.
#    Save the resulting gold standard as results/FT_2_gold_standard.xlsx.

# 3. Compare abstract-based predictions with the human gold standard.
python stepFT3.validation_metrics.py \
  --pred results/6_Orientation_out.xlsx \
  --gold results/FT_2_gold_standard.xlsx \
  --id-col UT

# 4. Optional: independent LLM full-text review for disagreement auditing.
python stepFT2.fulltext_adjudication.py \
  --input results/FT_2_gold_standard.xlsx \
  --variables ORIENTATION,ECOSYSTEM,STUDY_AREA
```

The number 412 is only the default inherited from the original study design, not a methodological requirement. The gold standard must be produced by human annotation; LLM output must not be used as its substitute. Model-reported `confidence` is an audit field, not an estimate of accuracy.

## Outputs and audit files

| File | Contents |
|---|---|
| `results/0_Relevance_out.xlsx` | All screened records and exclusion/audit labels |
| `results/0_Corpus_ESV.xlsx` | Records passing the ESV inclusion rule; common downstream corpus |
| `results/1_abstract_out.xlsx` … `6_Orientation_out.xlsx` | Successive structured coding tables |
| `results/7_Geocoded.xlsx` | WGS84 coordinates, precision levels, and coordinate sources |
| `results/8_Distance_out.xlsx` | Distances, log distances, validity, and cross-country flags |
| `results/9_Validation_Metrics.xlsx/.txt` | Validation metrics, confusion matrices, and English summary |
| `run_manifest.csv` | Script, model, temperature, prompt/schema versions, row and API-call counts |
| `results/_checkpoints/` | Resumability checkpoints |
| `results/geocode_cache.csv` | Geocoding cache keyed by normalized place text and hints |

Every LLM coding stage writes evidence, model, prompt-version, and timestamp fields where applicable. Coordinates are produced only by the GIS layer, never by the LLM.

## Reproducibility and limitations

- Temperature is fixed at 0 by default, and prompts/schemas are fingerprinted. Provider-side model updates, infrastructure, and fallback behavior can still change outputs; archive the exact model identifier, run manifest, prompt catalogue, raw outputs, and software environment used for the paper.
- JSON Schema is requested when available. The client may fall back to JSON-object mode or strict parsing after provider errors; inspect logs and the run manifest.
- `UNKNOWN` and `UNCERTAIN` are explicit outcomes and must be reported rather than silently discarded.
- Ecosystem/service subtypes are exploratory unless separately validated. PTR sensitivity bounds treat uncertain orientation cases as all-theory or all-practice extremes.
- Offline gazetteer matches are only as good as the supplied place table. Country-centroid distance fallback is for sensitivity analysis only.
- Nominatim use must comply with its current usage policy. The code throttles requests but does not replace the user's obligation to configure identification and review terms.
- This package releases code, not copyrighted source literature or full texts.

## Documentation for public archiving

Before uploading to a repository or journal supplement, complete [CITATION.md](CITATION.md), add the paper DOI/repository DOI, and follow [PUBLICATION_CHECKLIST.md](docs/PUBLICATION_CHECKLIST.md). Archive the prompt files together with the code version used for the reported analysis.

## License and citation

Code is released under the [MIT License](LICENSE). Third-party data, APIs, and PDF content remain subject to their own terms. See [CITATION.md](CITATION.md) for citation templates.
