# Input data directory

Place user-supplied input files here. This directory is intentionally empty in the public release.

- Default corpus: `all.xlsx`
- Optional full texts: `fulltext/`
- Required and accepted columns: see `docs/DATA_SCHEMA.md`

Do not redistribute proprietary bibliographic exports, copyrighted PDFs, or private annotations unless you have permission to do so. The `.gitignore` excludes files in this directory except this README.
