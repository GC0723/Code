# Release verification

Verification date: 2026-10-28  
Environment: Linux, Python 3.12

The public-release files were copied to a separate clean directory before verification. The following checks passed:

| Check | Result | Scope |
|---|---|---|
| Python syntax compilation | Pass | All 20 Python files |
| `stepT3.smoke_test.py` | Pass | Dependencies, settings, prompts, schemas, dry-runs, metrics, PDF backends |
| `stepT2.integration_test.py` | Pass | End-to-end offline fixtures, Step 2/7 ID merge, geocoding, distance, validation, blinded sample |
| `stepT1.mock_llm_pipeline_test.py` | Pass | Local mock HTTP service, schema fallback, parsing, retry/resume, concurrency, manifest/checkpoint |
| Markdown local-link check | Pass | All repository-local documentation links resolve |
| Credential/path review | Pass | No real API credential or machine-specific absolute path found |

No live LLM provider was contacted and no API credits were consumed during these tests. The tests do not validate the scientific correctness of model labels on the study corpus; that requires the independently annotated human gold standard described in the README.

Before citing the software in the paper, rerun the same checks on the exact archived release and record the actual research-run environment separately. See `PUBLICATION_CHECKLIST.md`.
