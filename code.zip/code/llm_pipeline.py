# -*- coding: utf-8 -*-
"""
llm_pipeline.py —— 各步骤脚本共用的“批处理骨架”

把每个步骤脚本都需要重复实现的逻辑集中到这里：

    - 读取输入表 / 备份原文件 / 写入输出表（含断点续跑）
    - 逐行调用 LLM，写入 label + subtype + evidence + confidence + model + prompt_version
    - 失败行单独标记，可 --force 或直接重跑续接
    - 可选多线程（默认串行，1 行 1 次调用，可审计）
    - dry-run：只检查输入列，不消耗 API 额度
    - 进度条（tqdm）

每个步骤脚本只需要提供：
    stage_key            步骤标识（用于 checkpoint 文件名）
    columns              需要写入的列名
    row_handler(df, i, ...) -> dict   单行处理逻辑
"""

from __future__ import annotations

import json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

import pandas as pd
from tqdm import tqdm

from llm_utils import (
    LLMClient,
    RunManifest,
    Settings,
    backup_file,
    checkpoint_path,
    is_blank,
    load_settings,
    read_table,
    safe_cell,
    select_rows,
    write_table,
)

__all__ = ["StageResult", "run_stage", "write_checkpoint", "read_checkpoint"]

FAILED_SENTINEL = "__FAILED__"


@dataclass
class StageResult:
    rows_total: int = 0
    rows_ok: int = 0
    rows_failed: int = 0
    rows_skipped: int = 0
    rows_blank: int = 0
    output_path: str = ""
    backup_path: str = ""
    manifest_path: str = ""
    errors: List[str] = field(default_factory=list)


def write_checkpoint(path: Path, records: Dict[int, Dict[str, Any]]) -> None:
    """把 {行索引: {列: 值}} 写到 CSV，用于断点续跑。"""
    if not records:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        rows = []
        for idx, values in records.items():
            row = {"_row_index": idx}
            row.update({k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v) for k, v in values.items()})
            rows.append(row)
        pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")
    except Exception:
        pass


def read_checkpoint(path: Path) -> Dict[int, Dict[str, Any]]:
    if not path.exists():
        return {}
    try:
        df = pd.read_csv(path)
    except Exception:
        return {}
    if "_row_index" not in df.columns:
        return {}
    out: Dict[int, Dict[str, Any]] = {}
    for _, row in df.iterrows():
        try:
            idx = int(row["_row_index"])
        except Exception:
            continue
        values: Dict[str, Any] = {}
        for col in df.columns:
            if col == "_row_index":
                continue
            val = row[col]
            if isinstance(val, str) and val.startswith(("[", "{")):
                try:
                    val = json.loads(val)
                except Exception:
                    pass
            values[col] = val
        out[idx] = values
    return out


def _apply(df: pd.DataFrame, idx: int, values: Dict[str, Any]) -> None:
    """
    写入单行结果。

    注意：pandas 3.x 对 dtype 校验更严格（把 bool 写进 str 列会直接抛
    TypeError），而各步骤的列既有字符串枚举、也有布尔标记。这里统一做
    dtype 兼容处理：类型不兼容时把该列提升为 object dtype，保证写入成功。
    """
    for col, val in values.items():
        try:
            df.at[idx, col] = val
        except (TypeError, ValueError):
            if col not in df.columns:
                raise
            try:
                df[col] = df[col].astype(object)
                df.at[idx, col] = val
            except Exception:
                merged = df[col].astype(object).copy()
                merged.at[idx] = val
                df[col] = merged


def _row_is_done(df: pd.DataFrame, idx: int, label_col: str) -> bool:
    """
    已处理过的行在续跑时跳过。
    注意：只要判定列非空（含 __FAILED__ 与旧版本写入值）即视为已处理，
    这样可以避免重跑整个语料时重复消耗 API 额度；需要重算请用 --force。
    """
    return safe_cell(df.at[idx, label_col], "") != ""


def run_stage(
    *,
    stage_key: str,
    script_name: str,
    in_path: Path,
    out_path: Path,
    columns: Sequence[str],
    row_handler: Callable[[pd.DataFrame, int], Dict[str, Any]],
    label_column: str,
    settings: Optional[Settings] = None,
    prompt_version: str = "",
    schema_version: str = "",
    args: Any = None,
    desc: str = "",
    client: Optional[LLMClient] = None,
) -> StageResult:
    """
    执行一个 LLM 批处理步骤。

    参数
    ----
    row_handler : 接收 (DataFrame, 行号)，返回 {列名: 值}；回调内部自行调用 LLM。
                  返回值中的 label_column 决定成功/失败：
                    - 非空且不是 __FAILED__  -> 成功
                    - 空或 __FAILED__        -> 失败（可重跑）
    label_column: 判定“是否处理完成”的列
    """
    s = settings or load_settings()
    res = StageResult(output_path=str(out_path))

    df = read_table(in_path)
    res.rows_total = len(df)

    # 列检测（缺失则建空列，绝不覆盖已有同名列以外的数据）
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    if label_column not in df.columns:
        df[label_column] = ""

    if getattr(args, "dry_run", False):
        res.manifest_path = ""
        print(f"[dry-run] 输入: {in_path}  行数: {len(df)}")
        print(f"[dry-run] 将写入列: {list(columns)}")
        print(f"[dry-run] 判定列: {label_column}")
        return res

    if not s.has_api_key:
        raise SystemExit(
            "未找到 API Key。请复制 .env.example 为 .env 并填写 DEEPSEEK_API_KEY（或设置环境变量）。"
        )

    targets = set(select_rows(df, args)) if args is not None else set(range(len(df)))
    force = bool(getattr(args, "force", False))
    workers = max(1, int(getattr(args, "workers", 1) or 1))

    done_count = 0
    pending: List[int] = []
    for idx in range(len(df)):
        if idx not in targets:
            res.rows_skipped += 1
            continue
        if not force and _row_is_done(df, idx, label_column):
            done_count += 1
            continue
        pending.append(idx)

    if len(targets) < len(df):
        res.rows_skipped += len(df) - len(targets)

    ckpt_file = checkpoint_path(s, stage_key)
    records = read_checkpoint(ckpt_file)
    if records and not force:
        for idx, values in list(records.items()):
            if idx in df.index:
                _apply(df, idx, values)
        pending = [i for i in pending if i not in records]

    bar = tqdm(total=len(pending), desc=desc or stage_key, unit="row")
    lock = threading.Lock()

    def _work(idx: int) -> Dict[str, Any]:
        try:
            return row_handler(df, idx) or {}
        except Exception as exc:  # 单行失败不影响整批
            return {label_column: FAILED_SENTINEL, "__error__": f"{type(exc).__name__}: {exc}"}

    try:
        if workers == 1:
            for idx in pending:
                values = _work(idx)
                if "__error__" in values:
                    res.errors.append(f"row {idx}: {values.pop('__error__')}")
                _apply(df, idx, values)
                records[idx] = values
                _tally(res, values, label_column)
                bar.update(1)
                if len(records) % s.save_every == 0:
                    write_table(df, out_path)
                    write_checkpoint(ckpt_file, records)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(_work, idx): idx for idx in pending}
                for fut in as_completed(futures):
                    idx = futures[fut]
                    values = fut.result()
                    if "__error__" in values:
                        res.errors.append(f"row {idx}: {values.pop('__error__')}")
                    with lock:
                        _apply(df, idx, values)
                        records[idx] = values
                        _tally(res, values, label_column)
                        bar.update(1)
                        if len(records) % s.save_every == 0:
                            try:
                                write_table(df, out_path)
                                write_checkpoint(ckpt_file, records)
                            except Exception:
                                pass
    finally:
        bar.close()

    res.backup_path = str(backup_file(out_path) or "")
    write_table(df, out_path)
    write_checkpoint(ckpt_file, records)

    manifest = RunManifest(script_name, prompt_version=prompt_version, schema_version=schema_version, settings=s)
    manifest.rows_total = res.rows_total
    manifest.rows_ok = res.rows_ok + done_count
    manifest.rows_failed = res.rows_failed
    manifest.rows_skipped = res.rows_skipped + done_count
    if client is not None:
        manifest.api_calls = client.calls
        manifest.api_failures = client.failures
    res.manifest_path = str(manifest.append() or "")

    print(
        f"[{stage_key}] 完成: 成功 {res.rows_ok} / 失败 {res.rows_failed} / "
        f"本轮跳过(已完成) {done_count} / 输出 {out_path}"
    )
    if res.errors:
        print(f"[{stage_key}] 最近错误示例: {res.errors[-1]}")
    return res


def _tally(res: StageResult, values: Dict[str, Any], label_column: str) -> None:
    val = safe_cell(values.get(label_column, ""), "")
    if val and val != FAILED_SENTINEL:
        res.rows_ok += 1
    else:
        res.rows_failed += 1
