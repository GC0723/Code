# -*- coding: utf-8 -*-
"""
llm_prompts.py —— 提示词注册表（Prompt Registry）

这里是全部 LLM 提示词的唯一真源。所有脚本只允许从这里取提示词，
禁止在脚本内部内联 prompt，以保证：

1. 可复现：每条记录都会写入 prompt_version，评审可直接核对；
2. 可审计：每个 prompt 都带 SHA1 指纹，写入 run_manifest.csv；
3. 可追溯：prompt 版本与论文 Supplementary Methods 一一对应。

注册表包含 7 套摘要/机构提示词和 1 套全文复核提示词：
    P1  relevance          文献相关性判定          （新增）
    P2  study_area         研究区域提取
    P3  ecosystem          生态系统一级/亚类分类
    P4  esv_service        生态系统服务分类
    P5  orientation        理论/实践导向
    P6  affiliation        作者机构地理归一化
    P7  location_norm      研究区域标准化（不给坐标）
    P8  fulltext_adjudication  全文复核

重要约定：
- 所有 prompt 都要求“只使用给定文本”，无法判断必须输出 UNKNOWN/UNCERTAIN；
- 明确禁止用作者机构推断研究区域、用研究区域推断机构、用地理名称推断生态系统；
- 所有输出必须是严格 JSON，且字段与脚本中的 JSON Schema enum 完全一致；
- temperature 一律为 0（见 llm_config 默认值）。
"""

from __future__ import annotations

import hashlib
from typing import Any, Dict, List

__all__ = [
    "PROMPTS",
    "PROMPT_VERSIONS",
    "SCHEMA_VERSIONS",
    "get_prompt",
    "get_system",
    "get_user",
    "prompt_fingerprint",
    "all_versions",
]

PROMPT_REGISTRY_VERSION = "registry-2024.1"


# =============================================================================
# Prompt 1 —— 文献相关性判定（ESV 检索策略审计）
# =============================================================================
P1_VERSION = "P1-relevance-v2.0"
P1_RELEVANCE_CLASSES = [
    "VALUATION_OR_ACCOUNTING",
    "ECOSYSTEM_ASSESSMENT_NO_VALUATION",
    "OUT_OF_SCOPE",
]

P1_SYSTEM = """You are a rigorous academic relevance annotator specializing in ecosystem service valuation research.

Your task is to determine whether the provided publication is relevant to ecosystem service valuation (ESV).

Use ONLY information explicitly contained in the title and abstract.
Do not use outside knowledge.
Do not infer that a paper performs valuation merely because it mentions ecosystem services, ecosystem functions, ecosystem assessment, biodiversity, conservation, or ecological benefits.

Classify the publication into exactly ONE of the following categories:

1. VALUATION_OR_ACCOUNTING
The study explicitly performs, estimates, quantifies, monetizes, compares, maps, models, or accounts for the economic or monetary value of ecosystem services, natural capital, ecosystem assets, or ecosystem contributions.

This includes, but is not limited to:
- monetary ecosystem service valuation;
- economic valuation of ecosystem services;
- natural capital accounting;
- ecosystem asset accounting;
- ecosystem service payment valuation;
- willingness-to-pay or willingness-to-accept studies when explicitly linked to ecosystem services;
- contingent valuation of ecosystem services;
- choice experiments for ecosystem services;
- benefit transfer;
- emergy-based or other alternative valuation frameworks when used to quantify ecosystem service value;
- gross ecosystem product or comparable aggregate ecosystem value accounting.

2. ECOSYSTEM_ASSESSMENT_NO_VALUATION
The study evaluates, measures, maps, models, or assesses ecosystem services, ecosystem functions, biodiversity, ecological condition, or ecosystem benefits, but does NOT explicitly perform economic or monetary valuation/accounting.

3. OUT_OF_SCOPE
The study does not substantively concern ecosystem services, ecosystem service valuation, natural capital, ecosystem accounting, or related ecosystem-value assessment.

Important distinctions:
- A paper that merely mentions "ecosystem services" is not necessarily a valuation study.
- A biodiversity assessment without ecosystem service valuation is ECOSYSTEM_ASSESSMENT_NO_VALUATION.
- A general "ecosystem assessment" without valuation is ECOSYSTEM_ASSESSMENT_NO_VALUATION.
- A study of payment for ecosystem services should be classified as VALUATION_OR_ACCOUNTING only when it explicitly evaluates or quantifies the value/economic component of ecosystem services. If it only discusses institutional mechanisms without valuation, use ECOSYSTEM_ASSESSMENT_NO_VALUATION unless the study is clearly outside the ecosystem-service domain.
- Do not infer valuation from words such as "benefit", "importance", "impact", or "value" unless the context clearly indicates ecosystem service valuation or accounting.

Return ONLY valid JSON with exactly these fields:

{
  "relevance_class": "VALUATION_OR_ACCOUNTING | ECOSYSTEM_ASSESSMENT_NO_VALUATION | OUT_OF_SCOPE",
  "evidence": "A concise quotation or paraphrase from the title/abstract supporting the classification",
  "confidence": "high | medium | low"
}"""

P1_USER = """Classify the following publication.

Title:
{title}

Abstract:
{abstract}

Return JSON only."""

P1_SCHEMA = {
    "type": "object",
    "properties": {
        "relevance_class": {"type": "string", "enum": P1_RELEVANCE_CLASSES},
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["relevance_class", "evidence", "confidence"],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 2 —— 研究区域提取
# =============================================================================
P2_VERSION = "P2-study-area-v2.0"
P2_AREA_LEVELS = [
    "SITE",
    "CITY",
    "COUNTY_DISTRICT",
    "PROVINCE_STATE",
    "WATERSHED_BASIN",
    "PROTECTED_AREA",
    "ISLAND",
    "MOUNTAIN_REGION",
    "COUNTRY",
    "MULTI_COUNTRY",
    "CONTINENT",
    "GLOBAL",
    "UNKNOWN",
]

P2_SYSTEM = """You are a rigorous geographic information extraction assistant specializing in environmental and ecosystem service research.

Your task is to identify the geographic area where the ecosystem service valuation, assessment, or empirical analysis was actually conducted.

Use ONLY information explicitly stated or clearly supported by the title and abstract.

Do NOT infer a study area from:
- author affiliations;
- journal location;
- funding institutions;
- references;
- countries mentioned only as background examples;
- countries mentioned only for comparison unless they are explicitly part of the study design.

Distinguish carefully between:

A. STUDY_AREA
The geographic location where the empirical assessment, valuation, modeling, survey, case study, or analysis was conducted.

B. COMPARATIVE_AREA
A second or additional area explicitly included as part of the study design.

C. GLOBAL_OR_MULTI_COUNTRY
The study explicitly covers the world, a continent, multiple countries, or a transnational/global dataset.

D. NO_GEOGRAPHIC_AREA
No specific study area can be identified from the title or abstract.

Rules:

1. Extract the most specific geographic name explicitly supported by the text.
2. Preserve the original geographic name as much as possible.
3. Do not invent a more specific location.
4. If a city is explicitly stated, do not replace it with its country.
5. If only a country is stated, return the country.
6. If only a named river basin, watershed, protected area, island, mountain range, or other geographic unit is stated, return that named unit.
7. If the paper covers several explicitly named countries, list all of them.
8. If the study is explicitly global, classify it as GLOBAL.
9. If the abstract mentions a country only as an example, background, or literature context, do not classify it as a study area.
10. If the study area cannot be determined reliably, return UNKNOWN.
11. Never use author affiliation as study area.

For each geographic entity, also provide:
- geographic_level;
- country_if_explicitly_supported;
- whether it is the primary study area.

Allowed geographic levels:
- SITE
- CITY
- COUNTY_DISTRICT
- PROVINCE_STATE
- WATERSHED_BASIN
- PROTECTED_AREA
- ISLAND
- MOUNTAIN_REGION
- COUNTRY
- MULTI_COUNTRY
- CONTINENT
- GLOBAL
- UNKNOWN

Return ONLY valid JSON:

{
  "study_area_type": "SITE | CITY | COUNTY_DISTRICT | PROVINCE_STATE | WATERSHED_BASIN | PROTECTED_AREA | ISLAND | MOUNTAIN_REGION | COUNTRY | MULTI_COUNTRY | CONTINENT | GLOBAL | UNKNOWN",
  "study_area_name": "string",
  "country": ["country names explicitly supported by the text"],
  "additional_areas": ["additional study areas explicitly included"],
  "evidence": "short supporting text or faithful paraphrase",
  "confidence": "high | medium | low"
}"""

P2_USER = """Extract the study area from the following publication.

Title:
{title}

Abstract:
{abstract}

Return JSON only."""

P2_SCHEMA = {
    "type": "object",
    "properties": {
        "study_area_type": {"type": "string", "enum": P2_AREA_LEVELS},
        "study_area_name": {"type": "string"},
        "country": {"type": "array", "items": {"type": "string"}},
        "additional_areas": {"type": "array", "items": {"type": "string"}},
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["study_area_type", "study_area_name", "country", "additional_areas", "evidence", "confidence"],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 3 —— 生态系统一级分类（新版 taxonomy）
# =============================================================================
P3_VERSION = "P3-ecosystem-v2.0"

P3_PRIMARY_ENUM = [
    "Forest Ecosystems",
    "Dryland and Grassland Ecosystems",
    "Wetland Ecosystems",
    "Aquatic Ecosystems",
    "Agricultural Ecosystems",
    "Urban and Artificial Ecosystems",
    "Special and Other Ecosystems",
    "UNKNOWN",
]

#: 一级类别 -> 允许的亚类（严格配对，避免“农业-干旱区”这类交叉错误）
P3_SUBTYPE_MAP: Dict[str, List[str]] = {
    "Forest Ecosystems": [
        "Tropical forests",
        "Subtropical forests",
        "Temperate forests",
        "Boreal forests",
        "Mixed forests",
        "Forest plantations",
        "Woodland / savanna woodland",
    ],
    "Dryland and Grassland Ecosystems": [
        "Temperate grasslands",
        "Tropical savannas",
        "Natural meadows",
        "Steppe",
        "Deserts",
        "Semi-arid shrublands",
        "Gobi and other hyper-arid systems",
    ],
    "Wetland Ecosystems": [
        "Marshes",
        "Swamps",
        "Peatlands",
        "Mangroves",
        "Salt marshes",
        "Tidal flats",
        "Coastal wetlands",
        "Constructed wetlands",
    ],
    "Aquatic Ecosystems": [
        "Rivers",
        "Lakes",
        "Reservoirs",
        "Springs / groundwater",
        "Estuaries",
        "Coastal waters",
        "Coral reefs",
        "Seagrass ecosystems",
        "Marine / pelagic ecosystems",
    ],
    "Agricultural Ecosystems": [
        "Croplands",
        "Paddy fields",
        "Orchards",
        "Plantations",
        "Vineyards",
        "Tea plantations",
        "Agroforestry",
        "Agro-pastoral systems",
    ],
    "Urban and Artificial Ecosystems": [
        "Urban built-up areas",
        "Urban green spaces",
        "Parks",
        "Peri-urban ecosystems",
        "Mining areas",
        "Artificial / managed landscapes",
    ],
    "Special and Other Ecosystems": [
        "Glaciers",
        "Polar ecosystems",
        "Arctic tundra",
        "Antarctic ecosystems",
        "Permafrost ecosystems",
        "Karst ecosystems",
        "Island ecosystems",
        "Mountain ecosystems",
        "Other clearly defined special ecosystems",
    ],
    "UNKNOWN": ["UNKNOWN"],
}

#: 每个一级类都允许 UNKNOWN 亚类：一级类明确但亚类证据不足时应输出 UNKNOWN，
#: 而不是被强迫在亚类里猜一个（对应“不能为了得到更多信息而强迫细粒度分类”）。
for _pk in list(P3_SUBTYPE_MAP):
    if "UNKNOWN" not in P3_SUBTYPE_MAP[_pk]:
        P3_SUBTYPE_MAP[_pk].append("UNKNOWN")

P3_SUBTYPE_ENUM = [s for s in dict.fromkeys(s for subs in P3_SUBTYPE_MAP.values() for s in subs)]

#: 供 prompt 内联的“亚类配对表”文本（保证模型看到合法配对）
def _subtype_block() -> str:
    lines: List[str] = []
    for primary, subs in P3_SUBTYPE_MAP.items():
        if primary == "UNKNOWN":
            continue
        lines.append(f"{primary.upper().replace(' ', '_')}:")
        for s in subs:
            if s == "UNKNOWN":
                continue  # UNKNOWN 由规则 8 说明，不在词表里重复
            lines.append(f"- {s}")
        lines.append("")
    return "\n".join(lines).strip()


P3_SYSTEM = """You are a rigorous scientific classifier specializing in ecosystem service valuation research.

Your task is to identify the PRIMARY ECOSYSTEM that is actually evaluated, valued, assessed, or modeled in the publication.

Use ONLY the title and abstract provided.
Do not use outside knowledge.
Do not classify an ecosystem merely because it is mentioned as background, comparison, or a general example.

IMPORTANT:
Each publication must receive exactly ONE primary ecosystem category and ONE corresponding subtype.

If a publication evaluates multiple ecosystems:
- identify the ecosystem that is most central to the study objective, valuation, analysis, or reported findings;
- if one ecosystem clearly dominates the study, classify that ecosystem;
- if several ecosystems are explicitly evaluated but none is dominant, classify the most specific common ecosystem category supported by the study;
- if no defensible primary ecosystem can be identified, return UNKNOWN.

Do NOT infer an ecosystem from geographic location alone.

For example:
- "Amazon Basin" does not automatically mean "tropical forest";
- "Tibetan Plateau" does not automatically mean "grassland";
- "coastal city" does not automatically mean "coastal wetland".

The classification taxonomy is:

1. Forest Ecosystems
2. Dryland and Grassland Ecosystems
3. Wetland Ecosystems
4. Aquatic Ecosystems
5. Agricultural Ecosystems
6. Urban and Artificial Ecosystems
7. Special and Other Ecosystems

Use the following subtype vocabulary:

__SUBTYPE_BLOCK__

Rules:
1. Select exactly ONE primary category.
2. Select exactly ONE subtype belonging to that category.
3. Use the exact taxonomy terminology.
4. Do not create new categories.
5. Do not classify based solely on geographic location.
6. Do not treat an ecosystem mentioned only in the introduction/background as the study ecosystem.
7. If the paper evaluates several ecosystems, identify the dominant ecosystem according to the study objective and results.
8. If no primary ecosystem can be identified, return UNKNOWN for both fields.
9. Include a short evidence statement.
10. Confidence must reflect evidential certainty, not general model confidence.

Return ONLY valid JSON:

{
  "ecosystem_primary": "...",
  "ecosystem_subtype": "...",
  "evidence": "...",
  "confidence": "high | medium | low"
}""".replace("__SUBTYPE_BLOCK__", _subtype_block())

P3_USER = """Title:
{title}

Abstract:
{abstract}

Return JSON only."""

P3_SCHEMA = {
    "type": "object",
    "properties": {
        "ecosystem_primary": {"type": "string", "enum": P3_PRIMARY_ENUM},
        "ecosystem_subtype": {"type": "string", "enum": P3_SUBTYPE_ENUM},
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["ecosystem_primary", "ecosystem_subtype", "evidence", "confidence"],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 4 —— 生态系统服务一级分类
# =============================================================================
P4_VERSION = "P4-esv-service-v2.0"

P4_PRIMARY_ENUM = [
    "PROVISIONING_SERVICES",
    "REGULATING_SERVICES",
    "CULTURAL_SERVICES",
    "SUPPORTING_SERVICES",
    "BUNDLED_ECOSYSTEM_SERVICES",
    "UNKNOWN",
]

#: 一级类别 -> 允许的亚类（与旧版 EST2 词表兼容，仅作为探索性结果）
P4_SUBTYPE_MAP: Dict[str, List[str]] = {
    "PROVISIONING_SERVICES": [
        "Food",
        "Freshwater",
        "Timber & fiber",
        "Fuelwood & biomass energy",
        "Medicinal resources",
        "Genetic resources",
    ],
    "REGULATING_SERVICES": [
        "Climate regulation",
        "Air quality regulation",
        "Water flow regulation",
        "Water purification",
        "Erosion prevention & soil fertility maintenance",
        "Pollination",
        "Pest & disease regulation",
        "Natural hazard regulation",
    ],
    "CULTURAL_SERVICES": [
        "Aesthetic values",
        "Recreation & tourism",
        "Spiritual & religious values",
        "Cultural heritage",
        "Education & knowledge systems",
        "Sense of place",
    ],
    "SUPPORTING_SERVICES": [
        "Primary production",
        "Nutrient cycling",
        "Soil formation",
        "Habitat provision",
    ],
    "BUNDLED_ECOSYSTEM_SERVICES": ["Bundled ecosystem services"],
    "UNKNOWN": ["UNKNOWN"],
}

#: 与 P3 同理：每个一级类都允许 UNKNOWN 亚类（一级类明确、亚类证据不足时）
for _pk in list(P4_SUBTYPE_MAP):
    if "UNKNOWN" not in P4_SUBTYPE_MAP[_pk]:
        P4_SUBTYPE_MAP[_pk].append("UNKNOWN")

P4_SUBTYPE_ENUM = [s for s in dict.fromkeys(s for subs in P4_SUBTYPE_MAP.values() for s in subs)]


def _p4_subtype_block() -> str:
    lines: List[str] = []
    for primary, subs in P4_SUBTYPE_MAP.items():
        if primary == "UNKNOWN":
            continue
        lines.append(f"{primary}:")
        for s in subs:
            if s == "UNKNOWN":
                continue  # UNKNOWN 由规则 4 说明，不在词表里重复
            lines.append(f"- {s}")
        lines.append("")
    return "\n".join(lines).strip()


P4_SYSTEM = """You are a rigorous scientific classifier specializing in ecosystem service valuation.

Your task is to identify the SINGLE PRIMARY ECOSYSTEM SERVICE that is most central to the publication.

Use ONLY the title and abstract.
Do not use outside knowledge.

The classification must reflect the service that is:
- explicitly valued;
- explicitly assessed as the main service;
- central to the study objective;
- or central to the reported results.

Do not classify a service merely because it is mentioned in the background.

Use the following four primary categories:

1. PROVISIONING_SERVICES
Services involving material products obtained from ecosystems.

Examples:
- Food
- Freshwater
- Timber and fiber
- Biomass energy
- Medicinal resources
- Genetic resources

2. REGULATING_SERVICES
Services involving regulation of ecological or environmental processes.

Examples:
- Climate regulation
- Air quality regulation
- Water flow regulation
- Water purification
- Erosion control and soil retention
- Pollination
- Pest and disease regulation
- Natural hazard regulation

3. CULTURAL_SERVICES
Non-material benefits obtained from ecosystems.

Examples:
- Recreation and tourism
- Aesthetic values
- Spiritual and religious values
- Cultural heritage
- Education and knowledge
- Sense of place

4. SUPPORTING_SERVICES
Underlying ecological processes that support other ecosystem services.

Examples:
- Primary production
- Nutrient cycling
- Soil formation
- Habitat provision

IMPORTANT:
If the paper evaluates ecosystem services as a bundle and does not identify one dominant service:
- classify the PRIMARY CATEGORY as BUNDLED_ECOSYSTEM_SERVICES;
- do not arbitrarily select one service.

If a paper evaluates several services but one is clearly the main focus, select that service.

Do not confuse:
- ecosystem function with ecosystem service;
- biodiversity with ecosystem service;
- ecosystem condition with ecosystem service;
- economic benefit with an ecosystem service unless the abstract explicitly links it to an ecosystem service.

The subtype vocabulary (subtype must belong to the chosen primary category):

__SUBTYPE_BLOCK__

Rules:
1. Select exactly ONE primary category and exactly ONE subtype from that category.
2. Use the exact terminology given above; do not create new subtypes.
3. If the primary category is BUNDLED_ECOSYSTEM_SERVICES, the subtype must be "Bundled ecosystem services".
4. If no primary service can be identified, return UNKNOWN for both fields.
5. Confidence must reflect evidential certainty.

Return ONLY valid JSON:

{
  "service_primary": "PROVISIONING_SERVICES | REGULATING_SERVICES | CULTURAL_SERVICES | SUPPORTING_SERVICES | BUNDLED_ECOSYSTEM_SERVICES | UNKNOWN",
  "service_subtype": "exact subtype if clearly supported, otherwise UNKNOWN",
  "evidence": "short supporting statement",
  "confidence": "high | medium | low"
}""".replace("__SUBTYPE_BLOCK__", _p4_subtype_block())

P4_USER = """Title:
{title}

Abstract:
{abstract}

Return JSON only."""

P4_SCHEMA = {
    "type": "object",
    "properties": {
        "service_primary": {"type": "string", "enum": P4_PRIMARY_ENUM},
        "service_subtype": {"type": "string", "enum": P4_SUBTYPE_ENUM},
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["service_primary", "service_subtype", "evidence", "confidence"],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 5 —— 理论导向 / 实践导向
# =============================================================================
P5_VERSION = "P5-orientation-v2.0"

P5_ORIENTATION_ENUM = ["PRACTICE_ORIENTED", "THEORY_ORIENTED", "UNCERTAIN"]
P5_APPLICATION_ENUM = [
    "management",
    "planning",
    "conservation",
    "restoration",
    "policy",
    "compensation_or_PES",
    "accounting",
    "decision_support",
    "resource_allocation",
    "other",
    "none",
    "unclear",
]

P5_SYSTEM = """You are a rigorous academic annotator specializing in ecosystem service valuation research.

Your task is to classify whether the publication has an EXPLICIT PRACTICE ORIENTATION.

The classification must be based on explicit evidence in the provided title and abstract.

IMPORTANT:
Do not infer real-world application merely because the authors mention:
- implications;
- significance;
- importance;
- sustainability;
- conservation;
- management;
- policy;
- decision making.

A paper should be classified as PRACTICE_ORIENTED only when the abstract explicitly connects the ecosystem service valuation/assessment results to a concrete management, policy, planning, governance, financial, compensation, or decision-making application.

PRACTICE_ORIENTED includes publications that explicitly state that valuation results are used or intended to be used for:

1. Specific environmental management actions;
2. Spatial planning or land-use planning;
3. Conservation planning;
4. Ecological restoration;
5. Environmental policy formulation or evaluation;
6. Payment for ecosystem services or ecological compensation;
7. Natural capital accounting used for decision making;
8. Cost-benefit or economic decision analysis;
9. Resource allocation;
10. Management standards or targets;
11. Decision-support systems or tools;
12. Explicit policy implementation or evaluation.

THEORY_ORIENTED includes studies that primarily:
- develop or compare valuation methods;
- estimate ecosystem service values without a concrete application;
- map ecosystem service values without explicit decision use;
- examine drivers of ecosystem service value;
- conduct conceptual or theoretical analysis;
- discuss general implications without a concrete application.

IMPORTANT:
"Policy implications" alone are NOT sufficient.
"Management implications" alone are NOT sufficient.
"Results can inform..." alone are NOT sufficient unless the target decision or application is explicitly identified.

If the evidence is insufficient, classify as UNCERTAIN rather than guessing.

Return ONLY valid JSON:

{
  "orientation": "PRACTICE_ORIENTED | THEORY_ORIENTED | UNCERTAIN",
  "application_type": "management | planning | conservation | restoration | policy | compensation_or_PES | accounting | decision_support | resource_allocation | other | none | unclear",
  "evidence": "short evidence statement from the title/abstract",
  "confidence": "high | medium | low"
}"""

P5_USER = """Classify the theory/practice orientation of the following publication.

Title:
{title}

Abstract:
{abstract}

Return JSON only."""

P5_SCHEMA = {
    "type": "object",
    "properties": {
        "orientation": {"type": "string", "enum": P5_ORIENTATION_ENUM},
        "application_type": {"type": "string", "enum": P5_APPLICATION_ENUM},
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["orientation", "application_type", "evidence", "confidence"],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 6 —— 作者机构地理归一化（只给国家/行政区/城市，不给坐标）
# =============================================================================
P6_VERSION = "P6-affiliation-v2.0"

P6_SYSTEM = """You are a precise academic affiliation normalization assistant.

Your task is to identify the geographic location of an author's institutional affiliation.

Use ONLY the provided affiliation/address text.

Do NOT infer location from the author's name.
Do NOT use the study area.
Do NOT use the journal or publisher.
Do NOT use external contextual assumptions.

Extract:

1. Country
2. First-level administrative region, if explicitly supported
3. City, if explicitly supported
4. Normalized institution location string

If the text does not provide sufficient evidence:
- return UNKNOWN;
- do not guess.

If multiple affiliations are listed:
- preserve all explicitly supported locations;
- do not arbitrarily choose one unless the input identifies the author's primary affiliation.

Return ONLY valid JSON:

{
  "country": "string or UNKNOWN",
  "region": "string or UNKNOWN",
  "city": "string or UNKNOWN",
  "normalized_location": "string or UNKNOWN",
  "evidence": "short supporting text",
  "confidence": "high | medium | low"
}"""

P6_USER = """Affiliation/address text:

{affiliation_text}

Return JSON only."""

P6_SCHEMA = {
    "type": "object",
    "properties": {
        "country": {"type": "string"},
        "region": {"type": "string"},
        "city": {"type": "string"},
        "normalized_location": {"type": "string"},
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["country", "region", "city", "normalized_location", "evidence", "confidence"],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 7 —— 研究区域标准化（不给坐标；坐标交给 GIS/geocoder）
# =============================================================================
P7_VERSION = "P7-location-norm-v2.0"

P7_SYSTEM = """You are a geographic entity normalization assistant.

Your task is to normalize a research-area name extracted from an academic publication.

Use ONLY the provided research-area text.

Preserve the actual study area and do not replace it with the author's institutional location.

Return:

- original_name
- normalized_name
- geographic_level
- country
- region
- ambiguity_flag

Allowed geographic levels:

SITE
CITY
COUNTY_DISTRICT
PROVINCE_STATE
WATERSHED_BASIN
PROTECTED_AREA
ISLAND
MOUNTAIN_REGION
COUNTRY
MULTI_COUNTRY
CONTINENT
GLOBAL
UNKNOWN

Rules:

1. Do not invent coordinates.
2. Do not invent administrative units.
3. If a named river basin crosses multiple countries, do not force it into one country.
4. If the location is ambiguous, mark ambiguity_flag = true.
5. If the location is global, use GLOBAL.
6. If several countries are explicitly studied, use MULTI_COUNTRY.
7. If only a country is given, do not infer a city.
8. If only a broad region is given, do not infer a more specific location.

Return ONLY JSON:

{
  "original_name": "...",
  "normalized_name": "...",
  "geographic_level": "...",
  "country": ["..."],
  "region": ["..."],
  "ambiguity_flag": true,
  "confidence": "high | medium | low"
}"""

P7_USER = """Research-area text to normalize:

{study_area_text}

Context (may be empty; use ONLY if it is consistent with the research-area text):

Country field from the study-area extraction step: {country_hint}

Return JSON only."""

P7_SCHEMA = {
    "type": "object",
    "properties": {
        "original_name": {"type": "string"},
        "normalized_name": {"type": "string"},
        "geographic_level": {"type": "string", "enum": P2_AREA_LEVELS},
        "country": {"type": "array", "items": {"type": "string"}},
        "region": {"type": "array", "items": {"type": "string"}},
        "ambiguity_flag": {"type": "boolean"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": [
        "original_name",
        "normalized_name",
        "geographic_level",
        "country",
        "region",
        "ambiguity_flag",
        "confidence",
    ],
    "additionalProperties": False,
}


# =============================================================================
# Prompt 8 —— 全文复核（adjudication）
# =============================================================================
P8_VERSION = "P8-fulltext-adjudication-v2.0"

P8_TARGET_ENUM = ["RELEVANCE", "STUDY_AREA", "ECOSYSTEM", "ESV_SERVICE", "ORIENTATION"]

P8_SYSTEM = """You are an expert annotator conducting a full-text validation of an automated literature classification.

The publication was initially classified using its title and abstract.

Your task is NOT to reproduce the automated classification.

Instead, independently determine the correct label using the available full-text evidence.

Evidence hierarchy:

1. Study objectives / research questions
2. Study area description
3. Methods describing the valuation target
4. Results
5. Conclusions
6. Introduction/background

Do not classify based on background mentions when the actual study design indicates otherwise.

For ecosystem classification:
- identify the ecosystem actually evaluated or valued.

For ecosystem-service classification:
- identify the service actually evaluated or valued;
- if multiple services are evaluated without a dominant service, classify as BUNDLED_ECOSYSTEM_SERVICES.

For theory/practice orientation:
- require explicit evidence of a concrete management, policy, planning, accounting, compensation, or decision-making application.

For study area:
- identify the geographic area actually analyzed;
- distinguish it from author affiliations and background examples.

If evidence is insufficient:
- return UNKNOWN or UNCERTAIN rather than guessing.

For every decision, provide:
1. final label;
2. evidence location;
3. short evidence statement;
4. confidence.

Return ONLY valid JSON:

{
  "target_variable": "RELEVANCE | STUDY_AREA | ECOSYSTEM | ESV_SERVICE | ORIENTATION",
  "final_label": "the corrected label for the target variable, using the same vocabulary as the automated step; use UNKNOWN or UNCERTAIN if evidence is insufficient",
  "final_subtype_or_level": "subtype / geographic level / geographic name if applicable, otherwise UNKNOWN",
  "agree_with_abstract_only_label": "yes | no | unclear",
  "evidence_location": "Objectives | Study area | Methods | Results | Conclusions | Introduction",
  "evidence": "short evidence statement from the full text",
  "confidence": "high | medium | low"
}"""

P8_USER = """TARGET VARIABLE: {target_variable}

AUTOMATED (TITLE+ABSTRACT) LABEL: {auto_label}
AUTOMATED SUBTYPE / LEVEL: {auto_subtype}
AUTOMATED EVIDENCE: {auto_evidence}

ALLOWED LABEL VOCABULARY: {allowed_labels}
ALLOWED SUBTYPE / LEVEL VOCABULARY: {allowed_subtypes}

FULL TEXT (may be truncated):

{fulltext}

Determine the correct label independently and return JSON only."""

#: 全文复核时按目标变量注入的标签词表
P8_ALLOWED: Dict[str, Dict[str, List[str]]] = {
    "RELEVANCE": {"labels": P1_RELEVANCE_CLASSES, "subtypes": ["UNKNOWN"]},
    "STUDY_AREA": {"labels": P2_AREA_LEVELS, "subtypes": ["UNKNOWN"]},
    "ECOSYSTEM": {"labels": P3_PRIMARY_ENUM, "subtypes": P3_SUBTYPE_ENUM},
    "ESV_SERVICE": {"labels": P4_PRIMARY_ENUM, "subtypes": P4_SUBTYPE_ENUM},
    "ORIENTATION": {"labels": P5_ORIENTATION_ENUM, "subtypes": P5_APPLICATION_ENUM},
}

P8_SCHEMA = {
    "type": "object",
    "properties": {
        "target_variable": {"type": "string", "enum": P8_TARGET_ENUM},
        "final_label": {"type": "string"},
        "final_subtype_or_level": {"type": "string"},
        "agree_with_abstract_only_label": {"type": "string", "enum": ["yes", "no", "unclear"]},
        "evidence_location": {
            "type": "string",
            "enum": ["Objectives", "Study area", "Methods", "Results", "Conclusions", "Introduction"],
        },
        "evidence": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": [
        "target_variable",
        "final_label",
        "final_subtype_or_level",
        "agree_with_abstract_only_label",
        "evidence_location",
        "evidence",
        "confidence",
    ],
    "additionalProperties": False,
}


# =============================================================================
# 注册表
# =============================================================================
PROMPTS: Dict[str, Dict[str, Any]] = {
    "relevance": {
        "version": P1_VERSION,
        "system": P1_SYSTEM,
        "user": P1_USER,
        "schema": P1_SCHEMA,
        "schema_name": "esv_relevance_v2",
        "required_keys": ["relevance_class", "evidence", "confidence"],
        "outputs": ["relevance_class", "evidence", "confidence"],
    },
    "study_area": {
        "version": P2_VERSION,
        "system": P2_SYSTEM,
        "user": P2_USER,
        "schema": P2_SCHEMA,
        "schema_name": "study_area_v2",
        "required_keys": ["study_area_type", "study_area_name", "country", "additional_areas", "evidence", "confidence"],
        "outputs": ["study_area_type", "study_area_name", "country", "additional_areas", "evidence", "confidence"],
    },
    "ecosystem": {
        "version": P3_VERSION,
        "system": P3_SYSTEM,
        "user": P3_USER,
        "schema": P3_SCHEMA,
        "schema_name": "ecosystem_v2",
        "required_keys": ["ecosystem_primary", "ecosystem_subtype", "evidence", "confidence"],
        "outputs": ["ecosystem_primary", "ecosystem_subtype", "evidence", "confidence"],
    },
    "esv_service": {
        "version": P4_VERSION,
        "system": P4_SYSTEM,
        "user": P4_USER,
        "schema": P4_SCHEMA,
        "schema_name": "esv_service_v2",
        "required_keys": ["service_primary", "service_subtype", "evidence", "confidence"],
        "outputs": ["service_primary", "service_subtype", "evidence", "confidence"],
    },
    "orientation": {
        "version": P5_VERSION,
        "system": P5_SYSTEM,
        "user": P5_USER,
        "schema": P5_SCHEMA,
        "schema_name": "orientation_v2",
        "required_keys": ["orientation", "application_type", "evidence", "confidence"],
        "outputs": ["orientation", "application_type", "evidence", "confidence"],
    },
    "affiliation": {
        "version": P6_VERSION,
        "system": P6_SYSTEM,
        "user": P6_USER,
        "schema": P6_SCHEMA,
        "schema_name": "affiliation_v2",
        "required_keys": ["country", "region", "city", "normalized_location", "evidence", "confidence"],
        "outputs": ["country", "region", "city", "normalized_location", "evidence", "confidence"],
    },
    "location_norm": {
        "version": P7_VERSION,
        "system": P7_SYSTEM,
        "user": P7_USER,
        "schema": P7_SCHEMA,
        "schema_name": "location_norm_v2",
        "required_keys": [
            "original_name",
            "normalized_name",
            "geographic_level",
            "country",
            "region",
            "ambiguity_flag",
            "confidence",
        ],
        "outputs": [
            "original_name",
            "normalized_name",
            "geographic_level",
            "country",
            "region",
            "ambiguity_flag",
            "confidence",
        ],
    },
    "fulltext_adjudication": {
        "version": P8_VERSION,
        "system": P8_SYSTEM,
        "user": P8_USER,
        "schema": P8_SCHEMA,
        "schema_name": "fulltext_adjudication_v2",
        "required_keys": [
            "target_variable",
            "final_label",
            "final_subtype_or_level",
            "agree_with_abstract_only_label",
            "evidence_location",
            "evidence",
            "confidence",
        ],
        "outputs": [
            "target_variable",
            "final_label",
            "final_subtype_or_level",
            "agree_with_abstract_only_label",
            "evidence_location",
            "evidence",
            "confidence",
        ],
    },
}

PROMPT_VERSIONS: Dict[str, str] = {k: v["version"] for k, v in PROMPTS.items()}
SCHEMA_VERSIONS: Dict[str, str] = {k: f"{v['schema_name']}@{v['version']}" for k, v in PROMPTS.items()}


def get_prompt(key: str) -> Dict[str, Any]:
    if key not in PROMPTS:
        raise KeyError(f"未知 prompt 键: {key}；可用: {sorted(PROMPTS)}")
    return PROMPTS[key]


def get_system(key: str) -> str:
    return get_prompt(key)["system"]


def get_user(key: str, **kwargs: Any) -> str:
    return get_prompt(key)["user"].format(**kwargs)


def prompt_fingerprint(key: str) -> str:
    """提示词 SHA1（前 12 位），用于 Supplementary 中的版本核对。"""
    p = get_prompt(key)
    blob = (p["system"] + "\n---\n" + p["user"]).encode("utf-8")
    return hashlib.sha1(blob).hexdigest()[:12]


def all_versions() -> Dict[str, Dict[str, str]]:
    return {
        k: {"version": PROMPT_VERSIONS[k], "schema": SCHEMA_VERSIONS[k], "sha1_12": prompt_fingerprint(k)}
        for k in sorted(PROMPTS)
    }
