# -*- coding: utf-8 -*-
"""
llm_utils.py —— LLM 调用与数据处理的公共工具层（第0层，被所有脚本共享）

设计原则：
1. 不再硬编码任何 API Key，统一从环境变量 / .env 文件读取；
2. 所有核心分类任务 temperature = 0（可复现），不再使用 0.2；
3. 优先使用 JSON Schema + enum 做结构化输出约束（DeepSeek / OpenAI 均支持
   response_format = {"type": "json_schema", ...}；服务端不支持时自动降级为
   json_object，再降级为严格解析）；
4. 输出必须可审计：每次调用记录 model / prompt_version / temperature /
   evidence / confidence / raw 输出；
5. 单行失败不污染整表：写入失败标记，可重跑；
6. 断点续跑：每 SAVE_EVERY 行落盘一次，重跑时跳过已完成行。

核心第三方依赖见 requirements.txt；可选功能见 requirements-optional.txt。
"""

from __future__ import annotations

import json
import os
import random
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import requests

__all__ = [
    "Settings",
    "load_settings",
    "CallRecord",
    "LLMError",
    "LLMClient",
    "get_client",
    "read_table",
    "write_table",
    "find_column",
    "find_text_column",
    "safe_cell",
    "is_blank",
    "extract_json_block",
    "as_text",
    "as_confidence",
    "as_bool",
    "as_name_list",
    "split_wos_addresses",
    "shorten_text",
    "strip_enum_suffix",
    "normalize_enum_value",
    "RunManifest",
    "BACKUP_DIRNAME",
    "ESV_KEEP_CLASS",
    "is_esv_corpus",
    "require_esv_corpus",
]


# =============================================================================
# 0. 运行设置（环境变量 / .env）
# =============================================================================
BACKUP_DIRNAME = "_backup"

#: .env 中允许出现的键；用于把 .env 的值注入 os.environ（不覆盖已有环境变量）
_ENV_KEYS = (
    "LLM_PROVIDER",
    "DEEPSEEK_API_KEY",
    "DEEPSEEK_BASE_URL",
    "DEEPSEEK_MODEL",
    "OPENAI_API_KEY",
    "OPENAI_BASE_URL",
    "OPENAI_MODEL",
    "LLM_TEMPERATURE",
    "LLM_TIMEOUT_SEC",
    "LLM_MAX_TRIES",
    "LLM_JSON_SCHEMA",
    "LLM_MIN_INTERVAL",
    "LLM_MAX_WORKERS",
    "LLM_SAVE_EVERY",
    "LLM_MAX_ABSTRACT_CHARS",
    "LLM_CHECKPOINT_FILE",
    "LLM_STRICT_INPUT",
    "D1_WORK_DIR",
    "PATH_INPUT_CORPUS",
    "PATH_STEP0_RELEVANCE",
    "PATH_STEP0_CORPUS",
    "PATH_STEP0_ESV_CORPUS",
    "PATH_STEP1_ABSTRACT",
    "PATH_STEP2_AFFILIATION",
    "PATH_STEP3_LOCATION",
    "PATH_STEP4_ECOSYSTEM",
    "PATH_STEP5_ESV",
    "PATH_STEP6_ORIENTATION",
    "PATH_STEP7_GEOCODE",
    "PATH_STEP8_DISTANCE",
    "PATH_FULLTEXT_DIR",
    "PATH_FULLTEXT_SAMPLE_XLSX",
    "PATH_FULLTEXT_GOLD_XLSX",
    "PATH_FULLTEXT_RESULT_XLSX",
    "PATH_FULLTEXT_ADJUDICATED_XLSX",
    "PATH_METRICS_XLSX",
    "PDF_UTILITY",
    "PDF_MAX_CHARS",
    "PDF_MAX_PAGES",
    "GEOCODER",
    "GEOCODE_USER_AGENT",
    "GEOCODE_EMAIL",
    "GEOCODE_MIN_INTERVAL",
    "GEOCODE_CACHE_FILE",
    "GEOCODE_GAZETTEER",
    "GEOCODE_OVERRIDES",
    "DISTANCE_UNKNOWN_STRATEGY",
)


def _read_env_file(path: Path) -> None:
    """把 .env 里的键值对注入 os.environ（已存在的环境变量优先，不覆盖）。"""
    if not path.is_file():
        return
    try:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
    except Exception:
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def _env(name: str, default: str = "") -> str:
    return (os.environ.get(name) or "").strip() or default


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(_env(name, str(default))))
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env(name, str(default)))
    except Exception:
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = _env(name, "")
    if not raw:
        return default
    return raw.lower() in ("1", "true", "yes", "y", "on")


@dataclass
class Settings:
    """全部运行参数。首次调用 load_settings() 时读取环境变量与 .env。"""

    base_dir: Path
    work_dir: Path
    provider: str
    api_key: str
    base_url: str
    chat_url: str
    model: str
    temperature: float
    timeout_sec: int
    max_tries: int
    min_interval: float
    max_workers: int
    use_json_schema: bool
    save_every: int
    max_abstract_chars: int
    checkpoint_file: Path
    paths: Dict[str, str] = field(default_factory=dict)
    geocode: Dict[str, str] = field(default_factory=dict)
    fulltext: Dict[str, Any] = field(default_factory=dict)
    distance_unknown_strategy: str = "exclude"
    #: True（默认）时，step1~step8 的默认输入必须指向 step0 生成的 ESV 子集数据库；
    #: 找不到就报错，绝不静默回退到全量原始语料（否则分母不一致且无人察觉）。
    strict_input: bool = True

    # ---- 便捷属性 ----
    @property
    def has_api_key(self) -> bool:
        return bool(self.api_key)

    def path(self, key: str) -> Path:
        """按 PATH_* 键取路径；PATH_ 前缀可省略、键名大小写不敏感。"""
        k = key.upper()
        if not k.startswith("PATH_"):
            k = "PATH_" + k
        raw = self.paths.get(k) or _env(k, "")
        if not raw:
            raise KeyError(f"未配置路径 {k}，请在 .env 或环境变量中设置。")
        return Path(raw)

    def raw_path(self, key: str) -> str:
        return str(self.path(key))


_SETTINGS: Optional[Settings] = None
_SETTINGS_LOCK = threading.Lock()


def _default_work_dir(base_dir: Path) -> Path:
    """Return a portable output directory; an explicit setting always wins."""
    explicit = _env("D1_WORK_DIR", "")
    if explicit:
        return Path(explicit)
    return base_dir / "results"


def load_settings(base_dir: Optional[Path] = None, reload: bool = False) -> Settings:
    """读取（并缓存）运行设置。base_dir 默认是本文件所在目录。"""
    global _SETTINGS
    with _SETTINGS_LOCK:
        if _SETTINGS is not None and not reload:
            return _SETTINGS

        bdir = Path(base_dir) if base_dir else Path(__file__).resolve().parent
        _read_env_file(bdir / ".env")
        work = _default_work_dir(bdir)

        provider = _env("LLM_PROVIDER", "deepseek").lower()
        if provider not in ("deepseek", "openai"):
            provider = "deepseek"

        if provider == "openai":
            api_key = _env("OPENAI_API_KEY", "")
            base_url = _env("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
            model = _env("OPENAI_MODEL", "gpt-4o-mini")
            key_hint = "OPENAI_API_KEY"
        else:
            api_key = _env("DEEPSEEK_API_KEY", "") or _env("OPENAI_API_KEY", "")
            base_url = _env("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1").rstrip("/")
            model = _env("DEEPSEEK_MODEL", "deepseek-chat")
            key_hint = "DEEPSEEK_API_KEY"

        if base_url.endswith("/chat/completions"):
            chat_url = base_url
        else:
            chat_url = base_url + "/chat/completions"

        p = lambda name, default: _env(name, os.path.join(str(work), default))

        paths = {
            "PATH_INPUT_CORPUS": _env("PATH_INPUT_CORPUS", os.path.join(str(bdir), "data", "all.xlsx")),
            "PATH_STEP0_RELEVANCE": _env("PATH_STEP0_RELEVANCE", p("PATH_STEP0_RELEVANCE", "0_Relevance_out.xlsx")),
            #: ESV 子集数据库：step0 按 relevance_class 过滤后的语料，
            #: step1~step8 一律以此为输入，保证所有步骤的样本与分母完全一致。
            "PATH_STEP0_CORPUS": _env(
                "PATH_STEP0_CORPUS",
                _env("PATH_STEP0_ESV_CORPUS", p("PATH_STEP0_CORPUS", "0_Corpus_ESV.xlsx")),
            ),
            "PATH_STEP1_ABSTRACT": _env("PATH_STEP1_ABSTRACT", p("PATH_STEP1_ABSTRACT", "1_abstract_out.xlsx")),
            "PATH_STEP2_AFFILIATION": _env("PATH_STEP2_AFFILIATION", p("PATH_STEP2_AFFILIATION", "2_Affiliations_out.xlsx")),
            "PATH_STEP3_LOCATION": _env("PATH_STEP3_LOCATION", p("PATH_STEP3_LOCATION", "3_Location_out.xlsx")),
            "PATH_STEP4_ECOSYSTEM": _env("PATH_STEP4_ECOSYSTEM", p("PATH_STEP4_ECOSYSTEM", "4_Ecosystem_Type_out.xlsx")),
            "PATH_STEP5_ESV": _env("PATH_STEP5_ESV", p("PATH_STEP5_ESV", "5_EST_out.xlsx")),
            "PATH_STEP6_ORIENTATION": _env("PATH_STEP6_ORIENTATION", p("PATH_STEP6_ORIENTATION", "6_Orientation_out.xlsx")),
            "PATH_STEP7_GEOCODE": _env("PATH_STEP7_GEOCODE", p("PATH_STEP7_GEOCODE", "7_Geocoded.xlsx")),
            "PATH_STEP8_DISTANCE": _env("PATH_STEP8_DISTANCE", p("PATH_STEP8_DISTANCE", "8_Distance_out.xlsx")),
            "PATH_FULLTEXT_DIR": _env("PATH_FULLTEXT_DIR", os.path.join(str(bdir), "fulltext")),
            "PATH_FULLTEXT_SAMPLE_XLSX": _env(
                "PATH_FULLTEXT_SAMPLE_XLSX", p("PATH_FULLTEXT_SAMPLE_XLSX", "FT_1_sample_for_review.xlsx")
            ),
            "PATH_FULLTEXT_GOLD_XLSX": _env(
                "PATH_FULLTEXT_GOLD_XLSX", p("PATH_FULLTEXT_GOLD_XLSX", "FT_2_gold_standard.xlsx")
            ),
            "PATH_FULLTEXT_RESULT_XLSX": _env(
                "PATH_FULLTEXT_RESULT_XLSX", p("PATH_FULLTEXT_RESULT_XLSX", "FT_3_fulltext_llm_out.xlsx")
            ),
            "PATH_FULLTEXT_ADJUDICATED_XLSX": _env(
                "PATH_FULLTEXT_ADJUDICATED_XLSX", p("PATH_FULLTEXT_ADJUDICATED_XLSX", "FT_4_adjudicated.xlsx")
            ),
            "PATH_METRICS_XLSX": _env("PATH_METRICS_XLSX", p("PATH_METRICS_XLSX", "9_Validation_Metrics.xlsx")),
        }

        geocode = {
            "provider": _env("GEOCODER", "auto").lower(),
            "user_agent": _env("GEOCODE_USER_AGENT", "ESV-bibliometric-coding/1.0 (research; contact: set GEOCODE_EMAIL)"),
            "email": _env("GEOCODE_EMAIL", ""),
            "min_interval": _env_float("GEOCODE_MIN_INTERVAL", 1.1),
            "cache_file": _env("GEOCODE_CACHE_FILE", os.path.join(str(work), "geocode_cache.csv")),
            "gazetteer": _env("GEOCODE_GAZETTEER", os.path.join(str(bdir), "gazetteer_extra.csv")),
            "overrides": _env("GEOCODE_OVERRIDES", os.path.join(str(bdir), "geocode_overrides.csv")),
        }

        fulltext = {
            "utility": _env("PDF_UTILITY", ""),
            "max_chars": _env_int("PDF_MAX_CHARS", 120000),
            "max_pages": _env_int("PDF_MAX_PAGES", 0),
        }

        _SETTINGS = Settings(
            base_dir=bdir,
            work_dir=work,
            provider=provider,
            api_key=api_key,
            base_url=base_url,
            chat_url=chat_url,
            model=model,
            temperature=_env_float("LLM_TEMPERATURE", 0.0),
            timeout_sec=_env_int("LLM_TIMEOUT_SEC", 90),
            max_tries=_env_int("LLM_MAX_TRIES", 5),
            min_interval=_env_float("LLM_MIN_INTERVAL", 0.0),
            max_workers=max(1, _env_int("LLM_MAX_WORKERS", 1)),
            use_json_schema=_env_bool("LLM_JSON_SCHEMA", True),
            save_every=max(1, _env_int("LLM_SAVE_EVERY", 50)),
            max_abstract_chars=_env_int("LLM_MAX_ABSTRACT_CHARS", 8000),
            checkpoint_file=Path(
                _env("LLM_CHECKPOINT_FILE", os.path.join(str(work), "_checkpoints", "checkpoints.xlsx"))
            ),
            paths=paths,
            geocode=geocode,
            fulltext=fulltext,
            distance_unknown_strategy=_env("DISTANCE_UNKNOWN_STRATEGY", "exclude").lower(),
            strict_input=_env_bool("LLM_STRICT_INPUT", True),
        )

        if not _SETTINGS.api_key:
            # 不抛异常：允许 scripts/stepT3.smoke_test.py 等离线导入本模块。
            # 真正发请求时会给出明确报错。
            _SETTINGS.api_key = ""

        return _SETTINGS


# =============================================================================
# 1.1 输入库守卫：step1~step8 必须跑在 step0 生成的 ESV 子集数据库上
# =============================================================================
#: 进入下游分析的 relevance_class 取值（方案第四节：VALUATION_OR_ACCOUNTING 才是真正的 ESV 研究）
ESV_KEEP_CLASS = "VALUATION_OR_ACCOUNTING"
#: 与 llm_pipeline.FAILED_SENTINEL 保持一致（此处重复定义以避免循环 import）
_PIPELINE_FAILED_SENTINEL = "__FAILED__"


def is_esv_corpus(path: os.PathLike | str) -> bool:
    """
    判断一个表是否是 step0 生成的 ESV 子集数据库：
    必须同时满足 (1) 有 relevance_class 列；(2) 该列只含 VALUATION_OR_ACCOUNTING。
    """
    try:
        import pandas as pd

        p = Path(path)
        if not p.exists():
            return False
        head = pd.read_excel(p, nrows=200)
        if "relevance_class" not in head.columns:
            return False
        values = {safe_cell(v, "") for v in head["relevance_class"].tolist()}
        return bool(values) and values <= {ESV_KEEP_CLASS}
    except Exception:
        return False


def require_esv_corpus(
    path: Path,
    *,
    script_name: str = "",
    allow_fallback: Optional[Path] = None,
) -> Path:
    """
    校验下游步骤的输入是否为 ESV 子集数据库。

    行为：
      - 文件缺失：报错并给出应执行的命令（避免静默跑错样本）；
      - 文件存在但不是 ESV 子集（含未过滤的全量记录）：默认报错，
        除非在 .env 中设置 LLM_STRICT_INPUT=false；
      - allow_fallback：仅在 strict 关闭时才使用的备用路径。
    """
    settings = load_settings()
    p = Path(path)

    if not p.exists():
        if allow_fallback is not None and not settings.strict_input and Path(allow_fallback).exists():
            print(f"[警告] {p.name} 不存在，已回退到 {Path(allow_fallback).name}"
                  f"（严格模式已关闭：结果将基于未过滤语料，务必在方法学中说明）")
            return Path(allow_fallback)
        raise SystemExit(
            f"找不到 ESV 子集数据库: {p}\n"
            f"请先运行: python step0.relevance_screening.py\n"
            f"（step1~step8 必须建立在 step0 过滤后的语料上，否则各步骤样本量不一致）"
        )

    try:
        check_df = read_table(p)
    except Exception as exc:
        raise SystemExit(f"无法读取输入文件 {p}: {exc}")

    if "relevance_class" not in check_df.columns:
        msg = (
            f"输入 {p.name} 没有 relevance_class 列，说明它没有经过 step0 相关性判定。\n"
            f"请先运行 step0.relevance_screening.py，并让本步骤读取它产出的 "
            f"{settings.paths.get('PATH_STEP0_CORPUS')}"
        )
        if settings.strict_input:
            raise SystemExit(msg)
        print(f"[警告] {msg}\n[警告] 严格模式已关闭，继续执行（结果基于未判定语料）。")
        return p

    classes = {safe_cell(v, "") for v in check_df["relevance_class"].tolist()}
    extra = classes - {ESV_KEEP_CLASS, "", _PIPELINE_FAILED_SENTINEL}
    if extra:
        counts = check_df["relevance_class"].fillna("").astype(str).value_counts().to_dict()
        msg = (
            f"输入 {p.name} 包含非 ESV 记录 {sorted(extra)}（分布 {counts}）。\n"
            f"step1~step8 应读取 step0 生成的 ESV 子集数据库（默认 "
            f"{settings.paths.get('PATH_STEP0_CORPUS')}），它已只保留 {ESV_KEEP_CLASS}。"
        )
        if settings.strict_input:
            raise SystemExit(msg)
        print(f"[警告] {msg}\n[警告] 严格模式已关闭，继续执行。")
    return p


# =============================================================================
# 2. 结构化输出 Schema 构造工具
# =============================================================================
def enum_schema(
    properties: Dict[str, Dict[str, Any]],
    required: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """
    构造严格 JSON Schema。
    properties 形如 {"field": {"type": "string", "enum": [...]}}
    """
    props: Dict[str, Any] = {}
    for name, spec in properties.items():
        spec = dict(spec)
        if spec.get("type") == "array":
            spec.setdefault("items", {"type": "string"})
        props[name] = spec
    return {
        "type": "object",
        "properties": props,
        "required": list(required) if required else list(properties.keys()),
        "additionalProperties": False,
    }


def _walk_remove_bad(node: Any) -> Any:
    """DeepSeek 等模型/网关对 JSON Schema 支持有限，递归删除不被支持的约束词。"""
    unsupported = {
        "minItems",
        "maxItems",
        "minLength",
        "maxLength",
        "pattern",
        "format",
        "minimum",
        "maximum",
        "multipleOf",
        "uniqueItems",
        "default",
        "examples",
    }
    if isinstance(node, dict):
        return {k: _walk_remove_bad(v) for k, v in node.items() if k not in unsupported}
    if isinstance(node, list):
        return [_walk_remove_bad(v) for v in node]
    return node


def relaxed_schema(schema: Dict[str, Any]) -> Dict[str, Any]:
    """把严格 schema 放宽为服务端普遍可接受的版本（去掉 length/range 约束）。"""
    return _walk_remove_bad(json.loads(json.dumps(schema)))


# =============================================================================
# 2. LLM 客户端
# =============================================================================
class LLMError(RuntimeError):
    pass


@dataclass
class CallRecord:
    """单次 LLM 调用的审计信息（可写入 RunManifest / evidence 列）。"""

    ok: bool
    data: Dict[str, Any] = field(default_factory=dict)
    raw: str = ""
    error: str = ""
    attempts: int = 0
    mode: str = "json_schema"  # json_schema | json_object | text
    model: str = ""
    prompt_version: str = ""
    temperature: float = 0.0
    elapsed_sec: float = 0.0


class _RateLimiter:
    def __init__(self, min_interval: float) -> None:
        self.min_interval = max(0.0, float(min_interval))
        self._lock = threading.Lock()
        self._next_allowed = 0.0

    def wait(self) -> None:
        if self.min_interval <= 0:
            return
        with self._lock:
            now = time.monotonic()
            if now < self._next_allowed:
                time.sleep(self._next_allowed - now)
                now = time.monotonic()
            self._next_allowed = now + self.min_interval


class LLMClient:
    """
    统一的 Chat Completions 客户端。

    - provider: deepseek | openai（从 Settings 读取）
    - 结构化输出优先级：json_schema -> json_object -> 纯文本+解析
    - 重试：网络错误 / 429 / 5xx / 服务端拒绝 response_format / 解析失败
    - 记录：每次调用返回 CallRecord（含 raw 文本与 model / prompt_version）
    """

    def __init__(self, settings: Optional[Settings] = None) -> None:
        self.s = settings or load_settings()
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        if self.s.api_key:
            self.session.headers.update({"Authorization": f"Bearer {self.s.api_key}"})
        self._limiter = _RateLimiter(self.s.min_interval)
        self._schema_supported: Optional[bool] = None
        self._json_object_supported: Optional[bool] = True
        self.calls = 0
        self.failures = 0

    # ---------- 内部 ----------
    def _build_payload(
        self,
        messages: List[Dict[str, str]],
        schema: Optional[Dict[str, Any]],
        mode: str,
        schema_name: str,
        max_tokens: int,
        temperature: float,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": self.s.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if schema and mode == "json_schema":
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {"name": schema_name, "schema": relaxed_schema(schema), "strict": True},
            }
        elif schema and mode == "json_object":
            payload["response_format"] = {"type": "json_object"}
        return payload

    def _post_once(self, payload: Dict[str, Any]) -> Tuple[int, str]:
        self._limiter.wait()
        resp = self.session.post(self.s.chat_url, data=json.dumps(payload, ensure_ascii=False), timeout=self.s.timeout_sec)
        body = resp.text or ""
        if resp.status_code == 200:
            try:
                content = resp.json()["choices"][0]["message"]["content"] or ""
            except Exception as exc:  # 响应结构异常
                raise LLMError(f"无法解析响应体: {exc}") from exc
            return 200, content
        return resp.status_code, body

    # ---------- 公开 API ----------
    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        schema: Optional[Dict[str, Any]] = None,
        schema_name: str = "structured_output",
        prompt_version: str = "",
        max_tokens: int = 700,
        temperature: Optional[float] = None,
        required_keys: Optional[Sequence[str]] = None,
    ) -> CallRecord:
        """调用模型并返回 CallRecord。永不抛异常（失败时 ok=False）。"""
        temp = self.s.temperature if temperature is None else float(temperature)
        t0 = time.time()
        attempts = 0
        last_err = ""
        modes: List[str] = []
        if schema:
            if self.s.use_json_schema and self._schema_supported is not False:
                modes.append("json_schema")
            if self._json_object_supported:
                modes.append("json_object")
        modes.append("text")

        for attempt in range(1, self.s.max_tries + 1):
            attempts = attempt
            for mode in modes:
                if schema and mode == "text" and len(modes) > 1 and attempt == 1:
                    # 第一轮先走结构化输出，避免无谓的纯文本请求
                    continue
                if not schema and mode != "text":
                    continue
                payload = self._build_payload(messages, schema, mode, schema_name, max_tokens, temp)
                try:
                    status, content = self._post_once(payload)
                except requests.RequestException as exc:
                    last_err = f"network: {exc}"
                    break  # 网络问题换 mode 无意义，直接退避重试
                except LLMError as exc:
                    last_err = str(exc)
                    break

                if status == 401:
                    return CallRecord(
                        ok=False, error="401 未授权：API Key 缺失或已失效（请检查 .env 中的 Key）",
                        attempts=attempt, mode=mode, model=self.s.model,
                        prompt_version=prompt_version, temperature=temp, elapsed_sec=time.time() - t0,
                    )
                if status == 429:
                    last_err = "429 rate limited"
                    break
                if status >= 500:
                    last_err = f"server error {status}"
                    break
                if status == 400 and mode in ("json_schema", "json_object"):
                    # 服务端不支持该 response_format：关闭并降级
                    if mode == "json_schema":
                        self._schema_supported = False
                    else:
                        self._json_object_supported = False
                    last_err = f"400 response_format 不被支持，已降级: {content[:200]}"
                    continue
                if status != 200:
                    last_err = f"HTTP {status}: {content[:200]}"
                    break

                self.calls += 1
                if mode == "json_schema":
                    self._schema_supported = True

                data = extract_json_block(content) if mode != "text" else extract_json_block(content)
                if isinstance(data, dict):
                    missing = [k for k in (required_keys or []) if k not in data]
                    if not missing:
                        return CallRecord(
                            ok=True, data=data, raw=content, attempts=attempt, mode=mode,
                            model=self.s.model, prompt_version=prompt_version,
                            temperature=temp, elapsed_sec=time.time() - t0,
                        )
                    last_err = f"缺少必需字段 {missing}"
                else:
                    last_err = "模型输出不是合法 JSON"

            # 退避
            if attempt < self.s.max_tries:
                sleep_s = min(2.0 * (2 ** (attempt - 1)) + random.random(), 30.0)
                if "429" in last_err:
                    sleep_s += 3.0
                time.sleep(sleep_s)

        self.failures += 1
        return CallRecord(
            ok=False, error=last_err or "unknown error", attempts=attempts, mode="failed",
            model=self.s.model, prompt_version=prompt_version, temperature=temp,
            elapsed_sec=time.time() - t0,
        )

    def classify(
        self,
        system_prompt: str,
        user_prompt: str,
        *,
        schema: Optional[Dict[str, Any]] = None,
        schema_name: str = "structured_output",
        prompt_version: str = "",
        max_tokens: int = 700,
        required_keys: Optional[Sequence[str]] = None,
    ) -> CallRecord:
        """system + user 两段式调用的便捷封装。temperature 固定取 Settings（默认 0）。"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        return self.chat(
            messages,
            schema=schema,
            schema_name=schema_name,
            prompt_version=prompt_version,
            max_tokens=max_tokens,
            required_keys=required_keys,
        )


def get_client(settings: Optional[Settings] = None) -> LLMClient:
    return LLMClient(settings)


# =============================================================================
# 3. 表格读写与列名处理
# =============================================================================
def read_table(path: os.PathLike | str) -> "DataFrame":  # type: ignore[name-defined]
    import pandas as pd

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"输入文件不存在: {p}")
    if p.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(p)
    if p.suffix.lower() == ".csv":
        return pd.read_csv(p)
    raise ValueError(f"不支持的文件类型: {p.suffix}")


def write_table(df, path: os.PathLike | str) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.suffix.lower() == ".csv":
        df.to_csv(p, index=False, encoding="utf-8-sig")
    else:
        df.to_excel(p, index=False)
    return p


def backup_file(path: os.PathLike | str, backup_dirname: str = BACKUP_DIRNAME) -> Optional[Path]:
    """覆盖写之前先备份原文件（不删除、不改名，仅在 _backup/ 下留副本）。"""
    import shutil

    src = Path(path)
    if not src.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = src.parent / backup_dirname / f"{src.stem}_{stamp}{src.suffix}"
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(src, dst)
        return dst
    except Exception:
        return None


def find_column(df, patterns: Iterable[str], exact_first: bool = True) -> Optional[str]:
    """
    按候选列名查找列。
    先做不区分大小写的精确匹配，再做“包含”匹配。
    """
    cols = list(df.columns)
    pats = [p for p in patterns if p]
    if exact_first:
        lower = {str(c).strip().lower(): c for c in cols}
        for p in pats:
            key = p.strip().lower()
            if key in lower:
                return lower[key]
    for p in pats:
        pl = p.lower()
        for c in cols:
            if pl in str(c).lower():
                return c
    return None


# 标题列候选（WoS 导出常见写法）
TITLE_CANDIDATES = ("Article Title", "Document Title", "Title", "title", "TI", "题名", "标题")
ABSTRACT_CANDIDATES = ("Abstract", "abstract", "ABSTRACT", "Summary", "summary", "摘要")
ADDRESS_CANDIDATES = ("Addresses", "Address", "address", "C1", "作者地址")
AFFILIATION_CANDIDATES = ("Affiliations", "Affiliation", "affiliation", "C3", "机构")


def find_text_column(df, candidates: Sequence[str]) -> Optional[str]:
    col = find_column(df, candidates)
    if col:
        return col
    # 最后兜底：寻找最像长文本的对象列
    best, best_len = None, 0.0
    for c in df.columns:
        try:
            if df[c].dtype != object:
                continue
            series = df[c].dropna().astype(str)
            if series.empty:
                continue
            avg = float(series.str.len().mean())
        except Exception:
            continue
        if avg > best_len:
            best, best_len = c, avg
    return best


def safe_cell(value: Any, default: str = "") -> str:
    import pandas as pd

    if value is None:
        return default
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    text = str(value).strip()
    if text.lower() in ("", "nan", "none", "null", "na", "n/a"):
        return default
    return text


def is_blank(value: Any) -> bool:
    return safe_cell(value) == ""


def truncate(text: str, max_chars: int) -> str:
    text = (text or "").strip()
    return text if len(text) <= max_chars else text[:max_chars]


# =============================================================================
# 4. JSON 解析与字段规范化
# =============================================================================
_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.S | re.I)


def extract_json_block(text: str) -> Optional[dict]:
    """从模型输出中稳健地提取第一个 JSON 对象。"""
    if not text:
        return None
    raw = text.strip()

    candidates: List[str] = []
    m = _FENCE_RE.search(raw)
    if m:
        candidates.append(m.group(1).strip())
    candidates.append(raw)

    # 用括号配平找最外层对象（比贪婪正则稳健）
    start = raw.find("{")
    if start != -1:
        depth = 0
        in_str = False
        escape = False
        for i in range(start, len(raw)):
            ch = raw[i]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidates.append(raw[start : i + 1])
                    break

    for cand in candidates:
        for attempt in (cand, re.sub(r",\s*([}\]])", r"\1", cand)):
            try:
                obj = json.loads(attempt)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                continue
    return None


def as_text(value: Any, default: str = "UNKNOWN") -> str:
    text = safe_cell(value, "")
    return text if text else default


def strip_enum_suffix(value: Any) -> str:
    """
    处理模型常见的“枚举自解释”输出，例如：
      "VALUATION_OR_ACCOUNTING | ECOSYSTEM_ASSESSMENT_NO_VALUATION | OUT_OF_SCOPE"
        -> "VALUATION_OR_ACCOUNTING"
      "Forest Ecosystems (森林)" -> "Forest Ecosystems"
    """
    text = safe_cell(value, "")
    if not text:
        return ""
    if "|" in text:
        text = text.split("|")[0]
    text = text.strip()
    text = re.split(r"\s*[\(\（\[【]", text)[0]
    text = re.split(r"\s+[-–—]\s+", text)[0]
    text = text.strip().strip(",;").strip()
    return text


def normalize_enum_value(value: Any, allowed: Sequence[str], default: str = "UNKNOWN") -> str:
    """把模型输出对齐到允许的枚举值（精确 -> 大小写/空格归一 -> 前缀/包含匹配）。"""
    text = strip_enum_suffix(value)
    if not text:
        return default
    if text in allowed:
        return text

    def key(s: str) -> str:
        return re.sub(r"[\s_\-&/]+", "", s.lower())

    kmap = {key(a): a for a in allowed}
    if key(text) in kmap:
        return kmap[key(text)]

    # 形如 "Forest" -> "Forest Ecosystems"
    for a in allowed:
        if key(a).startswith(key(text)) and len(key(text)) >= 4:
            return a
    for a in allowed:
        if key(text).startswith(key(a)) and len(key(a)) >= 4:
            return a
    return default


def as_confidence(value: Any, default: str = "low") -> str:
    """统一置信度为 high|medium|low（也接受数值与中文）。"""
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        v = float(value)
        if v > 1.0:  # 可能是 0-100
            v = v / 100.0
        if v >= 0.8:
            return "high"
        if v >= 0.5:
            return "medium"
        return "low"
    text = safe_cell(value, "").lower()
    if not text:
        return default
    if text in ("high", "h", "高", "0.9"):
        return "high"
    if text in ("medium", "med", "m", "中", "moderate"):
        return "medium"
    if text in ("low", "l", "低"):
        return "low"
    for token, label in (("high", "high"), ("medium", "medium"), ("moderate", "medium"), ("low", "low")):
        if token in text:
            return label
    return default


def as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = safe_cell(value, "").lower()
    if text in ("true", "yes", "y", "1", "是"):
        return True
    if text in ("false", "no", "n", "0", "否"):
        return False
    return default


def as_name_list(value: Any) -> List[str]:
    """把 model 输出的国家/地区字段统一成字符串列表（兼容 string / list / 逗号分隔）。"""
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        items = [safe_cell(v, "") for v in value]
    else:
        text = safe_cell(value, "")
        if not text:
            return []
        parts = re.split(r"[;；,，/]| and ", text)
        items = [p.strip() for p in parts]
    out: List[str] = []
    for item in items:
        item = strip_enum_suffix(item)
        if item and item.upper() not in ("UNKNOWN", "UNK", "NONE", "NA", "N/A"):
            out.append(item)
    # 去重保序
    seen = set()
    uniq = []
    for item in out:
        k = item.lower()
        if k not in seen:
            seen.add(k)
            uniq.append(item)
    return uniq


def join_list(items: Sequence[str], sep: str = "; ") -> str:
    return sep.join([i for i in items if i])


# WoS 地址字段形如：
#   "[Author1; Author2] Univ X, Dept Y, City, Peoples R China. [Author3] Univ Z, Dept W, City, USA."
# 用中括号标记作者分组，组间以 ". " 分隔。这里做保守拆分，只用于“减少重复调用/聚焦首个地址”，
# 不做任何地理推断。
_BRACKET_GROUP_RE = re.compile(r"\[[^\]]*\]")


def split_wos_addresses(text: Any, max_groups: int = 3) -> List[str]:
    """
    把 WoS 的 Addresses 字段拆成若干条地址文本（去掉作者分组中括号）。
    返回不超过 max_groups 条，按出现顺序。
    """
    raw = safe_cell(text, "")
    if not raw:
        return []

    # 以 ". " 切分，尽量保留带中括号的组
    parts = re.split(r"\.\s+(?=\[)", raw)
    if len(parts) == 1:
        # 没有中括号：按 ". " 粗切
        parts = re.split(r"\.\s+", raw)

    out: List[str] = []
    for part in parts:
        cleaned = _BRACKET_GROUP_RE.sub(" ", part)
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" .;,|")
        if cleaned and cleaned.lower() not in ("nan", "none"):
            out.append(cleaned)
        if len(out) >= max_groups:
            break
    return out


def shorten_text(text: Any, max_chars: int = 1200) -> str:
    """压缩长文本用于提示词输入：保留前段，避免把整段参考文献一起送进去。"""
    s = safe_cell(text, "")
    if not s:
        return ""
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= max_chars else s[:max_chars]


# =============================================================================
# 5. 运行清单（可复现性审计）
# =============================================================================
class RunManifest:
    """
    记录一次脚本运行的版本信息：
    脚本名 / 时间戳 / provider / model / temperature / prompt 版本 / schema 版本 /
    行数 / 成功失败数。落盘为 CSV，便于写进论文 Supplementary。
    """

    def __init__(self, script_name: str, prompt_version: str = "", schema_version: str = "", settings: Optional[Settings] = None):
        self.s = settings or load_settings()
        self.script_name = script_name
        self.prompt_version = prompt_version
        self.schema_version = schema_version
        self.started_at = datetime.now().isoformat(timespec="seconds")
        self.finished_at = ""
        self.rows_total = 0
        self.rows_ok = 0
        self.rows_failed = 0
        self.rows_skipped = 0
        self.api_calls = 0
        self.api_failures = 0

    def to_row(self) -> Dict[str, Any]:
        return {
            "script": self.script_name,
            "prompt_version": self.prompt_version,
            "schema_version": self.schema_version,
            "started_at": self.started_at,
            "finished_at": self.finished_at or datetime.now().isoformat(timespec="seconds"),
            "provider": self.s.provider,
            "model": self.s.model,
            "temperature": self.s.temperature,
            "json_schema_requested": self.s.use_json_schema,
            "rows_total": self.rows_total,
            "rows_ok": self.rows_ok,
            "rows_failed": self.rows_failed,
            "rows_skipped": self.rows_skipped,
            "api_calls": self.api_calls,
            "api_failures": self.api_failures,
        }

    def append(self, path: Optional[os.PathLike | str] = None) -> Optional[Path]:
        import pandas as pd

        target = Path(path) if path else (self.s.base_dir / "run_manifest.csv")
        try:
            row_df = pd.DataFrame([self.to_row()])
            if target.exists():
                old = pd.read_csv(target)
                out = pd.concat([old, row_df], ignore_index=True)
            else:
                out = row_df
            out.to_csv(target, index=False, encoding="utf-8-sig")
            return target
        except Exception:
            return None


# =============================================================================
# 6. 命令行公共参数
# =============================================================================
def add_common_args(parser) -> None:
    parser.add_argument("--input", "-i", default=None, help="覆盖输入文件路径（默认取 .env 配置）")
    parser.add_argument("--output", "-o", default=None, help="覆盖输出文件路径（默认取 .env 配置）")
    parser.add_argument("--limit", type=int, default=0, help="只处理前 N 行（0=全部，用于预实验）")
    parser.add_argument("--sample", type=int, default=0, help="随机抽样 N 行（0=不抽样）")
    parser.add_argument("--seed", type=int, default=20240101, help="抽样随机种子")
    parser.add_argument("--workers", type=int, default=1, help="并发线程数（1=串行）")
    parser.add_argument("--force", action="store_true", help="忽略断点，重跑所有行")
    parser.add_argument("--dry-run", action="store_true", help="不调用 API，只检查输入与列名")


def resolve_io(args, default_input_key: str, default_output_key: str) -> Tuple[Path, Path, "Settings"]:
    s = load_settings()
    in_path = Path(args.input) if args.input else s.path(default_input_key)
    out_path = Path(args.output) if args.output else s.path(default_output_key)
    return in_path, out_path, s


def select_rows(df, args) -> List[int]:
    """按 --sample / --limit 返回要处理的行索引（保序）。"""
    import random as _random

    idx = list(range(len(df)))
    if getattr(args, "sample", 0) and args.sample < len(idx):
        rng = _random.Random(getattr(args, "seed", 20240101))
        idx = sorted(rng.sample(idx, args.sample))
    if getattr(args, "limit", 0):
        idx = idx[: args.limit]
    return idx


def checkpoint_path(settings: Settings, key: str) -> Path:
    return settings.checkpoint_file.parent / f"{settings.checkpoint_file.stem}_{key}.csv"
