# -*- coding: utf-8 -*-
"""
pdf_text.py —— 全文 PDF 文本提取（供 stepFT2.fulltext_adjudication.py 使用）

支持多种后端，按可用性自动选择：
    1. 外部命令行工具（最快、最稳）：pdftotext（poppler）、mutool
       通过环境变量 PDF_UTILITY 显式指定，例如
           PDF_UTILITY=pdftotext
    2. Python 库：pymupdf(fitz) / pypdf / pdfminer.six
    3. 无可用后端时给出明确报错，而不是静默返回空文本

可选页码范围（用于只送前 N 页：Objectives / Study area / Methods 通常足够）
通过环境变量控制：PDF_MAX_CHARS（默认 120000）、PDF_MAX_PAGES（0=全部）
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Tuple

__all__ = ["extract_text", "available_backends", "normalize_pdf_text"]

_BACKEND_CACHE: Optional[str] = None


def available_backends() -> list:
    backends = []
    for exe in ("pdftotext", "mutool"):
        if shutil.which(exe):
            backends.append(f"cli:{exe}")
    for mod in ("fitz", "pypdf", "PyPDF2", "pdfminer"):
        try:
            __import__(mod)
            backends.append(f"py:{mod}")
        except Exception:
            continue
    configured = os.environ.get("PDF_UTILITY", "").strip()
    if configured and shutil.which(configured):
        backends.insert(0, f"cli:{configured}")
    return backends


def normalize_pdf_text(text: str) -> str:
    """清理 PDF 抽取结果：合并硬换行、压缩空白、去掉页码噪声。"""
    if not text:
        return ""
    text = text.replace("\r", "\n")
    text = re.sub(r"-\n(?=[a-z])", "", text)          # 连字符断词
    text = re.sub(r"\n{2,}", "\n\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n\s*\d{1,4}\s*\n", "\n", text)   # 独立行页码
    return text.strip()


def _extract_cli(exe: str, pdf_path: Path, max_pages: int = 0) -> str:
    cmd = [exe, "-layout" if exe.endswith("pdftotext") else "-F", str(pdf_path), "-"]
    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=180)
        if proc.returncode == 0 and proc.stdout:
            text = proc.stdout.decode("utf-8", errors="ignore")
            if max_pages:
                pages = text.split("\f")
                text = "\f".join(pages[:max_pages])
            return normalize_pdf_text(text)
    except Exception:
        pass
    return ""


def _extract_pymupdf(pdf_path: Path, max_pages: int = 0) -> str:
    try:
        import fitz  # type: ignore

        doc = fitz.open(str(pdf_path))
        parts = []
        limit = len(doc) if not max_pages else min(max_pages, len(doc))
        for i in range(limit):
            parts.append(doc.load_page(i).get_text("text"))
        doc.close()
        return normalize_pdf_text("\n".join(parts))
    except Exception:
        return ""


def _extract_pypdf(pdf_path: Path, max_pages: int = 0) -> str:
    for modname in ("pypdf", "PyPDF2"):
        try:
            module = __import__(modname)
            reader = module.PdfReader(str(pdf_path))
            limit = len(reader.pages) if not max_pages else min(max_pages, len(reader.pages))
            parts = []
            for i in range(limit):
                try:
                    parts.append(reader.pages[i].extract_text() or "")
                except Exception:
                    continue
            return normalize_pdf_text("\n".join(parts))
        except Exception:
            continue
    return ""


def _extract_pdfminer(pdf_path: Path, max_pages: int = 0) -> str:
    try:
        from pdfminer.high_level import extract_text as pm_extract  # type: ignore

        kwargs = {}
        if max_pages:
            kwargs["maxpages"] = max_pages
        return normalize_pdf_text(pm_extract(str(pdf_path), **kwargs))
    except Exception:
        return ""


def extract_text(pdf_path: os.PathLike | str, max_chars: int = 120000, max_pages: int = 0) -> Tuple[str, str]:
    """
    提取 PDF 文本。

    返回 (text, backend)。失败时返回 ("", "none")。
    text 会被截断到 max_chars。
    """
    global _BACKEND_CACHE
    path = Path(pdf_path)
    if not path.exists():
        return "", "missing"

    candidates = []
    configured = os.environ.get("PDF_UTILITY", "").strip()
    if configured and shutil.which(configured):
        candidates.append(("cli", configured))
    if shutil.which("pdftotext"):
        candidates.append(("cli", "pdftotext"))
    candidates += [("fitz", "fitz"), ("pypdf", "pypdf"), ("pdfminer", "pdfminer")]

    for kind, name in candidates:
        if kind == "cli":
            text = _extract_cli(name, path, max_pages)
        elif name == "fitz":
            text = _extract_pymupdf(path, max_pages)
        elif name == "pypdf":
            text = _extract_pypdf(path, max_pages)
        else:
            text = _extract_pdfminer(path, max_pages)
        if text and len(text) > 200:
            _BACKEND_CACHE = name
            return text[:max_chars], name

    return "", "none"
