# LLM Prompt Catalog

- Registry version: `registry-2024.1`
- Generated at: 2026-10-28T15:24:51
- Provider: `deepseek`
- Model: `deepseek-chat`
- Temperature: `0.0` (all classification tasks use 0)
- JSON Schema requested: `True`

| Step | Prompt version | JSON Schema | SHA1 (12) | Output columns |
|---|---|---|---|---|
| `relevance` | `P1-relevance-v2.0` | `esv_relevance_v2@P1-relevance-v2.0` | `22f90a21756c` | `relevance_class`, `evidence`, `confidence` |
| `study_area` | `P2-study-area-v2.0` | `study_area_v2@P2-study-area-v2.0` | `74b738d47bbe` | `study_area_type`, `study_area_name`, `country`, `additional_areas`, `evidence`, `confidence` |
| `affiliation` | `P6-affiliation-v2.0` | `affiliation_v2@P6-affiliation-v2.0` | `06a4a3202a45` | `country`, `region`, `city`, `normalized_location`, `evidence`, `confidence` |
| `location_norm` | `P7-location-norm-v2.0` | `location_norm_v2@P7-location-norm-v2.0` | `4b31732259cc` | `original_name`, `normalized_name`, `geographic_level`, `country`, `region`, `ambiguity_flag`, `confidence` |
| `ecosystem` | `P3-ecosystem-v2.0` | `ecosystem_v2@P3-ecosystem-v2.0` | `9ac14cea5322` | `ecosystem_primary`, `ecosystem_subtype`, `evidence`, `confidence` |
| `esv_service` | `P4-esv-service-v2.0` | `esv_service_v2@P4-esv-service-v2.0` | `ff8ad7406cb9` | `service_primary`, `service_subtype`, `evidence`, `confidence` |
| `orientation` | `P5-orientation-v2.0` | `orientation_v2@P5-orientation-v2.0` | `70c8aa6636fb` | `orientation`, `application_type`, `evidence`, `confidence` |
| `fulltext_adjudication` | `P8-fulltext-adjudication-v2.0` | `fulltext_adjudication_v2@P8-fulltext-adjudication-v2.0` | `8c758ebd2054` | `target_variable`, `final_label`, `final_subtype_or_level`, `agree_with_abstract_only_label`, `evidence_location`, `evidence`, `confidence` |

## Notes for the manuscript

- All prompts instruct the model to use ONLY the provided title/abstract (or full text for adjudication) and to return `UNKNOWN` / `UNCERTAIN` instead of guessing.
- Author affiliation must never be used as the study area, and the study area must never be used to infer the author affiliation.
- Coordinates are never produced by the LLM: geographic names are normalized by the LLM (Prompt 6/7) and geocoded by an external gazetteer/geocoder (see `step7.gis_geocoding.py`).
- Model self-reported `confidence` is an audit field only; reliability must be quantified against the full-text gold standard (`validation_metrics.py`).
- API credentials are read from environment variables; none are stored in code or supplementary files.
