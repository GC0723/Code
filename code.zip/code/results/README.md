# Generated results directory

Pipeline tables, checkpoints, validation outputs, and geocoding caches are written here by default. No generated research results are distributed with the code release.

For a paper archive, preserve only the outputs and audit files that you are legally and ethically permitted to share, and record the exact run configuration in `run_manifest.csv` and the publication checklist.
