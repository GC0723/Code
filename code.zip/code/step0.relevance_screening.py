# -*- coding: utf-8 -*-
"""
Step 0 —— 研究相关性判定（Prompt 1 / P1-relevance-v2.0）★新增脚本

脚本名：step0.relevance_screening.py
原文件名：无（本脚本为新增；原版流水线没有相关性判定这一步）

用途
----
把 WoS 检索得到的原始语料逐篇判定为：
    VALUATION_OR_ACCOUNTING          明确做了经济/货币化估值或核算
    ECOSYSTEM_ASSESSMENT_NO_VALUATION 评估了生态系统（服务）但没有货币化估值
    OUT_OF_SCOPE                      与 ESV 无关

这一层直接支撑论文的 search strategy audit：可以报告原始检索命中量、
ESV 相关量以及被排除的原因分布，而不只报告最终分析样本量。

与旧代码的区别
--------------
1. 旧代码没有这一步（直接对所有命中文献抽 location/methods/conclusions）；
2. 新脚本 temperature=0，使用 JSON Schema + enum 约束，输出 evidence 供人工复核；
3. 无法判断时输出 OUT_OF_SCOPE 之外不再凭空推断，全部保留原文证据；
4. 支持断点续跑与 --sample 预实验。

输出列（写入 0_Relevance_out.xlsx，保留全部记录，供检索策略审计）
--------------------------------------------------------------
    relevance_class            三分类枚举
    relevance_evidence         支持该判定的原文片段/忠实转述
    relevance_confidence       high | medium | low
    relevance_model            模型名（复现用）
    relevance_prompt_version   提示词版本（复现用）
    relevance_run_at           处理时间

另外生成 ESV 子集数据库（step1~step8 的唯一输入）
-------------------------------------------------
    0_Corpus_ESV.xlsx          只保留 relevance_class == VALUATION_OR_ACCOUNTING 的记录，
                               并附 esv_filter_pass / source_corpus_n / esv_selection_rule 列。
    这一步相当于"重新生成一个数据库"：
        · 原始检索命中量 → 见 0_Relevance_out.xlsx（全量，审计用）
        · ESV 相关语料量 → 见 0_Corpus_ESV.xlsx（下游分析用）
    两个数字都要写进论文，检索策略才可复核。

用法
----
    python step0.relevance_screening.py                     # 全部语料
    python step0.relevance_screening.py --limit 200         # 先跑 200 篇预实验
    python step0.relevance_screening.py --sample 412 --seed 42
    python step0.relevance_screening.py --dry-run           # 只检查输入，不调用 API
    python step0.relevance_screening.py -i all.xlsx -o 0_Relevance_out.xlsx
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import P1_RELEVANCE_CLASSES, PROMPT_VERSIONS, SCHEMA_VERSIONS, get_prompt, get_system, get_user
from llm_utils import (
    ESV_KEEP_CLASS,
    add_common_args,
    as_confidence,
    as_text,
    find_column,
    get_client,
    is_blank,
    load_settings,
    normalize_enum_value,
    resolve_io,
    truncate,
    write_table,
    ABSTRACT_CANDIDATES,
    TITLE_CANDIDATES,
)

PROMPT_KEY = "relevance"
OUTPUT_COLUMNS = [
    "relevance_class",
    "relevance_evidence",
    "relevance_confidence",
    "relevance_model",
    "relevance_prompt_version",
    "relevance_run_at",
]


def main() -> None:
    settings = load_settings()
    ap = argparse.ArgumentParser(description="Step 0：ESV 文献相关性判定（Prompt 1）")
    add_common_args(ap)
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_INPUT_CORPUS", "PATH_STEP0_RELEVANCE")
    df_head = pd.read_excel(in_path, nrows=0) if in_path.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(in_path, nrows=0)

    title_col = find_column(df_head, TITLE_CANDIDATES)
    abs_col = find_column(df_head, ABSTRACT_CANDIDATES)
    if abs_col is None:
        raise SystemExit(f"在 {in_path.name} 中找不到摘要列，候选列名: {ABSTRACT_CANDIDATES}")
    if title_col is None:
        print(f"[警告] 找不到标题列，将只用摘要判定（候选中包含: {TITLE_CANDIDATES}）")

    print(f"输入: {in_path}")
    print(f"标题列: {title_col}   摘要列: {abs_col}")
    print(f"输出: {out_path}")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_chars = settings.max_abstract_chars
    run_stamp = datetime.now().isoformat(timespec="seconds")

    df_full = pd.read_excel(in_path) if in_path.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(in_path)

    def handler(df: pd.DataFrame, idx: int) -> dict:
        title = as_text(df.at[idx, title_col], "") if title_col else ""
        abstract = as_text(df.at[idx, abs_col], "")
        if is_blank(abstract) and is_blank(title):
            return {c: "" for c in OUTPUT_COLUMNS}

        rec = client.classify(
            system_prompt,
            get_user(PROMPT_KEY, title=truncate(title, 1000) or "N/A", abstract=truncate(abstract, max_chars) or "N/A"),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=500,
            required_keys=prompt["required_keys"],
        )
        if not rec.ok:
            return {
                "relevance_class": FAILED_SENTINEL,
                "relevance_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "relevance_confidence": "",
                "relevance_model": settings.model,
                "relevance_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "relevance_run_at": datetime.now().isoformat(timespec="seconds"),
            }

        data = rec.data
        return {
            "relevance_class": normalize_enum_value(data.get("relevance_class"), P1_RELEVANCE_CLASSES, "OUT_OF_SCOPE"),
            "relevance_evidence": as_text(data.get("evidence"), "")[:1000],
            "relevance_confidence": as_confidence(data.get("confidence")),
            "relevance_model": settings.model,
            "relevance_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "relevance_run_at": datetime.now().isoformat(timespec="seconds"),
        }

    res = run_stage(
        stage_key="step0_relevance",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="relevance_class",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt1 相关性判定",
        client=client,
    )

    # 相关性与检索策略审计摘要
    if not args.dry_run:
        try:
            out_df = pd.read_excel(out_path)
            counts = out_df["relevance_class"].fillna("").astype(str).value_counts()
            total = len(out_df)
            print("\n=== 检索策略审计摘要（可直接写入论文） ===")
            for cls in P1_RELEVANCE_CLASSES + [FAILED_SENTINEL]:
                n = int(counts.get(cls, 0))
                print(f"  {cls:34s} {n:6d}  ({n / max(total, 1) * 100:5.2f}%)")
            print(f"  {'TOTAL':34s} {total:6d}")
            if int(counts.get(FAILED_SENTINEL, 0)) > 0:
                print("  [提示] 存在失败行，直接重跑本脚本即可续接（已完成行不会重复计费）。")

            # ---- 生成下游统一使用的 ESV 子集数据库（方案：step1~step8 的输入） ----
            corpus_path = emit_esv_corpus(out_df, settings, args)
        except Exception as exc:
            print(f"[警告] 无法生成摘要: {exc}")


def emit_esv_corpus(out_df: "pd.DataFrame", settings, args) -> None:
    """
    从 step0 的全量结果中筛出 ESV 子集，写成下游唯一入口数据库。

    设计说明
    --------
    - `0_Relevance_out.xlsx` 保留 **全部** 记录（含 OUT_OF_SCOPE），
      它是"检索策略审计"的凭证：n_hits / n_esv / 排除比例都能复核；
    - `0_Corpus_ESV.xlsx` 只保留 relevance_class == VALUATION_OR_ACCOUNTING 的记录，
      step1~step8 一律读它，保证所有步骤的样本与分母完全一致；
    - 若存在 __FAILED__ 行则拒绝生成子集（否则会静默丢样本），提示先重跑 step0。
    """
    from llm_utils import ESV_KEEP_CLASS

    col = out_df["relevance_class"].fillna("").astype(str)
    n_failed = int((col == FAILED_SENTINEL).sum())
    n_hits = len(out_df)
    n_esv = int((col == ESV_KEEP_CLASS).sum())
    n_excluded = int((col == "ECOSYSTEM_ASSESSMENT_NO_VALUATION").sum())
    n_oos = int((col == "OUT_OF_SCOPE").sum())

    if n_failed:
        print(f"\n[停止] 有 {n_failed} 行判定失败（__FAILED__），未生成 ESV 子集数据库。")
        print("       请直接重跑 step0（已完成行不会重复计费），成功后再继续 step1。")
        return

    corpus_path = Path(args.output).with_name("0_Corpus_ESV.xlsx") if args.output else settings.path("PATH_STEP0_CORPUS")

    sub = out_df[col == ESV_KEEP_CLASS].reset_index(drop=True)
    sub["esv_filter_pass"] = True
    sub["source_corpus_n"] = n_hits
    sub["esv_selection_rule"] = f"relevance_class == {ESV_KEEP_CLASS} (step0)"
    sub["esv_selection_time"] = datetime.now().isoformat(timespec="seconds")

    write_table(sub, corpus_path)

    print("\n=== ESV 子集数据库（step1~step8 的唯一输入） ===")
    print(f"  文件: {corpus_path}")
    print(f"  原始检索命中:      {n_hits:6d}")
    print(f"  其中 ESV 估值/核算: {n_esv:6d}  ({n_esv / max(n_hits, 1) * 100:5.2f}%)  -> 进入下游分析")
    print(f"  评估但未货币化:     {n_excluded:6d}   (按方案保留在审计文件中，不进主分析)")
    print(f"  完全无关:           {n_oos:6d}")
    print("\n  后续步骤请统一读取该文件：")
    print("    python step1.study_area_extraction.py      --input 0_Corpus_ESV.xlsx")
    print("    python step2.affiliation_geolocation_llm.py --input 0_Corpus_ESV.xlsx")
    print("  未显式传 --input 时，各步骤默认读取 .env 的 PATH_STEP0_CORPUS，同样是这个文件。")
    print("  [复现提示] 论文里请同时报告检索命中量与 ESV 子集量，并说明筛选规则。")
    return corpus_path


if __name__ == "__main__":
    sys.exit(main())
