# -*- coding: utf-8 -*-
"""
脚本名：step1.study_area_extraction.py
原文件名：All_abstract_output1_Xlsx.py（本脚本是其重写版）

Step 1 —— 研究区域提取（Prompt 2 / P2-study-area-v2.0）

本脚本替换旧版“一次抽取 research_location + research_methods + research_conclusions”的做法：

    删除  research_methods     —— 定义过宽，与出版记录错配，审稿人必问（方案第一节）
    删除  research_conclusions —— LLM 生成的结论不能作为论文结论变量（方案第二十节）
    升级  research_location    —— 改为严谨的 study area 提取，区分
                                 研究区域 / 对比区域 / 全球或多国 / 无法判定

输出列（新增，不覆盖旧列）
--------------------------
    study_area_type          SITE | CITY | ... | GLOBAL | UNKNOWN
    study_area_name          最具体的、明确支持的地理名称（无法判定为 UNKNOWN）
    study_area_country       明确支持的国家（多个用 "; " 连接）
    study_area_additional    明确纳入研究设计的额外区域（多个用 "; " 连接）
    study_area_evidence      支持判定的原文片段/忠实转述（人工审核用）
    study_area_confidence    high | medium | low
    study_area_model         模型名（复现用）
    study_area_prompt_version 提示词版本（复现用）
    study_area_run_at        处理时间

同时向后兼容：把 study_area_name 同步写入 research_location_v2 列，
便于与旧版结果逐条对比（Prompt 预实验需要）。

关键规则（与方案一致）
----------------------
1. 绝不用作者机构推断研究区域；
2. 只作为背景/对比出现的国家不算研究区域；
3. 能判到城市就不升格成国家，只有国家就不要臆造城市；
4. 确实判不出来就输出 UNKNOWN，而不是猜。

输入库（重要）
--------------
本步骤读 step0 生成的 **ESV 子集数据库**（默认 `0_Corpus_ESV.xlsx`，
即 `PATH_STEP0_CORPUS`），而不是原始全量检索结果。这样 step1~step8 的样本量
与分母完全一致。若该文件不存在或未经过 step0 过滤，脚本会直接报错，
提示先运行 `step0.relevance_screening.py`（除非在 .env 中显式关闭
`LLM_STRICT_INPUT`）。

用法
----
    python step1.study_area_extraction.py --dry-run
    python step1.study_area_extraction.py --limit 200
    python step1.study_area_extraction.py
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import P2_AREA_LEVELS, PROMPT_VERSIONS, SCHEMA_VERSIONS, get_prompt, get_system, get_user
from llm_utils import (
    ABSTRACT_CANDIDATES,
    TITLE_CANDIDATES,
    add_common_args,
    as_confidence,
    as_name_list,
    as_text,
    find_column,
    get_client,
    is_blank,
    join_list,
    load_settings,
    normalize_enum_value,
    require_esv_corpus,
    resolve_io,
    truncate,
)

PROMPT_KEY = "study_area"
OUTPUT_COLUMNS = [
    "study_area_type",
    "study_area_name",
    "study_area_country",
    "study_area_additional",
    "study_area_evidence",
    "study_area_confidence",
    "study_area_model",
    "study_area_prompt_version",
    "study_area_run_at",
    "research_location_v2",  # 兼容旧列名，便于新旧 prompt 逐条对比
]


def _detect_duplicates(df: pd.DataFrame, title_col: str | None, threshold: float = 0.95, max_scan: int = 30000):
    """
    轻量重复记录检测（标题归一化后近似比对）。
    仅做提示，不删除任何记录——是否去重应在方法学中明确说明。
    """
    if not title_col:
        return []
    import re
    from difflib import SequenceMatcher

    norm = (
        df[title_col]
        .fillna("")
        .astype(str)
        .str.lower()
        .str.replace(r"[^a-z0-9\u4e00-\u9fff]+", " ", regex=True)
        .str.strip()
    )
    seen: dict = {}
    dups = []
    for i, (key, raw) in enumerate(zip(norm.tolist(), df[title_col].fillna("").astype(str).tolist())):
        if not key:
            continue
        if key in seen:
            dups.append((seen[key], i, raw))
            continue
        seen[key] = i
        if i > max_scan:
            break

    # 近似重复（仅在前 3000 条内做，避免 O(n^2) 过慢）
    keys = [k for k in norm.tolist()[:3000] if k]
    for a in range(len(keys)):
        for b in range(a + 1, len(keys)):
            if abs(len(keys[a]) - len(keys[b])) > 25:
                continue
            if SequenceMatcher(None, keys[a], keys[b]).ratio() >= threshold:
                dups.append((a, b, "near-duplicate"))
    return dups


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 1：研究区域提取（Prompt 2）")
    add_common_args(ap)
    ap.add_argument("--no-dup-check", action="store_true", help="跳过重复记录检测")
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP0_CORPUS", "PATH_STEP1_ABSTRACT")
    # 输入库守卫：必须建立在 step0 生成的 ESV 子集数据库上。
    # 若用户显式传了 --input，则尊重用户选择（但仍会检查是否含 relevance_class）；
    # 若没传，则默认读 PATH_STEP0_CORPUS，找不到就报错，绝不静默回退到全量语料。
    in_path = require_esv_corpus(in_path, script_name=Path(__file__).name)

    head = pd.read_excel(in_path, nrows=0)
    title_col = find_column(head, TITLE_CANDIDATES)
    abs_col = find_column(head, ABSTRACT_CANDIDATES)
    if abs_col is None:
        raise SystemExit(f"在 {in_path.name} 中找不到摘要列，候选列名: {ABSTRACT_CANDIDATES}")
    if title_col is None:
        print(f"[警告] 找不到标题列，将只用摘要提取研究区域")

    print(f"输入: {in_path}")
    print(f"标题列: {title_col}   摘要列: {abs_col}")
    print(f"输出: {out_path}")

    if not args.no_dup_check and not args.dry_run:
        try:
            full = pd.read_excel(in_path)
            dups = _detect_duplicates(full, title_col)
            if dups:
                print(f"[重复检测] 发现 {len(dups)} 组疑似重复记录（不自动删除，请在方法学中说明去重规则）")
                for a, b, t in dups[:5]:
                    print(f"    row {a} <-> row {b}: {t[:90]}")
        except Exception as exc:
            print(f"[重复检测] 跳过（{exc}）")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_chars = settings.max_abstract_chars

    def handler(df: pd.DataFrame, idx: int) -> dict:
        title = as_text(df.at[idx, title_col], "") if title_col else ""
        abstract = as_text(df.at[idx, abs_col], "")
        if is_blank(abstract) and is_blank(title):
            return {"study_area_type": "UNKNOWN", "study_area_name": "UNKNOWN"}

        rec = client.classify(
            system_prompt,
            get_user(PROMPT_KEY, title=truncate(title, 1000) or "N/A", abstract=truncate(abstract, max_chars) or "N/A"),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=600,
            required_keys=prompt["required_keys"],
        )
        stamp = datetime.now().isoformat(timespec="seconds")
        if not rec.ok:
            return {
                "study_area_type": FAILED_SENTINEL,
                "study_area_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "study_area_model": settings.model,
                "study_area_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "study_area_run_at": stamp,
            }

        data = rec.data
        area_type = normalize_enum_value(data.get("study_area_type"), P2_AREA_LEVELS, "UNKNOWN")
        area_name = as_text(data.get("study_area_name"), "UNKNOWN")
        countries = as_name_list(data.get("country"))
        additional = as_name_list(data.get("additional_areas"))

        # 一致性约束：GLOBAL 不应再有具体国家；UNKNOWN 不应再有具体名称
        if area_type == "GLOBAL":
            pass
        if area_type == "UNKNOWN":
            area_name = "UNKNOWN"

        return {
            "study_area_type": area_type,
            "study_area_name": area_name,
            "study_area_country": join_list(countries),
            "study_area_additional": join_list(additional),
            "study_area_evidence": as_text(data.get("evidence"), "")[:1000],
            "study_area_confidence": as_confidence(data.get("confidence")),
            "study_area_model": settings.model,
            "study_area_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "study_area_run_at": stamp,
            "research_location_v2": area_name,
        }

    res = run_stage(
        stage_key="step1_study_area",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="study_area_type",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt2 研究区域提取",
        client=client,
    )

    if not args.dry_run:
        try:
            out_df = pd.read_excel(out_path)
            print("\n=== 研究区域层级分布（空间分析核心变量） ===")
            vc = out_df["study_area_type"].fillna("").astype(str).value_counts()
            total = len(out_df)
            for k, v in vc.items():
                print(f"  {k:20s} {int(v):6d}  ({int(v) / max(total, 1) * 100:5.2f}%)")
            n_unk = int((out_df["study_area_name"].fillna("").astype(str) == "UNKNOWN").sum())
            print(f"  名称无法判定(UNKNOWN): {n_unk} ({n_unk / max(total, 1) * 100:.2f}%)")
            print("  [提示] 论文中应报告 UNKNOWN 比例；地理编码步骤会将其排除并单独说明。")
        except Exception as exc:
            print(f"[警告] 无法生成分布摘要: {exc}")


if __name__ == "__main__":
    sys.exit(main())
