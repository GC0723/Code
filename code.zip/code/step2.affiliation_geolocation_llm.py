# -*- coding: utf-8 -*-
"""
脚本名：step2.affiliation_geolocation_llm.py
原文件名：All_Affiliations_output2_Xlsx.py（本脚本是其重写版）

Step 2 —— 作者机构地理归一化（Prompt 6 / P6-affiliation-v2.0）

本脚本最重要的修改（方案第十五节）
----------------------------------
旧代码：把 Address + Affiliation 拼在一起，让 LLM 直接“推断”出 lat/lon。
新代码：**LLM 只负责理解文本，不再产生任何坐标。**

    旧输出列：Geo_Country / Geo_Region / Geo_Lat / Geo_Lon / Geo_Confidence
    新输出列：affil_country / affil_region / affil_city / affil_normalized_location /
              affil_evidence / affil_confidence / affil_model / affil_prompt_version /
              affil_run_at  （另有 affil_multi_flag 标记一条记录里出现多个机构国家）

坐标一律由 Step 7 的 `step7.gis_geocoding.py`（gazetteer / GeoPy / Nominatim / GADM）
产出，并强制记录坐标来源（source），做到“理解文本的是 LLM，确定坐标的是 GIS”。

另外的修改
----------
1. temperature=0（旧代码 Geo 调用虽为 0，但分类调用是 0.2；现全部统一为 0）；
2. 删除旧代码里那份硬编码的 QUICK_RULES（北京=39.9042 之类）：
   这些坐标既无来源、又会污染机构位置，新版改为在 geocoder 里用可审计的地名词典；
3. 不再把国家级结果硬写成某个城市的坐标；
4. JSON Schema + enum 约束 confidence，evidence 必填；
5. 断点续跑、失败标记、run_manifest 审计。

输入库（重要）
--------------
读 step0 生成的 **ESV 子集数据库**（默认 `0_Corpus_ESV.xlsx`，即 `PATH_STEP0_CORPUS`）。
该文件由 step0 从原始语料中筛出 `VALUATION_OR_ACCOUNTING` 的记录，
WoS 原始字段（含 Addresses / Affiliations）随行保留，因此本步骤可以直接取用。
若文件不存在或未经 step0 过滤，脚本会报错并提示先运行 step0。

用法
----
    python step2.affiliation_geolocation_llm.py --dry-run
    python step2.affiliation_geolocation_llm.py --limit 200
    python step2.affiliation_geolocation_llm.py
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import PROMPT_VERSIONS, SCHEMA_VERSIONS, get_prompt, get_system, get_user
from llm_utils import (
    AFFILIATION_CANDIDATES,
    ADDRESS_CANDIDATES,
    add_common_args,
    as_confidence,
    as_text,
    find_column,
    get_client,
    is_blank,
    load_settings,
    require_esv_corpus,
    resolve_io,
    safe_cell,
    shorten_text,
    split_wos_addresses,
)

PROMPT_KEY = "affiliation"
OUTPUT_COLUMNS = [
    "affil_country",
    "affil_region",
    "affil_city",
    "affil_normalized_location",
    "affil_evidence",
    "affil_confidence",
    "affil_multi_flag",
    "affil_source_field",
    "affil_model",
    "affil_prompt_version",
    "affil_run_at",
]

UNKNOWN = "UNKNOWN"


def _collect_affiliation_text(df: pd.DataFrame, idx: int, address_col, affil_col, max_groups: int = 3) -> str:
    """把一条记录的地址与机构拼接成送给 LLM 的文本（不含任何作者姓名推断）。"""
    chunks = []
    if address_col:
        addrs = split_wos_addresses(df.at[idx, address_col], max_groups=max_groups)
        if addrs:
            chunks.append("Address: " + " | ".join(addrs))
        else:
            raw = shorten_text(df.at[idx, address_col], 900)
            if raw:
                chunks.append("Address: " + raw)
    if affil_col:
        raw = shorten_text(df.at[idx, affil_col], 900)
        if raw:
            chunks.append("Affiliation: " + raw)
    return "\n".join(chunks)


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 2：作者机构地理归一化（Prompt 6，LLM 不产出坐标）")
    add_common_args(ap)
    ap.add_argument("--max-address-groups", type=int, default=3, help="每条记录最多送入几个地址分组")
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP0_CORPUS", "PATH_STEP2_AFFILIATION")
    # 输入库守卫：机构归一化同样只对 ESV 子集做，保证与 step1/3~8 样本一致。
    # 注意：ESV 子集数据库由 step0 从原始语料筛选而来，因此
    # Addresses / Affiliations 等 WoS 原始字段都会随行一起保留下来。
    in_path = require_esv_corpus(in_path, script_name=Path(__file__).name)
    head = pd.read_excel(in_path, nrows=0)

    address_col = find_column(head, ADDRESS_CANDIDATES)
    affil_col = find_column(head, AFFILIATION_CANDIDATES)
    if address_col is None and affil_col is None:
        raise SystemExit(
            f"输入表 {in_path.name} 中找不到 Addresses / Affiliations 列，候选: "
            f"{ADDRESS_CANDIDATES} / {AFFILIATION_CANDIDATES}"
        )
    print(f"输入: {in_path}")
    print(f"地址列: {address_col}   机构列: {affil_col}")
    print(f"输出: {out_path}")
    print("[说明] 本步骤不产生任何坐标；坐标由 Step 7 step7.gis_geocoding.py 产出。")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_groups = max(1, args.max_address_groups)

    def handler(df: pd.DataFrame, idx: int) -> dict:
        text = _collect_affiliation_text(df, idx, address_col, affil_col, max_groups)
        source_field = "+".join([c for c in (address_col, affil_col) if c])
        stamp = datetime.now().isoformat(timespec="seconds")
        if is_blank(text):
            return {
                "affil_country": UNKNOWN,
                "affil_region": UNKNOWN,
                "affil_city": UNKNOWN,
                "affil_normalized_location": UNKNOWN,
                "affil_evidence": "无地址/机构字段内容",
                "affil_confidence": "low",
                "affil_multi_flag": False,
                "affil_source_field": source_field,
                "affil_model": settings.model,
                "affil_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "affil_run_at": stamp,
            }

        rec = client.classify(
            system_prompt,
            get_user(PROMPT_KEY, affiliation_text=text),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=500,
            required_keys=prompt["required_keys"],
        )
        if not rec.ok:
            return {
                "affil_country": FAILED_SENTINEL,
                "affil_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "affil_source_field": source_field,
                "affil_model": settings.model,
                "affil_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "affil_run_at": stamp,
            }

        data = rec.data
        country = as_text(data.get("country"), UNKNOWN)
        region = as_text(data.get("region"), UNKNOWN)
        city = as_text(data.get("city"), UNKNOWN)
        normalized = as_text(data.get("normalized_location"), UNKNOWN)

        # 多机构提示：地址字段里出现多个 ". " 分组或文本里出现多个国家名，只做提示，不擅自取舍
        multi = False
        raw_address = safe_cell(df.at[idx, address_col], "") if address_col else ""
        groups = split_wos_addresses(raw_address, max_groups=5)
        if len(groups) > 1:
            multi = True
        if text.count("|") >= 2:
            multi = True

        return {
            "affil_country": country,
            "affil_region": region,
            "affil_city": city,
            "affil_normalized_location": normalized,
            "affil_evidence": as_text(data.get("evidence"), "")[:1000],
            "affil_confidence": as_confidence(data.get("confidence")),
            "affil_multi_flag": multi,
            "affil_source_field": source_field,
            "affil_model": settings.model,
            "affil_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "affil_run_at": stamp,
        }

    res = run_stage(
        stage_key="step2_affiliation",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="affil_country",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt6 机构地理归一化",
        client=client,
    )

    if not args.dry_run:
        try:
            out_df = pd.read_excel(out_path)
            total = max(len(out_df), 1)
            unk = int((out_df["affil_country"].fillna("").astype(str).str.upper() == UNKNOWN).sum())
            multi = int(out_df["affil_multi_flag"].fillna(False).astype(bool).sum())
            print("\n=== 机构地理归一回执 ===")
            print(f"  国家无法判定(UNKNOWN): {unk} ({unk / total * 100:.2f}%)")
            print(f"  疑似多机构记录: {multi} ({multi / total * 100:.2f}%)  <- 距离分析需做敏感性检验")
            print("  下一步: python step7.gis_geocoding.py  (LLM 不产出坐标，坐标由 GIS/geocoder 给出)")
        except Exception as exc:
            print(f"[警告] 无法生成摘要: {exc}")


if __name__ == "__main__":
    sys.exit(main())
