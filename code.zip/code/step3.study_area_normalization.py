# -*- coding: utf-8 -*-
"""
脚本名：step3.study_area_normalization.py
原文件名：All_Location_output3_Xlsx.py（本脚本是其重写版）

Step 3 —— 研究区域标准化（Prompt 7 / P7-location-norm-v2.0）

本脚本最重要的修改（方案第十六节）
----------------------------------
旧代码：把“研究区域文本”丢给 DeepSeek，让它直接给出 country / region / lat / lon。
新代码：**LLM 只做地理实体归一化，明确禁止给出坐标。**

    LLM 负责：original_name / normalized_name / geographic_level / country /
              region / ambiguity_flag
    GIS 负责：真实坐标（Step 7 step7.gis_geocoding.py：gazetteer + GeoPy/Nominatim + GADM）

这样做的原因：
1. LLM 生成的坐标没有来源、不可复现、也无法通过审稿人核查；
2. 距离分析（作者—研究区距离）依赖坐标质量，必须用可追溯的地理编码器；
3. 旧代码里的 QUICK_RULES（Beijing=39.9042 等）既无来源，也会把“研究区域”
   误当成某个固定点，新版已删除，改为可审计的地名词典。

输出列
------
    loc_original_name        输入的研究区域原文
    loc_normalized_name      归一化后的规范名称（模糊则标记，不臆造）
    loc_geographic_level     SITE | CITY | ... | GLOBAL | UNKNOWN
    loc_country              明确支持的国家（多个用 "; " 连接）
    loc_region               明确支持的行政区（多个用 "; " 连接）
    loc_ambiguity_flag       名称存在歧义 -> True（距离敏感性分析中单列报告）
    loc_evidence             支持判定的输入片段
    loc_confidence           high | medium | low
    loc_model / loc_prompt_version / loc_run_at

兼容列（仅作占位，不再写入 LLM 坐标）
------------------------------------
    Loc_Country / Loc_Region / Loc_Confidence  -> 仍写入归一化结果，便于沿用旧表结构
    Loc_Lat / Loc_Lon                          -> 一律留空（坐标见 Step 7 的 geo_llm_* 列）

用法
----
    python step3.study_area_normalization.py --dry-run
    python step3.study_area_normalization.py --limit 200
    python step3.study_area_normalization.py
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import P2_AREA_LEVELS, PROMPT_VERSIONS, SCHEMA_VERSIONS, get_prompt, get_system, get_user
from llm_utils import (
    add_common_args,
    as_bool,
    as_confidence,
    as_name_list,
    as_text,
    find_column,
    get_client,
    is_blank,
    join_list,
    load_settings,
    normalize_enum_value,
    require_esv_corpus,
    resolve_io,
    shorten_text,
)

PROMPT_KEY = "location_norm"

#: 研究区域文本的候选列（新列优先，兼容旧列）
AREA_NAME_CANDIDATES = (
    "study_area_name",
    "research_location_v2",
    "research_location",
    "Study area",
    "study_area",
)
COUNTRY_HINT_CANDIDATES = ("study_area_country",)

OUTPUT_COLUMNS = [
    "loc_original_name",
    "loc_normalized_name",
    "loc_geographic_level",
    "loc_country",
    "loc_region",
    "loc_ambiguity_flag",
    "loc_evidence",
    "loc_confidence",
    "loc_model",
    "loc_prompt_version",
    "loc_run_at",
    # 兼容旧表结构
    "Loc_Country",
    "Loc_Region",
    "Loc_Lat",
    "Loc_Lon",
    "Loc_Confidence",
]


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 3：研究区域标准化（Prompt 7，不产出坐标）")
    add_common_args(ap)
    ap.add_argument(
        "--strict",
        action="store_true",
        help="强制校验输入确实来自 step0 的 ESV 子集数据库（step1/step2 已默认强制）",
    )
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP1_ABSTRACT", "PATH_STEP3_LOCATION")
    if getattr(args, "strict", False):
        # 可选硬校验：确认整条链路的输入确实源于 step0 的 ESV 子集数据库
        # （step1 / step2 已有强制守卫，此处用于人工复核时再确认一次）
        in_path = require_esv_corpus(in_path, script_name=Path(__file__).name)
    print(f"[输入库] {in_path.name}（应源自 step0 的 ESV 子集数据库 0_Corpus_ESV.xlsx）")
    head = pd.read_excel(in_path, nrows=0)

    area_col = find_column(head, AREA_NAME_CANDIDATES)
    country_col = find_column(head, COUNTRY_HINT_CANDIDATES)
    if area_col is None:
        raise SystemExit(
            f"输入表 {in_path.name} 中找不到研究区域列（应含 study_area_name / research_location），"
            f"请先运行 step1.study_area_extraction.py"
        )
    print(f"输入: {in_path}")
    print(f"研究区域列: {area_col}   国家提示列: {country_col}")
    print(f"输出: {out_path}")
    print("[说明] 本步骤不产出坐标；坐标由 Step 7 step7.gis_geocoding.py 产出并记录来源。")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)

    def handler(df: pd.DataFrame, idx: int) -> dict:
        raw_name = as_text(df.at[idx, area_col], "")
        country_hint = as_text(df.at[idx, country_col], "") if country_col else ""
        stamp = datetime.now().isoformat(timespec="seconds")

        if is_blank(raw_name) or raw_name.upper() in ("UNKNOWN", "UNK", "NONE", "N/A"):
            return {
                "loc_original_name": raw_name or "UNKNOWN",
                "loc_normalized_name": "UNKNOWN",
                "loc_geographic_level": "UNKNOWN",
                "loc_country": "",
                "loc_region": "",
                "loc_ambiguity_flag": True,
                "loc_evidence": "上游未提取到研究区域",
                "loc_confidence": "low",
                "loc_model": settings.model,
                "loc_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "loc_run_at": stamp,
                "Loc_Country": "UNK",
                "Loc_Region": "UNK",
                "Loc_Lat": "",
                "Loc_Lon": "",
                "Loc_Confidence": "low",
            }

        rec = client.classify(
            system_prompt,
            get_user(
                PROMPT_KEY,
                study_area_text=shorten_text(raw_name, 600),
                country_hint=shorten_text(country_hint, 200) or "(none)",
            ),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=500,
            required_keys=prompt["required_keys"],
        )
        if not rec.ok:
            return {
                "loc_original_name": raw_name,
                "loc_geographic_level": FAILED_SENTINEL,
                "loc_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "loc_model": settings.model,
                "loc_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "loc_run_at": stamp,
            }

        data = rec.data
        level = normalize_enum_value(data.get("geographic_level"), P2_AREA_LEVELS, "UNKNOWN")
        normalized = as_text(data.get("normalized_name"), "UNKNOWN")
        if level == "UNKNOWN":
            normalized = "UNKNOWN"
        countries = as_name_list(data.get("country"))
        regions = as_name_list(data.get("region"))
        ambiguous = as_bool(data.get("ambiguity_flag"), False)
        confidence = as_confidence(data.get("confidence"))

        return {
            "loc_original_name": as_text(data.get("original_name"), raw_name)[:300],
            "loc_normalized_name": normalized[:300],
            "loc_geographic_level": level,
            "loc_country": join_list(countries),
            "loc_region": join_list(regions),
            "loc_ambiguity_flag": ambiguous,
            "loc_evidence": as_text(data.get("evidence"), "")[:1000],
            "loc_confidence": confidence,
            "loc_model": settings.model,
            "loc_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "loc_run_at": stamp,
            "Loc_Country": countries[0] if countries else "UNK",
            "Loc_Region": regions[0] if regions else "UNK",
            "Loc_Lat": "",  # 不再由 LLM 生成坐标
            "Loc_Lon": "",
            "Loc_Confidence": confidence,
        }

    res = run_stage(
        stage_key="step3_location_norm",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="loc_geographic_level",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt7 研究区域标准化",
        client=client,
    )

    if not args.dry_run:
        try:
            out_df = pd.read_excel(out_path)
            total = max(len(out_df), 1)
            print("\n=== 研究区域标准化回执 ===")
            vc = out_df["loc_geographic_level"].fillna("").astype(str).value_counts()
            for k, v in vc.items():
                print(f"  {k:20s} {int(v):6d}  ({int(v) / total * 100:5.2f}%)")
            amb = int(out_df["loc_ambiguity_flag"].fillna(False).astype(bool).sum())
            print(f"  歧义标记: {amb} ({amb / total * 100:.2f}%)  <- 距离分析中单列报告")
        except Exception as exc:
            print(f"[警告] 无法生成摘要: {exc}")


if __name__ == "__main__":
    sys.exit(main())
