# -*- coding: utf-8 -*-
"""
脚本名：step4.ecosystem_classification.py
原文件名：All_Ecosystem_output4_Xlsx.py（本脚本是其重写版）

Step 4 —— 生态系统一级分类（Prompt 3 / P3-ecosystem-v2.0）

本脚本针对方案第六、七、八节的全部批评做了修改
------------------------------------------------
1. temperature 0.2 -> 0，所有分类任务统一零温度，保证可复现；
2. taxonomy 重排，消除自相矛盾：
      旧版：Drylands 同时出现在 “2. Dryland Ecosystems” 和 “5. Agricultural Ecosystems”
      新版：干旱区/草地统一进入 “Dryland and Grassland Ecosystems”，
            农业生态系统只保留真正的农业经营类型（不再含 Drylands）；
3. Special 组扩展：新增 Permafrost（多年冻土）、Karst（喀斯特）、Polar、
   Antarctic、Mountain、Island 等，使论文里 glacier / karst / polar 的计数
   有明确分类依据；
4. 不再“看到 forest 就分 Forest”：明确要求以“实际被评估/估值的那个生态系统”为准，
   背景提及不算；
5. 不允许模型自由生成类别：使用 JSON Schema + enum 强约束
   （ecosystem_primary 与 ecosystem_subtype 都在枚举内，且亚类必须属于所选一级类）；
6. 无法判定时输出 UNKNOWN，而不是硬猜；
7. 输出 evidence 与 confidence，供人工复核与全文金标准校验。

输出列
------
    ecosystem_primary        七个一级类之一，或 UNKNOWN（正式结果）
    ecosystem_subtype        对应亚类，或 UNKNOWN（探索性结果）
    ecosystem_evidence       支持判定的原文片段（人工审核用）
    ecosystem_confidence     high | medium | low（模型自报，非准确率）
    ecosystem_model / ecosystem_prompt_version / ecosystem_run_at
    ecosystem_pair_valid     亚类是否属于所选一级类（自动一致性校验）

兼容列：Ecosystem primary classification / Ecosystem sub-classification
（写入同样的值，避免下游脚本改动）

用法
----
    python step4.ecosystem_classification.py --dry-run
    python step4.ecosystem_classification.py --limit 200
    python step4.ecosystem_classification.py
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import P3_PRIMARY_ENUM, P3_SUBTYPE_MAP, PROMPT_VERSIONS, SCHEMA_VERSIONS, get_prompt, get_system, get_user
from llm_utils import (
    ABSTRACT_CANDIDATES,
    TITLE_CANDIDATES,
    add_common_args,
    as_confidence,
    as_text,
    find_column,
    get_client,
    is_blank,
    load_settings,
    normalize_enum_value,
    resolve_io,
    truncate,
)

PROMPT_KEY = "ecosystem"
OUTPUT_COLUMNS = [
    "ecosystem_primary",
    "ecosystem_subtype",
    "ecosystem_evidence",
    "ecosystem_confidence",
    "ecosystem_pair_valid",
    "ecosystem_model",
    "ecosystem_prompt_version",
    "ecosystem_run_at",
    # 兼容旧列名
    "Ecosystem primary classification",
    "Ecosystem sub-classification",
]


def _flatten_enum(values) -> list:
    out = []
    for v in values:
        if isinstance(v, (list, tuple, set)):
            out.extend(str(x) for x in v)
        else:
            out.append(str(v))
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 4：生态系统一级分类（Prompt 3，taxonomy v2）")
    add_common_args(ap)
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP3_LOCATION", "PATH_STEP4_ECOSYSTEM")
    head = pd.read_excel(in_path, nrows=0)
    title_col = find_column(head, TITLE_CANDIDATES)
    abs_col = find_column(head, ABSTRACT_CANDIDATES)
    if abs_col is None:
        raise SystemExit(f"在 {in_path.name} 中找不到摘要列，候选列名: {ABSTRACT_CANDIDATES}")

    print(f"输入: {in_path}")
    print(f"标题列: {title_col}   摘要列: {abs_col}")
    print(f"输出: {out_path}")
    print(f"[taxonomy] 一级类 {len(P3_PRIMARY_ENUM) - 1} 个 + UNKNOWN；亚类 {len(_flatten_enum(list(P3_SUBTYPE_MAP.values())))} 个")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_chars = settings.max_abstract_chars

    def handler(df: pd.DataFrame, idx: int) -> dict:
        title = as_text(df.at[idx, title_col], "") if title_col else ""
        abstract = as_text(df.at[idx, abs_col], "")
        stamp = datetime.now().isoformat(timespec="seconds")
        if is_blank(abstract) and is_blank(title):
            return {
                "ecosystem_primary": "UNKNOWN",
                "ecosystem_subtype": "UNKNOWN",
                "ecosystem_evidence": "无标题与摘要",
                "ecosystem_confidence": "low",
                "ecosystem_pair_valid": True,
                "Ecosystem primary classification": "UNKNOWN",
                "Ecosystem sub-classification": "UNKNOWN",
                "ecosystem_model": settings.model,
                "ecosystem_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "ecosystem_run_at": stamp,
            }

        rec = client.classify(
            system_prompt,
            get_user(PROMPT_KEY, title=truncate(title, 1000) or "N/A", abstract=truncate(abstract, max_chars) or "N/A"),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=500,
            required_keys=prompt["required_keys"],
        )
        if not rec.ok:
            return {
                "ecosystem_primary": FAILED_SENTINEL,
                "ecosystem_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "ecosystem_model": settings.model,
                "ecosystem_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "ecosystem_run_at": stamp,
            }

        data = rec.data
        primary = normalize_enum_value(data.get("ecosystem_primary"), P3_PRIMARY_ENUM, "UNKNOWN")
        allowed_subtypes = P3_SUBTYPE_MAP.get(primary, ["UNKNOWN"])
        subtype = normalize_enum_value(data.get("ecosystem_subtype"), allowed_subtypes, "UNKNOWN")
        pair_valid = subtype in allowed_subtypes

        # 交叉一致性：UNKNOWN 必须成对出现
        if primary == "UNKNOWN":
            subtype = "UNKNOWN"
            pair_valid = True
        if subtype == "UNKNOWN" and primary != "UNKNOWN":
            pair_valid = True  # 允许“类别明确但亚类不确定”

        return {
            "ecosystem_primary": primary,
            "ecosystem_subtype": subtype,
            "ecosystem_evidence": as_text(data.get("evidence"), "")[:1000],
            "ecosystem_confidence": as_confidence(data.get("confidence")),
            "ecosystem_pair_valid": pair_valid,
            "ecosystem_model": settings.model,
            "ecosystem_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "ecosystem_run_at": stamp,
            "Ecosystem primary classification": primary,
            "Ecosystem sub-classification": subtype,
        }

    res = run_stage(
        stage_key="step4_ecosystem",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="ecosystem_primary",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt3 生态系统分类",
        client=client,
    )

    if not args.dry_run:
        try:
            out_df = pd.read_excel(out_path)
            total = max(len(out_df), 1)
            print("\n=== 生态系统一级类分布（核心结果变量） ===")
            vc = out_df["ecosystem_primary"].fillna("").astype(str).value_counts()
            for k, v in vc.items():
                print(f"  {k:36s} {int(v):6d}  ({int(v) / total * 100:5.2f}%)")
            bad = int((~out_df["ecosystem_pair_valid"].fillna(True).astype(bool)).sum())
            if bad:
                print(f"  [提示] {bad} 行亚类与一级类不匹配（已在写入时归一化，可复查 evidence）")
            print("  [论文提示] Special 组现包含 Glacier / Karst / Permafrost / Polar 等子类，")
            print("             原先 glacier=90 / karst=9 / polar=8 才有分类学依据。")
            print("  [论文提示] 一级类作为正式结果；亚类仅作探索性结果（可靠性低）。")
        except Exception as exc:
            print(f"[警告] 无法生成分布摘要: {exc}")


if __name__ == "__main__":
    sys.exit(main())
