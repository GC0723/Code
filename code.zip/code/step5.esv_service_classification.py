# -*- coding: utf-8 -*-
"""
脚本名：step5.esv_service_classification.py
原文件名：All_Ecosystem_system_output5_Xlsx.py（本脚本是其重写版）

Step 5 —— 生态系统服务分类（Prompt 4 / P4-esv-service-v2.0）

相对旧版的修改（方案第九、十、十一节）
--------------------------------------
1. 新增 BUNDLED_ECOSYSTEM_SERVICES：
   旧版强制“ONE category + ONE specific type”，遇到
   “estimated the total economic value of 12 ecosystem services” 这类论文时，
   模型只能被迫瞎选一个服务。新版明确允许 bundled，并在 README/论文中作为
   特殊类别单列，避免人为制造分类错误。
2. 一级分类用于正式结果，二级分类仅作探索性结果（可靠性低），
   两者在输出列里严格分开，并做“亚类必须属于所选一级类”的自动校验。
3. temperature=0，JSON Schema + enum 强约束（不再依赖“Output JSON ONLY”）。
4. 无法判定输出 UNKNOWN；不把 ecosystem function / biodiversity /
   ecosystem condition 当作 ecosystem service。
5. 断点续跑、失败标记、evidence、run_manifest。

输出列
------
    service_primary           PROVISIONING_/REGULATING_/CULTURAL_/SUPPORTING_SERVICES
                              | BUNDLED_ECOSYSTEM_SERVICES | UNKNOWN
    service_subtype           对应亚类，或 UNKNOWN（探索性）
    service_evidence          支持判定的原文片段
    service_confidence        high | medium | low
    service_model / service_prompt_version / service_run_at
    service_pair_valid        亚类是否属于所选一级类
    service_bundled_flag      是否为 bundled（论文中单列的类别）

兼容列：EST1 / EST2（写入同样内容，供旧下游脚本继续使用）

用法
----
    python step5.esv_service_classification.py --dry-run
    python step5.esv_service_classification.py --limit 200
    python step5.esv_service_classification.py
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import P4_PRIMARY_ENUM, P4_SUBTYPE_MAP, PROMPT_VERSIONS, SCHEMA_VERSIONS, get_prompt, get_system, get_user
from llm_utils import (
    ABSTRACT_CANDIDATES,
    TITLE_CANDIDATES,
    add_common_args,
    as_confidence,
    as_text,
    find_column,
    get_client,
    is_blank,
    load_settings,
    normalize_enum_value,
    resolve_io,
    truncate,
)

PROMPT_KEY = "esv_service"
BUNDLED = "BUNDLED_ECOSYSTEM_SERVICES"
OUTPUT_COLUMNS = [
    "service_primary",
    "service_subtype",
    "service_evidence",
    "service_confidence",
    "service_pair_valid",
    "service_bundled_flag",
    "service_model",
    "service_prompt_version",
    "service_run_at",
    # 兼容旧列名
    "EST1",
    "EST2",
]


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 5：生态系统服务分类（Prompt 4，含 BUNDLED）")
    add_common_args(ap)
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP4_ECOSYSTEM", "PATH_STEP5_ESV")
    head = pd.read_excel(in_path, nrows=0)
    title_col = find_column(head, TITLE_CANDIDATES)
    abs_col = find_column(head, ABSTRACT_CANDIDATES)
    if abs_col is None:
        raise SystemExit(f"在 {in_path.name} 中找不到摘要列，候选列名: {ABSTRACT_CANDIDATES}")

    print(f"输入: {in_path}")
    print(f"标题列: {title_col}   摘要列: {abs_col}")
    print(f"输出: {out_path}")
    print(f"[重要] 一级服务类别之外新增 {BUNDLED}，避免模型被迫瞎选单一服务。")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_chars = settings.max_abstract_chars

    def handler(df: pd.DataFrame, idx: int) -> dict:
        title = as_text(df.at[idx, title_col], "") if title_col else ""
        abstract = as_text(df.at[idx, abs_col], "")
        stamp = datetime.now().isoformat(timespec="seconds")
        if is_blank(abstract) and is_blank(title):
            return {
                "service_primary": "UNKNOWN",
                "service_subtype": "UNKNOWN",
                "service_evidence": "无标题与摘要",
                "service_confidence": "low",
                "service_pair_valid": True,
                "service_bundled_flag": False,
                "service_model": settings.model,
                "service_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "service_run_at": stamp,
                "EST1": "UNKNOWN",
                "EST2": "UNKNOWN",
            }

        rec = client.classify(
            system_prompt,
            get_user(PROMPT_KEY, title=truncate(title, 1000) or "N/A", abstract=truncate(abstract, max_chars) or "N/A"),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=500,
            required_keys=prompt["required_keys"],
        )
        if not rec.ok:
            return {
                "service_primary": FAILED_SENTINEL,
                "service_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "service_model": settings.model,
                "service_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "service_run_at": stamp,
            }

        data = rec.data
        primary = normalize_enum_value(data.get("service_primary"), P4_PRIMARY_ENUM, "UNKNOWN")
        allowed_subtypes = P4_SUBTYPE_MAP.get(primary, ["UNKNOWN"])
        subtype = normalize_enum_value(data.get("service_subtype"), allowed_subtypes, "UNKNOWN")
        pair_valid = subtype in allowed_subtypes

        if primary == "UNKNOWN":
            subtype = "UNKNOWN"
            pair_valid = True
        if subtype == "UNKNOWN" and primary != "UNKNOWN":
            pair_valid = True
        bundled = primary == BUNDLED
        if bundled:
            subtype = "Bundled ecosystem services"
            pair_valid = True

        return {
            "service_primary": primary,
            "service_subtype": subtype,
            "service_evidence": as_text(data.get("evidence"), "")[:1000],
            "service_confidence": as_confidence(data.get("confidence")),
            "service_pair_valid": pair_valid,
            "service_bundled_flag": bundled,
            "service_model": settings.model,
            "service_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "service_run_at": stamp,
            "EST1": primary,
            "EST2": subtype,
        }

    res = run_stage(
        stage_key="step5_esv_service",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="service_primary",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt4 生态系统服务分类",
        client=client,
    )

    if not args.dry_run:
        try:
            out_df = pd.read_excel(out_path)
            total = max(len(out_df), 1)
            print("\n=== 生态系统服务一级类分布（辅助结果） ===")
            vc = out_df["service_primary"].fillna("").astype(str).value_counts()
            for k, v in vc.items():
                print(f"  {k:30s} {int(v):6d}  ({int(v) / total * 100:5.2f}%)")
            n_bundle = int(out_df["service_bundled_flag"].fillna(False).astype(bool).sum())
            print(f"\n  bundled 论文: {n_bundle} ({n_bundle / total * 100:.2f}%)")
            print("  [论文提示] 建议同时报告“排除 bundled 后”的四类服务占比，作为敏感性分析；")
            print("             不要把 bundled 强行拆分到四个一级类，以免制造分类误差。")
            print("  [论文提示] 一级服务类别可靠性中等偏低，亚类可靠性低，仅作探索性结果。")
        except Exception as exc:
            print(f"[警告] 无法生成分布摘要: {exc}")


if __name__ == "__main__":
    sys.exit(main())
