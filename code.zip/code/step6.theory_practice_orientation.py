# -*- coding: utf-8 -*-
"""
脚本名：step6.theory_practice_orientation.py
原文件名：无（本脚本为新增；原版把理论/实践导向混在一次抽取里）

Step 6 —— 理论导向 / 实践导向（Prompt 5 / P5-orientation-v2.0）★新增脚本

为什么必须新增（方案第十二、十三、十四节）
------------------------------------------
PTR（practice-to-theory ratio）依赖这一变量的清晰定义。
若只区分“theoretical vs practical”而没有证据标准，
“This study provides important implications for ecosystem management.”
这类句子会被强行算成实践导向，或反过来被算成理论导向——两种都会带来系统性偏差。

新版做法：
1. 明确“实践导向”的**证据门槛**：必须把估值/评估结果与具体的
   管理、政策、规划、治理、补偿、金融或决策应用明确连接；
2. 明确“仅仅出现 implications / significance / importance / sustainability /
   policy / management”**不构成**实践导向；
3. 引入 UNCERTAIN 第三类，不再强迫模型二选一；
4. 输出 application_type，用于解释 PTR 的构成。

PTR 的上下界（可直接写入论文）
------------------------------
    PTR_lower = N_practice / N
    PTR_upper = (N_practice + N_uncertain) / N

本脚本在结束时自动打印这两个界限（对应保守方案 UNCERTAIN→THEORY 与
敏感性方案 UNCERTAIN→PRACTICE）。

输出列
------
    orientation_primary       PRACTICE_ORIENTED | THEORY_ORIENTED | UNCERTAIN
    application_type          management | planning | conservation | restoration |
                              policy | compensation_or_PES | accounting |
                              decision_support | resource_allocation | other |
                              none | unclear
    orientation_evidence      支持判定的原文片段
    orientation_confidence    high | medium | low
    orientation_model / orientation_prompt_version / orientation_run_at

用法
----
    python step6.theory_practice_orientation.py --dry-run
    python step6.theory_practice_orientation.py --limit 200
    python step6.theory_practice_orientation.py
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from llm_pipeline import FAILED_SENTINEL, run_stage
from llm_prompts import (
    P5_APPLICATION_ENUM,
    P5_ORIENTATION_ENUM,
    PROMPT_VERSIONS,
    SCHEMA_VERSIONS,
    get_prompt,
    get_system,
    get_user,
)
from llm_utils import (
    ABSTRACT_CANDIDATES,
    TITLE_CANDIDATES,
    add_common_args,
    as_confidence,
    as_text,
    find_column,
    get_client,
    is_blank,
    load_settings,
    normalize_enum_value,
    resolve_io,
    truncate,
)

PROMPT_KEY = "orientation"
OUTPUT_COLUMNS = [
    "orientation_primary",
    "application_type",
    "orientation_evidence",
    "orientation_confidence",
    "orientation_model",
    "orientation_prompt_version",
    "orientation_run_at",
]


def print_ptr_bounds(out_path: Path) -> None:
    """打印 PTR 的观测值、下界（UNCERTAIN→THEORY）与上界（UNCERTAIN→PRACTICE）。"""
    try:
        df = pd.read_excel(out_path)
    except Exception as exc:
        print(f"[警告] 无法读取输出计算 PTR: {exc}")
        return

    col = df["orientation_primary"].fillna("").astype(str)
    n_practice = int((col == "PRACTICE_ORIENTED").sum())
    n_theory = int((col == "THEORY_ORIENTED").sum())
    n_uncertain = int((col == "UNCERTAIN").sum())
    n_failed = int((col == FAILED_SENTINEL).sum())
    denom = n_practice + n_theory + n_uncertain

    print("\n=== 理论/实践导向与 PTR（论文核心结果 ③） ===")
    print(f"  PRACTICE_ORIENTED : {n_practice:6d}")
    print(f"  THEORY_ORIENTED   : {n_theory:6d}")
    print(f"  UNCERTAIN         : {n_uncertain:6d}")
    if n_failed:
        print(f"  处理失败(待重跑)  : {n_failed:6d}")
    if denom:
        lower = n_practice / denom * 100
        upper = (n_practice + n_uncertain) / denom * 100
        print(f"\n  observed PTR (practice / classified) = {lower:.2f}%")
        print(f"  PTR_lower  (UNCERTAIN -> THEORY)     = {lower:.2f}%")
        print(f"  PTR_upper  (UNCERTAIN -> PRACTICE)   = {upper:.2f}%")
        print(f"  -> 论文可报告: observed PTR = {lower:.1f}%; sensitivity bounds = {lower:.1f}-{upper:.1f}%")
    print("\n  实践导向的 application_type 构成：")
    vc = df["application_type"].fillna("").astype(str).value_counts()
    for k, v in vc.items():
        print(f"    {k:22s} {int(v):6d}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 6：理论/实践导向（Prompt 5，含 UNCERTAIN 与 PTR 上下界）")
    add_common_args(ap)
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP5_ESV", "PATH_STEP6_ORIENTATION")
    head = pd.read_excel(in_path, nrows=0)
    title_col = find_column(head, TITLE_CANDIDATES)
    abs_col = find_column(head, ABSTRACT_CANDIDATES)
    if abs_col is None:
        raise SystemExit(f"在 {in_path.name} 中找不到摘要列，候选列名: {ABSTRACT_CANDIDATES}")

    print(f"输入: {in_path}")
    print(f"标题列: {title_col}   摘要列: {abs_col}")
    print(f"输出: {out_path}")
    print("[说明] 实践导向要求“估值结果 <-> 具体管理/政策/规划/补偿/决策应用”的明确连接；")
    print("       仅有 implications / policy / management 字样的论文归入 THEORY 或 UNCERTAIN。")

    prompt = get_prompt(PROMPT_KEY)
    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_chars = settings.max_abstract_chars

    def handler(df: pd.DataFrame, idx: int) -> dict:
        title = as_text(df.at[idx, title_col], "") if title_col else ""
        abstract = as_text(df.at[idx, abs_col], "")
        stamp = datetime.now().isoformat(timespec="seconds")
        if is_blank(abstract) and is_blank(title):
            return {
                "orientation_primary": "UNCERTAIN",
                "application_type": "unclear",
                "orientation_evidence": "无标题与摘要",
                "orientation_confidence": "low",
                "orientation_model": settings.model,
                "orientation_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "orientation_run_at": stamp,
            }

        rec = client.classify(
            system_prompt,
            get_user(PROMPT_KEY, title=truncate(title, 1000) or "N/A", abstract=truncate(abstract, max_chars) or "N/A"),
            schema=prompt["schema"],
            schema_name=prompt["schema_name"],
            prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
            max_tokens=500,
            required_keys=prompt["required_keys"],
        )
        if not rec.ok:
            return {
                "orientation_primary": FAILED_SENTINEL,
                "orientation_evidence": f"CALL_FAILED: {rec.error}"[:500],
                "orientation_model": settings.model,
                "orientation_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
                "orientation_run_at": stamp,
            }

        data = rec.data
        orientation = normalize_enum_value(data.get("orientation"), P5_ORIENTATION_ENUM, "UNCERTAIN")
        app_type = normalize_enum_value(data.get("application_type"), P5_APPLICATION_ENUM, "unclear")
        if orientation != "PRACTICE_ORIENTED" and app_type == "none":
            app_type = "none"

        return {
            "orientation_primary": orientation,
            "application_type": app_type,
            "orientation_evidence": as_text(data.get("evidence"), "")[:1000],
            "orientation_confidence": as_confidence(data.get("confidence")),
            "orientation_model": settings.model,
            "orientation_prompt_version": PROMPT_VERSIONS[PROMPT_KEY],
            "orientation_run_at": stamp,
        }

    res = run_stage(
        stage_key="step6_orientation",
        script_name=Path(__file__).name,
        in_path=in_path,
        out_path=out_path,
        columns=OUTPUT_COLUMNS,
        label_column="orientation_primary",
        row_handler=handler,
        settings=settings,
        prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
        schema_version=SCHEMA_VERSIONS[PROMPT_KEY],
        args=args,
        desc="Prompt5 理论/实践导向",
        client=client,
    )

    if not args.dry_run:
        print_ptr_bounds(out_path)


if __name__ == "__main__":
    sys.exit(main())
