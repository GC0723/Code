# -*- coding: utf-8 -*-
"""
脚本名：step7.gis_geocoding.py
原文件名：无（本脚本为新增；坐标由 GIS/geocoder 产出，LLM 不再给坐标）

Step 7 —— 研究区域 / 作者机构的地理编码（GIS 层，不调用 LLM，不消耗 API 额度）★新增脚本

方案第十五、十六节的核心要求：
    **LLM 负责“理解文本”，地理编码软件负责“确定坐标”。**

因此本脚本：
    1. 读取 Step 3（或 Step 6）的研究区域结果；若主表没有 affil_* 列，
       则按 UT/DOI 等唯一 ID 自动合并 Step 2 的机构归一化结果；
    2. 依次尝试：
         a) 手动覆盖表（geocode_overrides.csv，最高优先级，用于人工核查修正）
         b) 本地地名词典（gazetteer_extra.csv + 内置常用地名）
         c) geopy（若已安装；Nominatim / 其它 provider）
         d) Nominatim HTTP 直连（1 请求/秒，需真实 User-Agent 与联系方式）
    3. 为每个坐标记录 **来源**（source）与 **精度层级**（level），
       论文补充材料可直接说明坐标系与来源；
    4. 失败一律写 UNKNOWN，**绝不臆造坐标**。

输出列（研究区域）
------------------
    geo_study_country      地理编码结果国家
    geo_study_region       一级行政区
    geo_study_lat / lon    WGS84（EPSG:4326）
    geo_study_level        坐标精度层级（country / province / city / site ...）
    geo_study_source       override | gazetteer | geopy | nominatim | none
    geo_study_match_confidence  0-1（地理编码匹配置信度，与 LLM 置信度不同）

输出列（作者机构）
------------------
    geo_author_country / geo_author_region / geo_author_lat / geo_author_lon /
    geo_author_level / geo_author_source / geo_author_match_confidence

缓存
----
    geocode_cache.csv —— 键为“归一化文本”，避免重复请求（可断点续跑）。

用法
----
    python step7.gis_geocoding.py --dry-run
    python step7.gis_geocoding.py                       # 使用 .env 中的 GEOCODER 设置
    python step7.gis_geocoding.py --provider none       # 只用字典/覆盖表，不联网
    python step7.gis_geocoding.py --provider nominatim  # 允许联网（1 req/s）
    python step7.gis_geocoding.py --input results/6_Orientation_out.xlsx \
        --affiliation-input results/2_Affiliations_out.xlsx --provider none
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
import urllib.parse
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from tqdm import tqdm

from llm_utils import add_common_args, find_column, load_settings, read_table, resolve_io, safe_cell, write_table

OUTPUT_COLUMNS = [
    "geo_study_country",
    "geo_study_region",
    "geo_study_lat",
    "geo_study_lon",
    "geo_study_level",
    "geo_study_source",
    "geo_study_match_confidence",
    "geo_author_country",
    "geo_author_region",
    "geo_author_lat",
    "geo_author_lon",
    "geo_author_level",
    "geo_author_source",
    "geo_author_match_confidence",
]

#: 内置地名词典（仅放最常用、无歧义的地点；正式分析请务必补充 gazetteer_extra.csv，
#: 或在论文中完整说明所使用的 GADM / Natural Earth / 官方行政区划数据版本）
#: 键：小写规范化名称；值：(国家, 一级行政区, 纬度, 经度, 精度层级)
BUILTIN_GAZETTEER: Dict[str, Tuple[str, str, float, float, str]] = {
    # 中国
    "china": ("China", "", 35.8617, 104.1954, "country"),
    "beijing": ("China", "Beijing Municipality", 39.9042, 116.4074, "city"),
    "beijing municipality": ("China", "Beijing Municipality", 39.9042, 116.4074, "city"),
    "shanghai": ("China", "Shanghai Municipality", 31.2304, 121.4737, "city"),
    "guangzhou": ("China", "Guangdong Province", 23.1291, 113.2644, "city"),
    "guangdong": ("China", "Guangdong Province", 23.3417, 113.4244, "province_state"),
    "guangdong province": ("China", "Guangdong Province", 23.3417, 113.4244, "province_state"),
    "nanjing": ("China", "Jiangsu Province", 32.0603, 118.7969, "city"),
    "urumqi": ("China", "Xinjiang Uygur Autonomous Region", 43.8256, 87.6168, "city"),
    "lanzhou": ("China", "Gansu Province", 36.0611, 103.8343, "city"),
    "guiyang": ("China", "Guizhou Province", 26.6470, 106.6302, "city"),
    "guizhou": ("China", "Guizhou Province", 26.8155, 106.8747, "province_state"),
    "guizhou province": ("China", "Guizhou Province", 26.8155, 106.8747, "province_state"),
    "changsha": ("China", "Hunan Province", 28.2282, 112.9388, "city"),
    "hunan": ("China", "Hunan Province", 27.6253, 111.8568, "province_state"),
    "hunan province": ("China", "Hunan Province", 27.6253, 111.8568, "province_state"),
    "yangtze river basin": ("China", "", 30.9, 112.0, "watershed_basin"),
    "loess plateau": ("China", "", 36.5, 108.5, "mountain_region"),
    "tibetan plateau": ("China", "", 32.0, 86.0, "mountain_region"),
    "qinghai-tibet plateau": ("China", "", 32.0, 86.0, "mountain_region"),
    "hainan": ("China", "Hainan Province", 19.1959, 109.7453, "island"),
    # 日韩
    "japan": ("Japan", "", 36.2048, 138.2529, "country"),
    "tokyo": ("Japan", "Tokyo Metropolis", 35.6762, 139.6503, "city"),
    "kyoto": ("Japan", "Kyoto Prefecture", 35.0116, 135.7681, "city"),
    "south korea": ("South Korea", "", 35.9078, 127.7669, "country"),
    # 欧美
    "united states": ("United States", "", 39.8283, -98.5795, "country"),
    "usa": ("United States", "", 39.8283, -98.5795, "country"),
    "california": ("United States", "California", 36.7783, -119.4179, "province_state"),
    "berkeley": ("United States", "California", 37.8715, -122.2730, "city"),
    "united kingdom": ("United Kingdom", "", 55.3781, -3.4360, "country"),
    "england": ("United Kingdom", "England", 52.3555, -1.1743, "province_state"),
    "london": ("United Kingdom", "England", 51.5074, -0.1278, "city"),
    "germany": ("Germany", "", 51.1657, 10.4515, "country"),
    "freiburg": ("Germany", "Baden-Wurttemberg", 47.9990, 7.8421, "city"),
    "france": ("France", "", 46.2276, 2.2137, "country"),
    "paris": ("France", "Ile-de-France", 48.8566, 2.3522, "city"),
    "netherlands": ("Netherlands", "", 52.1326, 5.2913, "country"),
    "spain": ("Spain", "", 40.4637, -3.7492, "country"),
    "italy": ("Italy", "", 41.8719, 12.5674, "country"),
    "sweden": ("Sweden", "", 60.1282, 18.6435, "country"),
    "norway": ("Norway", "", 60.4720, 8.4689, "country"),
    "oslo": ("Norway", "Oslo", 59.9139, 10.7522, "city"),
    "finland": ("Finland", "", 61.9241, 25.7482, "country"),
    "canada": ("Canada", "", 56.1304, -106.3468, "country"),
    "australia": ("Australia", "", -25.2744, 133.7751, "country"),
    "brazil": ("Brazil", "", -14.2350, -51.9253, "country"),
    "sao paulo": ("Brazil", "Sao Paulo", -23.5505, -46.6333, "city"),
    "amazon basin": ("Brazil", "", -3.4653, -62.2159, "watershed_basin"),
    "india": ("India", "", 20.5937, 78.9629, "country"),
    "kenya": ("Kenya", "", -0.0236, 37.9062, "country"),
    "nairobi": ("Kenya", "Nairobi", -1.2921, 36.8219, "city"),
    "south africa": ("South Africa", "", -30.5595, 22.9375, "country"),
    "indonesia": ("Indonesia", "", -0.7893, 113.9213, "country"),
    "mexico": ("Mexico", "", 23.6345, -102.5528, "country"),
    "ethiopia": ("Ethiopia", "", 9.1450, 40.4897, "country"),
    "antarctica": ("Antarctica", "", -75.2509, -0.0713, "continent"),
    "global": ("", "", None, None, "global"),  # 特殊：不产生坐标
    "world": ("", "", None, None, "global"),
}


def _norm_key(text: str) -> str:
    text = safe_cell(text, "").lower()
    text = text.replace("the ", "").strip()
    for token in (", peoples r china", ", p.r. china", ", china", " municipality", " province", " prefecture"):
        if text.endswith(token):
            text = text[: -len(token)]
    return " ".join(text.replace("’", "'").split())


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


class Gazetteer:
    """本地地名词典：内置表 + 用户扩展表 + 手动覆盖表。"""

    def __init__(self, extra_path: Optional[Path], override_path: Optional[Path]) -> None:
        self.builtin = {_norm_key(k): v for k, v in BUILTIN_GAZETTEER.items()}
        self.extra = self._load_csv(extra_path, source="gazetteer")
        self.overrides = self._load_csv(override_path, source="override")

    @staticmethod
    def _load_csv(path: Optional[Path], source: str) -> Dict[str, Dict[str, Any]]:
        out: Dict[str, Dict[str, Any]] = {}
        if not path or not Path(path).exists():
            return out
        try:
            df = pd.read_csv(path)
        except Exception:
            return out
        for _, row in df.iterrows():
            name_col = None
            for cand in ("name", "normalized_name", "location", "place"):
                if cand in df.columns:
                    name_col = cand
                    break
            if name_col is None:
                continue
            key = _norm_key(str(row[name_col]))
            if not key:
                continue
            try:
                lat = float(row["lat"]) if "lat" in df.columns and not pd.isna(row["lat"]) else None
                lon = float(row["lon"]) if "lon" in df.columns and not pd.isna(row["lon"]) else None
            except Exception:
                lat = lon = None
            out[key] = {
                "country": safe_cell(row.get("country", ""), ""),
                "region": safe_cell(row.get("region", ""), ""),
                "lat": lat,
                "lon": lon,
                "level": safe_cell(row.get("level", ""), "city") or "city",
                "source": source,
                "match_confidence": float(row["confidence"]) if "confidence" in df.columns and not pd.isna(row["confidence"]) else 0.9,
            }
        return out

    def lookup(self, text: str) -> Optional[Dict[str, Any]]:
        key = _norm_key(text)
        if not key:
            return None
        if key in self.overrides:
            return dict(self.overrides[key])
        if key in self.extra:
            return dict(self.extra[key])
        if key in self.builtin:
            country, region, lat, lon, level = self.builtin[key]
            return {
                "country": country,
                "region": region,
                "lat": lat,
                "lon": lon,
                "level": level,
                "source": "gazetteer",
                "match_confidence": 0.8,
            }
        return None


class NominatimGeocoder:
    """Nominatim HTTP 直连（严格遵守 1 请求/秒与自定义 User-Agent）。"""

    def __init__(self, user_agent: str, email: str = "", min_interval: float = 1.1) -> None:
        self.url = "https://nominatim.openstreetmap.org/search"
        self.headers = {"User-Agent": user_agent, "Accept": "application/json"}
        if email:
            self.headers["From"] = email
        self.min_interval = max(1.0, float(min_interval))
        self._last = 0.0
        self._delegate = None
        try:  # 若安装了 geopy，优先用 geopy（同样遵守速率限制）
            from geopy.geocoders import Nominatim  # type: ignore

            self._delegate = Nominatim(user_agent=user_agent, timeout=20)
            if email:
                try:
                    self._delegate.headers["From"] = email
                except Exception:
                    pass
        except Exception:
            self._delegate = None

    def _wait(self) -> None:
        delta = time.monotonic() - self._last
        if delta < self.min_interval:
            time.sleep(self.min_interval - delta)
        self._last = time.monotonic()

    def geocode(self, query: str) -> Optional[Dict[str, Any]]:
        if not query.strip():
            return None
        self._wait()
        try:
            if self._delegate is not None:
                loc = self._delegate.geocode(query, exactly_one=True, addressdetails=True, language="en")
                if loc is None:
                    return None
                raw = getattr(loc, "raw", {}) or {}
                addr = raw.get("address", {}) or {}
                return {
                    "country": addr.get("country", "") or "",
                    "region": addr.get("state", "") or addr.get("region", "") or "",
                    "lat": float(loc.latitude),
                    "lon": float(loc.longitude),
                    "level": _level_from_addresstype(raw.get("addresstype") or raw.get("type") or ""),
                    "source": "geopy-nominatim",
                    "match_confidence": _importance_to_conf(raw.get("importance")),
                }
            import requests

            params = {"q": query, "format": "jsonv2", "addressdetails": 1, "limit": 1, "accept-language": "en"}
            resp = requests.get(self.url + "?" + urllib.parse.urlencode(params), headers=self.headers, timeout=25)
            if resp.status_code != 200:
                return None
            items = resp.json()
            if not items:
                return None
            item = items[0]
            addr = item.get("address", {}) or {}
            return {
                "country": addr.get("country", "") or "",
                "region": addr.get("state", "") or addr.get("region", "") or "",
                "lat": float(item["lat"]),
                "lon": float(item["lon"]),
                "level": _level_from_addresstype(item.get("addresstype") or item.get("type") or ""),
                "source": "nominatim",
                "match_confidence": _importance_to_conf(item.get("importance")),
            }
        except Exception:
            return None


def _level_from_addresstype(value: str) -> str:
    v = (value or "").lower()
    mapping = {
        "country": "country",
        "state": "province_state",
        "province": "province_state",
        "region": "province_state",
        "county": "county_district",
        "city": "city",
        "town": "city",
        "municipality": "city",
        "village": "site",
        "hamlet": "site",
        "waterway": "watershed_basin",
        "river": "watershed_basin",
        "basin": "watershed_basin",
        "protected_area": "protected_area",
        "island": "island",
        "mountain_range": "mountain_region",
        "peak": "mountain_region",
    }
    return mapping.get(v, "site")


def _importance_to_conf(importance: Any) -> float:
    try:
        imp = float(importance)
    except Exception:
        return 0.5
    return max(0.1, min(1.0, imp))


EMPTY = {
    "country": "",
    "region": "",
    "lat": None,
    "lon": None,
    "level": "unknown",
    "source": "none",
    "match_confidence": 0.0,
}


def geocode_one(
    *,
    name: str,
    country_hint: str,
    region_hint: str,
    gaz: Gazetteer,
    online: Optional[NominatimGeocoder],
    use_online: bool,
) -> Dict[str, Any]:
    """按 覆盖表 -> 本地词典 -> 在线 geocoder 的顺序解析一个地名。"""
    if not safe_cell(name, ""):
        return dict(EMPTY)

    hit = gaz.lookup(name)
    if hit is None and country_hint:
        hit = gaz.lookup(country_hint)
    if hit is not None:
        return hit

    if use_online and online is not None:
        query = ", ".join([p for p in [name, region_hint, country_hint] if safe_cell(p, "")])
        result = online.geocode(query)
        if result is not None and result.get("lat") is not None:
            return result

    return dict(EMPTY)


ID_CANDIDATES = ("UT", "UT (Unique WOS ID)", "Paper ID", "paper_id", "DOI", "DI")


def merge_affiliation_results(
    df: pd.DataFrame,
    affiliation_path: Path,
    id_col: Optional[str] = None,
) -> pd.DataFrame:
    """Join Step 2 affiliation columns onto the main table by a unique paper ID."""
    aff = read_table(affiliation_path)
    left_id = id_col or find_column(df, ID_CANDIDATES)
    right_id = id_col or find_column(aff, ID_CANDIDATES)
    if (
        not left_id
        or not right_id
        or left_id != right_id
        or left_id not in df.columns
        or right_id not in aff.columns
    ):
        raise SystemExit(
            "无法合并 Step 2 机构结果：主表与机构表必须包含同名唯一 ID 列 "
            f"{ID_CANDIDATES}，或用 --id-col 显式指定。"
        )
    if df[left_id].isna().any() or aff[right_id].isna().any():
        raise SystemExit(f"合并键 {left_id} 含空值；请先补齐唯一论文 ID。")
    if df[left_id].duplicated().any() or aff[right_id].duplicated().any():
        raise SystemExit(f"合并键 {left_id} 不是唯一键；请先处理重复记录，避免一对多扩行。")

    aff_cols = [c for c in aff.columns if c.startswith("affil_")]
    if not aff_cols:
        raise SystemExit(f"机构结果 {affiliation_path} 中没有 affil_* 列，请确认它来自 Step 2。")
    overlap = [c for c in aff_cols if c in df.columns]
    if overlap:
        raise SystemExit(f"主表已包含机构列 {overlap}；无需重复合并。")

    merged = df.merge(aff[[right_id] + aff_cols], on=left_id, how="left", validate="one_to_one")
    matched = int(merged["affil_normalized_location"].notna().sum()) if "affil_normalized_location" in merged else 0
    print(f"机构结果合并: {affiliation_path} | 键={left_id} | 匹配={matched}/{len(merged)}")
    return merged


def main() -> None:
    settings = load_settings()
    ap = argparse.ArgumentParser(description="Step 7：研究区域与作者机构地理编码（不调用 LLM）")
    add_common_args(ap)
    ap.add_argument(
        "--provider",
        default=settings.geocode.get("provider", "auto"),
        choices=["auto", "none", "gazetteer", "geopy", "nominatim"],
        help="在线地理编码提供方；none=只用本地词典（默认取 .env GEOCODER）",
    )
    ap.add_argument("--study-name-col", default=None, help="指定研究区域名称列")
    ap.add_argument("--author-name-col", default=None, help="指定作者机构文本列；设置后不自动合并 Step 2")
    ap.add_argument("--affiliation-input", default=None, help="Step 2 机构结果表；主表无 affil_* 列时按 ID 合并")
    ap.add_argument("--id-col", default=None, help="主表与机构表的共同唯一 ID 列（默认自动识别 UT/DOI 等）")
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP3_LOCATION", "PATH_STEP7_GEOCODE")

    df = read_table(in_path)
    print(f"输入: {in_path}   行数: {len(df)}")
    print(f"输出: {out_path}")

    # Step 2 is parallel to Steps 1/3–6. Merge its affil_* columns when the
    # selected main input does not already contain normalized affiliation data.
    has_normalized_affiliation = any(
        c in df.columns for c in ("affil_normalized_location", "affil_city", "affil_country")
    )
    if not has_normalized_affiliation and not args.author_name_col:
        affiliation_path = Path(args.affiliation_input) if args.affiliation_input else settings.path("PATH_STEP2_AFFILIATION")
        if affiliation_path.exists():
            df = merge_affiliation_results(df, affiliation_path, args.id_col)
        elif args.affiliation_input:
            raise SystemExit(f"指定的机构结果不存在: {affiliation_path}")
        else:
            print(f"[提示] 未找到 Step 2 机构结果 {affiliation_path}；将仅使用主表已有机构字段（如有）。")

    study_name_col = args.study_name_col or find_column(df, ("loc_normalized_name", "study_area_name", "research_location"))
    study_country_col = find_column(df, ("loc_country", "study_area_country"))
    study_region_col = find_column(df, ("loc_region",))
    author_col = args.author_name_col or find_column(df, ("affil_normalized_location", "affil_city", "affil_country", "Affiliations"))
    author_country_col = find_column(df, ("affil_country",))
    author_region_col = find_column(df, ("affil_region",))

    if study_name_col is None:
        raise SystemExit("找不到研究区域名称列（loc_normalized_name / study_area_name / research_location）")

    print(f"研究区域列: {study_name_col}   国家列: {study_country_col}   机构列: {author_col}")

    if args.dry_run:
        print(f"[dry-run] 将写入列: {OUTPUT_COLUMNS}")
        return

    gaz = Gazetteer(Path(settings.geocode["gazetteer"]), Path(settings.geocode["overrides"]))
    print(f"地名词典: 内置 {len(gaz.builtin)} 条 | 扩展 {len(gaz.extra)} 条 | 覆盖 {len(gaz.overrides)} 条")

    use_online = args.provider in ("auto", "geopy", "nominatim")
    online: Optional[NominatimGeocoder] = None
    if use_online:
        ua = settings.geocode.get("user_agent") or "ESV-bibliometric-coding/1.0"
        if "set GEOCODE_EMAIL" in ua:
            print("[警告] 请在 .env 设置 GEOCODE_USER_AGENT 与 GEOCODE_EMAIL（Nominatim 使用条款要求可识别的 UA）。")
        online = NominatimGeocoder(ua, settings.geocode.get("email", ""), settings.geocode.get("min_interval", 1.1))
        print(f"在线地理编码: 启用（{args.provider}，>= {settings.geocode.get('min_interval', 1.1)} s/请求）")
    else:
        print("在线地理编码: 关闭（仅使用本地词典/覆盖表）")

    cache_path = Path(settings.geocode["cache_file"])
    cache: Dict[str, Dict[str, Any]] = {}
    if cache_path.exists():
        try:
            cdf = pd.read_csv(cache_path)
            for _, r in cdf.iterrows():
                cache[str(r["key"])] = {
                    "country": r.get("country", ""),
                    "region": r.get("region", ""),
                    "lat": None if pd.isna(r.get("lat")) else float(r["lat"]),
                    "lon": None if pd.isna(r.get("lon")) else float(r["lon"]),
                    "level": r.get("level", "unknown"),
                    "source": r.get("source", "none"),
                    "match_confidence": 0.0 if pd.isna(r.get("match_confidence")) else float(r["match_confidence"]),
                }
            print(f"已加载地理编码缓存: {len(cache)} 条")
        except Exception as exc:
            print(f"[警告] 读取缓存失败，将重建: {exc}")

    def cached(kind: str, name: str, country_hint: str, region_hint: str) -> Dict[str, Any]:
        key = f"{kind}|{_norm_key(name)}|{_norm_key(country_hint)}"
        if key in cache:
            return cache[key]
        result = geocode_one(
            name=name,
            country_hint=country_hint,
            region_hint=region_hint,
            gaz=gaz,
            online=online,
            use_online=use_online,
        )
        result = dict(result)
        cache[key] = result
        return result

    rows_study, rows_author = [], []
    for idx in tqdm(range(len(df)), desc="Geocoding (WGS84)"):
        study_name = safe_cell(df.at[idx, study_name_col], "")
        country_hint = safe_cell(df.at[idx, study_country_col], "") if study_country_col else ""
        region_hint = safe_cell(df.at[idx, study_region_col], "") if study_region_col else ""

        s_res = cached("study", study_name, country_hint, region_hint) if study_name else dict(EMPTY)
        rows_study.append(s_res)

        if author_col:
            a_text = safe_cell(df.at[idx, author_col], "")
            a_country = safe_cell(df.at[idx, author_country_col], "") if author_country_col else ""
            a_region = safe_cell(df.at[idx, author_region_col], "") if author_region_col else ""
            a_res = cached("author", a_text, a_country, a_region) if a_text else dict(EMPTY)
        else:
            a_res = dict(EMPTY)
        rows_author.append(a_res)

        if (idx + 1) % 200 == 0:
            # Cache geocoding results for resumability. The table itself is
            # written only after all geo_* columns have been attached.
            _save_cache(cache_path, cache)

    df["geo_study_country"] = [r["country"] for r in rows_study]
    df["geo_study_region"] = [r["region"] for r in rows_study]
    df["geo_study_lat"] = [r["lat"] for r in rows_study]
    df["geo_study_lon"] = [r["lon"] for r in rows_study]
    df["geo_study_level"] = [r["level"] for r in rows_study]
    df["geo_study_source"] = [r["source"] for r in rows_study]
    df["geo_study_match_confidence"] = [r["match_confidence"] for r in rows_study]

    df["geo_author_country"] = [r["country"] for r in rows_author]
    df["geo_author_region"] = [r["region"] for r in rows_author]
    df["geo_author_lat"] = [r["lat"] for r in rows_author]
    df["geo_author_lon"] = [r["lon"] for r in rows_author]
    df["geo_author_level"] = [r["level"] for r in rows_author]
    df["geo_author_source"] = [r["source"] for r in rows_author]
    df["geo_author_match_confidence"] = [r["match_confidence"] for r in rows_author]

    df["geocode_run_at"] = datetime.now().isoformat(timespec="seconds")
    write_table(df, out_path)
    _save_cache(cache_path, cache)

    n = max(len(df), 1)
    ok_study = int(df["geo_study_lat"].notna().sum())
    ok_author = int(df["geo_author_lat"].notna().sum())
    print(f"\n=== 地理编码结果（WGS84 / EPSG:4326） ===")
    print(f"  研究区域已定位: {ok_study}/{len(df)} ({ok_study / n * 100:.2f}%)")
    print(f"  作者机构已定位: {ok_author}/{len(df)} ({ok_author / n * 100:.2f}%)")
    print("  坐标来源分布（论文需报告）:")
    for src, cnt in df["geo_study_source"].value_counts().items():
        print(f"    {src:18s} {int(cnt):6d}")
    print(f"  缓存文件: {cache_path}")
    print("  下一步: python step8.author_studyarea_distance.py")


def _save_cache(path: Path, cache: Dict[str, Dict[str, Any]]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        rows = []
        for key, val in cache.items():
            row = {"key": key}
            row.update(val)
            rows.append(row)
        pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")
    except Exception:
        pass


if __name__ == "__main__":
    sys.exit(main())
