# -*- coding: utf-8 -*-
"""
脚本名：step8.author_studyarea_distance.py
原文件名：无（本脚本为新增；距离分析必须基于带来源的坐标）

Step 8 —— 作者—研究区域距离计算（论文核心结果 ④）★新增脚本

背景
----
旧代码把“LLM 猜出来的坐标”直接用于距离分析（All_Affiliations_output2 的 Geo_Lat/Geo_Lon），
方案第十五节明确指出这是不可接受的：坐标必须来自地理编码器，且必须记录来源。

本脚本只消费 Step 7（step7.gis_geocoding.py）产出的、带来源与精度层级的坐标，
并据此计算：

    study_author_distance_km        作者机构 -> 研究区域 的大圆距离（km）
    study_author_distance_log       log10(1 + km)，供回归/分布分析使用
    cross_country_flag              研究区域国家 != 作者机构国家（note: 跨国 vs 国内）
    distance_valid_flag             是否具备可用于距离分析的坐标

距离度量说明
------------
默认使用 Haversine 大圆距离（球面，误差 < 0.5%，对国家级/城市级质心完全够用）。
如需椭球精确距离，可用 --geodesic 切换到 pyproj Geod（WGS84，更慢但更精确），
论文中需明确说明所用度量与坐标系（WGS84 / EPSG:4326）。

UNKNOWN 的处理（- - 与 PTR 的敏感性分析同理）
---------------------------------------------
    --unknown exclude   默认：坐标缺失的行排除在距离分析之外，并单独报告比例
    --unknown country   回退到国家级质心（更保守，但会系统性低估距离，必须作为敏感性分析）
    --unknown keep      仅保留空值，交由下游决定

用法
----
    python step8.author_studyarea_distance.py --dry-run
    python step8.author_studyarea_distance.py
    python step8.author_studyarea_distance.py --unknown country        # 敏感性分析
    python step8.author_studyarea_distance.py --geodesic               # 椭球精确距离
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import pandas as pd

from llm_utils import add_common_args, find_column, load_settings, read_table, resolve_io, safe_cell, write_table

OUTPUT_COLUMNS = [
    "study_author_distance_km",
    "study_author_distance_log",
    "cross_country_flag",
    "distance_valid_flag",
    "distance_note",
]

#: 少量国家质心（仅在 --unknown country 时用于回退，论文必须说明这是敏感性分析）
COUNTRY_CENTROIDS = {
    "china": (35.8617, 104.1954),
    "united states": (39.8283, -98.5795),
    "usa": (39.8283, -98.5795),
    "united kingdom": (55.3781, -3.4360),
    "uk": (55.3781, -3.4360),
    "germany": (51.1657, 10.4515),
    "france": (46.2276, 2.2137),
    "japan": (36.2048, 138.2529),
    "australia": (-25.2744, 133.7751),
    "canada": (56.1304, -106.3468),
    "brazil": (-14.2350, -51.9253),
    "india": (20.5937, 78.9629),
    "netherlands": (52.1326, 5.2913),
    "spain": (40.4637, -3.7492),
    "italy": (41.8719, 12.5674),
    "sweden": (60.1282, 18.6435),
    "norway": (60.4720, 8.4689),
    "finland": (61.9241, 25.7482),
    "south korea": (35.9078, 127.7669),
    "indonesia": (-0.7893, 113.9213),
    "mexico": (23.6345, -102.5528),
    "south africa": (-30.5595, 22.9375),
    "kenya": (-0.0236, 37.9062),
    "ethiopia": (9.1450, 40.4897),
}


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(min(1.0, a)))


def geodesic_km(lat1: float, lon1: float, lat2: float, lon2: float):
    try:
        from pyproj import Geod  # type: ignore

        geod = Geod(ellps="WGS84")
        _, _, dist = geod.inv(lon1, lat1, lon2, lat2)
        return dist / 1000.0
    except Exception:
        return haversine_km(lat1, lon1, lat2, lon2)


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 8：作者—研究区域距离（基于地理编码器坐标）")
    add_common_args(ap)
    ap.add_argument("--unknown", choices=["exclude", "country", "keep"], default=None, help="坐标缺失时的处理策略")
    ap.add_argument("--geodesic", action="store_true", help="使用 WGS84 椭球精确距离（pyproj）")
    args = ap.parse_args()

    in_path, out_path, settings = resolve_io(args, "PATH_STEP7_GEOCODE", "PATH_STEP8_DISTANCE")
    policy = (args.unknown or settings.distance_unknown_strategy or "exclude").lower()

    df = read_table(in_path)
    print(f"输入: {in_path}   行数: {len(df)}")
    print(f"输出: {out_path}")
    print(f"距离度量: {'WGS84 椭球 (pyproj)' if args.geodesic else 'Haversine 大圆'} | 缺失坐标策略: {policy}")

    required = ["geo_study_lat", "geo_study_lon", "geo_author_lat", "geo_author_lon"]
    missing = [c for c in required if c not in df.columns]

    if args.dry_run:
        if missing:
            print(f"[dry-run] 输入尚未地理编码（缺少 {missing}），正式运行前请先执行 step7.gis_geocoding.py")
        print(f"[dry-run] 将写入列: {OUTPUT_COLUMNS}")
        return

    if missing:
        raise SystemExit(f"缺少地理编码列 {missing}，请先运行 step7.gis_geocoding.py")

    study_country_col = find_column(df, ("geo_study_country", "loc_country", "study_area_country"))
    author_country_col = find_column(df, ("geo_author_country", "affil_country"))

    dists, logs, cross, valid, notes = [], [], [], [], []
    for _, row in df.iterrows():
        slat, slon = row["geo_study_lat"], row["geo_study_lon"]
        alat, alon = row["geo_author_lat"], row["geo_author_lon"]
        note = ""

        def _num(v):
            try:
                if pd.isna(v):
                    return None
                return float(v)
            except Exception:
                return None

        slat, slon, alat, alon = _num(slat), _num(slon), _num(alat), _num(alon)

        if policy == "country":
            if slat is None or slon is None:
                c = safe_cell(row.get(study_country_col, ""), "").split(";")[0].strip().lower()
                if c in COUNTRY_CENTROIDS:
                    slat, slon = COUNTRY_CENTROIDS[c]
                    note = "study:country-centroid"
            if alat is None or alon is None:
                c = safe_cell(row.get(author_country_col, ""), "").split(";")[0].strip().lower()
                if c in COUNTRY_CENTROIDS:
                    alat, alon = COUNTRY_CENTROIDS[c]
                    note = (note + ";author:country-centroid").strip(";")

        if None in (slat, slon, alat, alon):
            dists.append(None)
            logs.append(None)
            valid.append(False)
            missing_side = []
            if slat is None or slon is None:
                missing_side.append("study")
            if alat is None or alon is None:
                missing_side.append("author")
            note = (note + ";missing:" + "+".join(missing_side)).strip(";")
        else:
            d = geodesic_km(slat, slon, alat, alon) if args.geodesic else haversine_km(slat, slon, alat, alon)
            dists.append(round(d, 3))
            logs.append(round(math.log10(1.0 + d), 6))
            valid.append(True)

        sc = safe_cell(row.get(study_country_col, ""), "").split(";")[0].strip().lower() if study_country_col else ""
        ac = safe_cell(row.get(author_country_col, ""), "").split(";")[0].strip().lower() if author_country_col else ""
        cross.append(bool(sc and ac and sc != ac))
        notes.append(note)

    df["study_author_distance_km"] = dists
    df["study_author_distance_log"] = logs
    df["cross_country_flag"] = cross
    df["distance_valid_flag"] = valid
    df["distance_note"] = notes

    write_table(df, out_path)

    valid_series = pd.Series([d for d, v in zip(dists, valid) if v and d is not None], dtype="float64")
    n = max(len(df), 1)
    print(f"\n=== 作者—研究区域距离（核心结果 ④） ===")
    print(f"  可用距离: {len(valid_series)}/{len(df)} ({len(valid_series) / n * 100:.2f}%)")
    if len(valid_series):
        q = valid_series.quantile([0.25, 0.5, 0.75, 0.9]).to_dict()
        print(f"  中位数: {valid_series.median():.1f} km   均值: {valid_series.mean():.1f} km")
        print(f"  分位数: P25={q.get(0.25, float('nan')):.1f}  P50={q.get(0.5, float('nan')):.1f}  "
              f"P75={q.get(0.75, float('nan')):.1f}  P90={q.get(0.9, float('nan')):.1f}")
        print(f"  近距离记录 (< 100 km, 可视为本地研究): {(valid_series < 100).mean() * 100:.1f}%")
    cross_n = int(sum(1 for c, v in zip(cross, valid) if c and v))
    print(f"  作者国别 != 研究区域国别: {cross_n} ({cross_n / n * 100:.2f}%)")
    print("  [论文提示] 距离分析必须报告: (1) 坐标系 WGS84/EPSG:4326; (2) 距离度量;")
    print("             (3) 坐标来源分布（Step 7 的 geo_*_source 列）; (4) UNKNOWN 比例与处理策略。")


if __name__ == "__main__":
    sys.exit(main())
