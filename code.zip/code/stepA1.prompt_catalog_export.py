# -*- coding: utf-8 -*-
"""
脚本名：stepA1.prompt_catalog_export.py
原文件名：无（本脚本为新增）

stepA1.prompt_catalog_export.py —— 导出提示词清单（供论文 Supplementary Methods 使用）

用法：
    python stepA1.prompt_catalog_export.py            # 导出 Markdown + JSON 清单
    python stepA1.prompt_catalog_export.py --full     # 同时导出完整提示词全文

输出：
    prompt_catalog.md        提示词版本 / JSON Schema 版本 / SHA1 指纹
    prompt_catalog.json      机器可读版本
    prompt_catalog_full.md   完整提示词全文（建议与代码一起存档）

说明：本脚本不调用任何 API，可离线运行。
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

from llm_prompts import PROMPT_REGISTRY_VERSION, PROMPTS, SCHEMA_VERSIONS, all_versions, prompt_fingerprint
from llm_utils import load_settings


def build_markdown(settings) -> str:
    lines = [
        "# LLM Prompt Catalog",
        "",
        f"- Registry version: `{PROMPT_REGISTRY_VERSION}`",
        f"- Generated at: {datetime.now().isoformat(timespec='seconds')}",
        f"- Provider: `{settings.provider}`",
        f"- Model: `{settings.model}`",
        f"- Temperature: `{settings.temperature}` (all classification tasks use 0)",
        f"- JSON Schema requested: `{settings.use_json_schema}`",
        "",
        "| Step | Prompt version | JSON Schema | SHA1 (12) | Output columns |",
        "|---|---|---|---|---|",
    ]
    versions = all_versions()
    keys = [
        "relevance",
        "study_area",
        "affiliation",
        "location_norm",
        "ecosystem",
        "esv_service",
        "orientation",
        "fulltext_adjudication",
    ]
    for key in keys:
        if key not in PROMPTS:
            continue
        p = PROMPTS[key]
        lines.append(
            f"| `{key}` | `{versions[key]['version']}` | `{versions[key]['schema']}` | "
            f"`{versions[key]['sha1_12']}` | {', '.join('`'+c+'`' for c in p['outputs'])} |"
        )
    lines += [
        "",
        "## Notes for the manuscript",
        "",
        "- All prompts instruct the model to use ONLY the provided title/abstract (or full text for adjudication) "
        "and to return `UNKNOWN` / `UNCERTAIN` instead of guessing.",
        "- Author affiliation must never be used as the study area, and the study area must never be used to "
        "infer the author affiliation.",
        "- Coordinates are never produced by the LLM: geographic names are normalized by the LLM (Prompt 6/7) and "
        "geocoded by an external gazetteer/geocoder (see `step7.gis_geocoding.py`).",
        "- Model self-reported `confidence` is an audit field only; reliability must be quantified against the "
        "full-text gold standard (`validation_metrics.py`).",
        "- API credentials are read from environment variables; none are stored in code or supplementary files.",
        "",
    ]
    return "\n".join(lines)


def build_full_markdown(settings) -> str:
    lines = [
        "# LLM Prompts — Full Text",
        "",
        f"- Registry version: `{PROMPT_REGISTRY_VERSION}`",
        f"- Model: `{settings.model}` | temperature `{settings.temperature}`",
        "",
    ]
    for key, p in PROMPTS.items():
        lines += [
            f"## `{key}` — version `{p['version']}` (SHA1 {prompt_fingerprint(key)})",
            "",
            f"JSON Schema name: `{p['schema_name']}`",
            "",
            "### SYSTEM",
            "",
            "```text",
            p["system"],
            "```",
            "",
            "### USER TEMPLATE",
            "",
            "```text",
            p["user"],
            "```",
            "",
            "### JSON SCHEMA",
            "",
            "```json",
            json.dumps(p["schema"], ensure_ascii=False, indent=2),
            "```",
            "",
        ]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description="导出 LLM 提示词清单")
    ap.add_argument("--full", action="store_true", help="同时导出完整提示词全文")
    ap.add_argument("--outdir", default=None, help="输出目录（默认脚本所在目录）")
    args = ap.parse_args()

    settings = load_settings()
    outdir = Path(args.outdir) if args.outdir else settings.base_dir
    outdir.mkdir(parents=True, exist_ok=True)

    md_path = outdir / "prompt_catalog.md"
    md_path.write_text(build_markdown(settings), encoding="utf-8")

    json_path = outdir / "prompt_catalog.json"
    payload = {
        "registry_version": PROMPT_REGISTRY_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "provider": settings.provider,
        "model": settings.model,
        "temperature": settings.temperature,
        "prompts": all_versions(),
        "schemas": SCHEMA_VERSIONS,
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"已写出: {md_path}")
    print(f"已写出: {json_path}")

    if args.full:
        full_path = outdir / "prompt_catalog_full.md"
        full_path.write_text(build_full_markdown(settings), encoding="utf-8")
        print(f"已写出: {full_path}")


if __name__ == "__main__":
    main()
