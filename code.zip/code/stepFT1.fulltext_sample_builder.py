# -*- coding: utf-8 -*-
"""
脚本名：stepFT1.fulltext_sample_builder.py
原文件名：无（本脚本为新增；全文人工标注抽样）

stepFT1.fulltext_sample_builder.py —— 生成全文验证抽样表（412 篇 / 350+ PDF 验证集）★新增脚本

方案第十七、十八节要求：
    全文 PDF 不应只用于人工验证，而应形成
        PDF → 独立人工标注 → 全文复核（adjudication） → gold standard → P/R/F1/κ/CI
    的闭环；并且明确反对
        PDF → LLM → gold standard

本脚本负责这条链路的第一步：
    1. 从编码结果表里抽取待验证样本（可分层抽样）；
    2. 输出一张“人工标注表”，包含：
           paper_id / title / 自动编码结果 / 空白 gold_* 列（人工填写）
       （自动结果放在不同列，方便盲标时隐藏——脚本会额外提供 --blind 选项生成
        不含自动结果的盲标表，用另一份 key 文件回连，避免人工标注被 LLM 结果锚定）
    3. 同时输出 PDF 与 paper_id 的匹配清单（--pdf-dir），自动识别缺失 PDF。

分层抽样
--------
--stratify variable:column 例如 --stratify orientation_primary
可保证稀有类别（如 Glacier/Karst 或 BUNDLED）在验证集中有足够样本，
避免总体准确率虚高。

用法
----
    python stepFT1.fulltext_sample_builder.py --input 6_Orientation_out.xlsx --n 412
    python stepFT1.fulltext_sample_builder.py --input 6_Orientation_out.xlsx --n 300 --stratify orientation_primary
    python stepFT1.fulltext_sample_builder.py --input 6_Orientation_out.xlsx --n 412 --blind
    python stepFT1.fulltext_sample_builder.py --input 6_Orientation_out.xlsx --pdf-dir fulltext --check-pdfs
"""

from __future__ import annotations

import argparse
import random
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from llm_utils import (
    add_common_args,
    find_column,
    load_settings,
    read_table,
    resolve_io,
    safe_cell,
    write_table,
)

#: 用于唯一定位论文的 ID 列候选
ID_CANDIDATES = ("UT", "UT (Unique WOS ID)", "Paper ID", "paper_id", "DOI", "DI")

GOLD_COLUMNS = {
    "gold_relevance": "VALUATION_OR_ACCOUNTING | ECOSYSTEM_ASSESSMENT_NO_VALUATION | OUT_OF_SCOPE | UNCLEAR",
    "gold_study_area_type": "SITE | CITY | COUNTY_DISTRICT | PROVINCE_STATE | WATERSHED_BASIN | PROTECTED_AREA | "
                            "ISLAND | MOUNTAIN_REGION | COUNTRY | MULTI_COUNTRY | CONTINENT | GLOBAL | UNKNOWN",
    "gold_study_area_name": "研究区域名称（原文语言即可）",
    "gold_study_country": "国家（多个用 ; 分隔）",
    "gold_ecosystem_primary": "七个一级类之一 或 UNKNOWN",
    "gold_ecosystem_subtype": "对应亚类 或 UNKNOWN",
    "gold_service_primary": "四个服务一级类 或 BUNDLED_ECOSYSTEM_SERVICES 或 UNKNOWN",
    "gold_service_subtype": "对应亚类 或 UNKNOWN",
    "gold_orientation": "PRACTICE_ORIENTED | THEORY_ORIENTED | UNCERTAIN",
    "gold_application_type": "management | planning | ... | unclear",
    "gold_evidence_location": "Objectives | Study area | Methods | Results | Conclusions | Introduction",
    "gold_notes": "标注备注 / 与自动结果分歧的原因",
    "annotator": "标注人缩写",
    "annotation_date": "标注日期",
    "annotation_round": "first | second | adjudicated",
}

AUTO_PREFIX = "auto_"


def _norm_title(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", safe_cell(text, "").lower())[:60]


def match_pdfs(pdf_dir: Path, keys: List[str], titles: Optional[List[str]] = None) -> Dict[str, str]:
    """把 PDF 文件名与 paper_id / 标题匹配起来。"""
    found: Dict[str, str] = {}
    if not pdf_dir.exists():
        return found
    for pdf in pdf_dir.rglob("*.pdf"):
        stem_norm = _norm_title(pdf.stem)
        for key in keys:
            k = safe_cell(key, "")
            if not k:
                continue
            if k.lower() in pdf.stem.lower() or (len(k) > 6 and k.lower() in pdf.name.lower()):
                found[key] = str(pdf)
        if titles:
            for key, title in zip(keys, titles):
                if _norm_title(title) and _norm_title(title) in stem_norm:
                    found[key] = str(pdf)
    return found


def main() -> None:
    settings = load_settings()
    ap = argparse.ArgumentParser(description="生成全文验证抽样表（人工标注用）")
    add_common_args(ap)
    ap.add_argument("--n", type=int, default=412, help="抽样篇数（默认 412：使用现有全文验证集规模）")
    ap.add_argument("--stratify", default=None, help="分层变量列名，例如 orientation_primary")
    ap.add_argument("--min-per-class", type=int, default=15, help="分层抽样时每类最少抽多少篇")
    ap.add_argument("--blind", action="store_true", help="生成盲标表（不显示自动编码结果）")
    ap.add_argument("--pdf-dir", default=None, help="全文 PDF 目录（默认取 .env PATH_FULLTEXT_DIR）")
    ap.add_argument("--check-pdfs", action="store_true", help="检查 PDF 是否齐备并写入 pdf_path 列")
    args = ap.parse_args()

    in_path, _, settings = resolve_io(args, "PATH_STEP6_ORIENTATION", "PATH_STEP6_ORIENTATION")
    if args.input is None:
        # 依次回退到可能存在的中间结果
        for key in ("PATH_STEP5_ESV", "PATH_STEP4_ECOSYSTEM", "PATH_STEP3_LOCATION", "PATH_STEP0_RELEVANCE"):
            candidate = settings.path(key)
            if candidate.exists():
                in_path = candidate
                break

    df = read_table(in_path)
    print(f"输入: {in_path} ({len(df)} 行)")

    id_col = find_column(df, ID_CANDIDATES)
    title_col = find_column(df, ("Article Title", "Document Title", "Title", "title"))
    if id_col is None and title_col is None:
        raise SystemExit("既找不到 ID 列也找不到标题列，无法唯一定位论文。")
    if id_col is None:
        df["paper_id"] = [f"row_{i}" for i in range(len(df))]
        id_col = "paper_id"

    rng = random.Random(args.seed)
    n = min(args.n, len(df))

    if args.stratify and args.stratify in df.columns:
        series = df[args.stratify].fillna("").astype(str)
        classes = [c for c in series.unique() if c]
        per_class = max(args.min_per_class, n // max(len(classes), 1))
        picked: List[int] = []
        for cls in classes:
            idxs = df.index[series == cls].tolist()
            rng.shuffle(idxs)
            picked.extend(idxs[:per_class])
        remaining = [i for i in df.index.tolist() if i not in set(picked)]
        rng.shuffle(remaining)
        picked.extend(remaining[: max(0, n - len(picked))])
        sample = df.loc[sorted(set(picked))]
        print(f"分层抽样: 变量={args.stratify}, 类别数={len(classes)}, 每类>={per_class}, 实际={len(sample)}")
    else:
        idxs = df.index.tolist()
        rng.shuffle(idxs)
        sample = df.loc[sorted(idxs[:n])]
        print(f"简单随机抽样: n={len(sample)} (seed={args.seed})")

    out = pd.DataFrame()
    out["paper_id"] = sample[id_col].astype(str).values
    if title_col:
        out["title"] = sample[title_col].astype(str).values
    for col in ("year", "Year", "Publication Year", "PY", "source", "Source Title", "SO"):
        if col in sample.columns:
            out[col] = sample[col].values

    auto_map = {
        "relevance_class": "relevance_class",
        "study_area_type": "study_area_type",
        "study_area_name": "study_area_name",
        "study_area_country": "study_area_country",
        "ecosystem_primary": "ecosystem_primary",
        "ecosystem_subtype": "ecosystem_subtype",
        "service_primary": "service_primary",
        "service_subtype": "service_subtype",
        "orientation_primary": "orientation_primary",
        "application_type": "application_type",
    }
    for auto_col, src in auto_map.items():
        if src in sample.columns:
            out[f"{AUTO_PREFIX}{auto_col}"] = sample[src].values

    for gold_col, hint in GOLD_COLUMNS.items():
        out[gold_col] = ""
    out["gold_column_hint"] = ""  # 占位，避免 Excel 里看不到提示
    out.attrs = {}

    pdf_path_col = None
    if args.check_pdfs:
        pdf_dir = Path(args.pdf_dir) if args.pdf_dir else Path(settings.paths["PATH_FULLTEXT_DIR"])
        keys = out["paper_id"].astype(str).tolist()
        titles = out["title"].astype(str).tolist() if "title" in out.columns else None
        found = match_pdfs(pdf_dir, keys, titles)
        out["pdf_path"] = [found.get(k, "") for k in keys]
        out["pdf_found"] = [bool(found.get(k)) for k in keys]
        pdf_path_col = "pdf_path"
        n_found = int(out["pdf_found"].sum())
        print(f"PDF 匹配: {n_found}/{len(out)} 命中（目录 {pdf_dir}）")
        if n_found < len(out):
            print("  [提示] 未命中的记录会进入 stepFT2.fulltext_adjudication.py 的跳过清单，可先补齐 PDF。")

    if args.blind:
        blind_cols = [c for c in out.columns if not c.startswith(AUTO_PREFIX)]
        blind = out[blind_cols].copy()
        key = out[["paper_id"] + [c for c in out.columns if c.startswith(AUTO_PREFIX)]].copy()
        out_path = Path(args.output) if args.output else settings.path("PATH_FULLTEXT_SAMPLE_XLSX")
        blind_path = out_path.with_name(out_path.stem + "_BLIND" + out_path.suffix)
        key_path = out_path.with_name(out_path.stem + "_KEY" + out_path.suffix)
        write_table(blind, blind_path)
        write_table(key, key_path)
        print(f"已写出盲标表: {blind_path}")
        print(f"已写出密钥表(含自动结果, 标注完成前请勿交给标注人): {key_path}")
    else:
        out = out.drop(columns=["gold_column_hint"])
        out_path = Path(args.output) if args.output else settings.path("PATH_FULLTEXT_SAMPLE_XLSX")
        write_table(out, out_path)
        print(f"已写出标注表: {out_path}")

    print("\n人工标注须知（对应方案第十八节）:")
    print("  1. 标注者只看全文，不看自动编码结果（建议使用 --blind）；")
    print("  2. 标注规则与 LLM 提示词使用同一套定义与词表；")
    print("  3. 至少两人独立标注，分歧进入 adjudication，最终形成 gold standard；")
    print("  4. gold standard 由人工判定，绝不由 LLM 生成。")
    hints = pd.DataFrame({"gold_column": list(GOLD_COLUMNS.keys()), "allowed_values_or_hint": list(GOLD_COLUMNS.values())})
    hint_path = out_path.with_name(out_path.stem + "_column_hints.csv")
    hints.to_csv(hint_path, index=False, encoding="utf-8-sig")
    print(f"  列取值说明已写出: {hint_path}")


if __name__ == "__main__":
    sys.exit(main())
