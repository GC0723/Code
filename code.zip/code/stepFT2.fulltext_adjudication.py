# -*- coding: utf-8 -*-
"""
脚本名：stepFT2.fulltext_adjudication.py
原文件名：无（本脚本为新增；全文复核与仲裁，Prompt 8）

stepFT2.fulltext_adjudication.py —— 全文复核（Prompt 8 / P8-fulltext-adjudication-v2.0）★新增脚本

全文复核的定位
--------------
本脚本把已合法获取的全文 PDF 用作：

    摘要自动编码结果  ×  全文证据  →  独立复核后的最终标签

用途有两个（两用同一套 prompt）：
  (A) **审计**：抽样复核摘要编码质量，输出 “全文复核后是否仍成立”；
  (B) **仲裁**：当摘要结果与人工全文标注冲突时，用全文证据给出最终标签。

明确不是：PDF → LLM → gold standard。
    gold standard 必须由人工标注产生（stepFT1.fulltext_sample_builder.py）；
    本脚本的输出仅用于复核、分歧仲裁与错误类型分析。

证据层级（prompt 已写入）
-------------------------
    Objectives > Study area > Methods > Results > Conclusions > Introduction/background

输出列（前缀 ft_，逐变量各一组）
--------------------------------
    ft_<var>_final_label          全文复核后的最终标签
    ft_<var>_final_subtype_level  亚类 / 地理层级 / 地理名称
    ft_<var>_agree                是否与摘要自动结果一致 (yes|no|unclear)
    ft_<var>_evidence_location    Objectives | Study area | Methods | Results | Conclusions | Introduction
    ft_<var>_evidence             证据原文片段
    ft_<var>_confidence           high | medium | low
    ft_pdf_backend                PDF 文本抽取后端（复现用）
    ft_text_chars                 送入模型的字符数
    ft_run_at                     处理时间

用法
----
    # 1) 先确认 PDF 可被解析
    python stepFT2.fulltext_adjudication.py --check-pdfs

    # 2) 只复核核心变量（推荐先用金标准样本做小规模预实验）
    python stepFT2.fulltext_adjudication.py --input FT_2_gold_standard.xlsx --variables ORIENTATION
    python stepFT2.fulltext_adjudication.py --input 6_Orientation_out.xlsx --sample 100 --variables ORIENTATION,ECOSYSTEM
    python stepFT2.fulltext_adjudication.py --input FT_2_gold_standard.xlsx --variables RELEVANCE,STUDY_AREA,ECOSYSTEM,ESV_SERVICE,ORIENTATION

    # 3) 只做审计（不写入最终标签，仅输出一致性）
    python stepFT2.fulltext_adjudication.py --audit-only
"""

from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from tqdm import tqdm

import pdf_text
from llm_prompts import (  # noqa: F401  (PROMPT_VERSIONS/SCHEMA_VERSIONS 用于审计记录)
    P8_ALLOWED,
    P8_SCHEMA,
    PROMPT_VERSIONS,
    SCHEMA_VERSIONS,
    get_prompt,
    get_system,
    get_user,
)
from llm_utils import (
    add_common_args,
    as_confidence,
    as_text,
    find_column,
    get_client,
    load_settings,
    read_table,
    safe_cell,
    select_rows,
    write_table,
)

PROMPT_KEY = "fulltext_adjudication"

#: 变量 -> (自动标签列候选, 自动亚类列候选, 金标准列候选)
TARGETS: Dict[str, Dict[str, tuple]] = {
    "RELEVANCE": {
        "auto": ("relevance_class",),
        "auto_sub": (),
        "gold": ("gold_relevance",),
    },
    "STUDY_AREA": {
        "auto": ("study_area_type", "loc_geographic_level"),
        "auto_sub": ("study_area_name", "loc_normalized_name"),
        "gold": ("gold_study_area_type",),
    },
    "ECOSYSTEM": {
        "auto": ("ecosystem_primary", "Ecosystem primary classification"),
        "auto_sub": ("ecosystem_subtype", "Ecosystem sub-classification"),
        "gold": ("gold_ecosystem_primary",),
    },
    "ESV_SERVICE": {
        "auto": ("service_primary", "EST1"),
        "auto_sub": ("service_subtype", "EST2"),
        "gold": ("gold_service_primary",),
    },
    "ORIENTATION": {
        "auto": ("orientation_primary",),
        "auto_sub": ("application_type",),
        "gold": ("gold_orientation",),
    },
}

ID_CANDIDATES = ("UT", "UT (Unique WOS ID)", "Paper ID", "paper_id", "DOI", "DI")


def _norm_for_match(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", safe_cell(text, "").lower())[:60]


def resolve_pdf(row: pd.Series, pdf_dir: Path, pdf_col: Optional[str]) -> str:
    """找到该记录对应的 PDF 路径。"""
    if pdf_col and safe_cell(row.get(pdf_col, ""), ""):
        p = Path(safe_cell(row[pdf_col]))
        if p.exists():
            return str(p)
    if not pdf_dir.exists():
        return ""
    for col in ("paper_id", "UT", "UT (Unique WOS ID)", "DOI", "DI", "title", "Article Title"):
        if col not in row.index:
            continue
        key = safe_cell(row[col], "")
        if not key:
            continue
        if col in ("DOI", "DI") and len(key) > 5:
            token = key.split("/")[-1]
            for pdf in pdf_dir.rglob("*.pdf"):
                if token and token.lower() in pdf.stem.lower():
                    return str(pdf)
        elif col in ("title", "Article Title"):
            nk = _norm_for_match(key)
            if len(nk) < 20:
                continue
            for pdf in pdf_dir.rglob("*.pdf"):
                if nk in _norm_for_match(pdf.stem):
                    return str(pdf)
        else:
            for pdf in pdf_dir.rglob("*.pdf"):
                if key.lower() in pdf.stem.lower():
                    return str(pdf)
    return ""


def main() -> None:
    ap = argparse.ArgumentParser(description="全文复核 / 仲裁（Prompt 8）")
    add_common_args(ap)
    ap.add_argument(
        "--variables",
        default="RELEVANCE,STUDY_AREA,ECOSYSTEM,ESV_SERVICE,ORIENTATION",
        help="要复核的变量（逗号分隔）",
    )
    ap.add_argument("--pdf-dir", default=None, help="PDF 目录（默认取 .env PATH_FULLTEXT_DIR）")
    ap.add_argument("--pdf-col", default="pdf_path", help="表中已记录 PDF 路径的列名")
    ap.add_argument("--check-pdfs", action="store_true", help="只检查 PDF 与文本抽取是否可用")
    ap.add_argument("--audit-only", action="store_true", help="只输出一致性审计，不写最终标签列")
    ap.add_argument("--max-chars", type=int, default=0, help="送入模型的全文最大字符数（0=取配置）")
    args = ap.parse_args()

    settings = load_settings()
    in_path = Path(args.input) if args.input else settings.path("PATH_FULLTEXT_GOLD_XLSX")
    if not in_path.exists():
        alt = settings.path("PATH_STEP6_ORIENTATION")
        if alt.exists():
            print(f"[提示] 未找到 {in_path.name}，改用 {alt.name}")
            in_path = alt
        else:
            raise SystemExit(f"输入文件不存在: {in_path}")

    pdf_dir = Path(args.pdf_dir) if args.pdf_dir else Path(settings.paths["PATH_FULLTEXT_DIR"])
    backends = pdf_text.available_backends()
    print(f"输入: {in_path} ({len(read_table(in_path))} 行)")
    print(f"PDF 目录: {pdf_dir}")
    print(f"PDF 文本后端: {backends if backends else '【无】——请安装 poppler(pdftotext) 或 pymupdf/pypdf'}")

    df = read_table(in_path)
    pdf_col = args.pdf_col if args.pdf_col in df.columns else None

    if args.check_pdfs:
        n_found = n_text = 0
        sample_rows = df.head(min(len(df), 50))
        for _, row in sample_rows.iterrows():
            path = resolve_pdf(row, pdf_dir, pdf_col)
            if path:
                n_found += 1
                text, backend = pdf_text.extract_text(path, max_chars=20000)
                if text:
                    n_text += 1
        print(f"[检查] 前 {len(sample_rows)} 行: 找到 PDF {n_found} 个, 成功抽取文本 {n_text} 个")
        if n_text == 0:
            print("  [处理建议] 安装 pdftotext: 下载 poppler for Windows 并加入 PATH；或 pip install pymupdf")
        return

    if args.dry_run:
        print(f"[dry-run] 将复核变量: {args.variables}")
        return

    if not settings.has_api_key:
        raise SystemExit("未找到 API Key，请配置 .env 中的 DEEPSEEK_API_KEY。")

    variables = [v.strip().upper() for v in args.variables.split(",") if v.strip()]
    variables = [v for v in variables if v in TARGETS]
    if not variables:
        raise SystemExit(f"没有有效变量；可用: {sorted(TARGETS)}")

    client = get_client(settings)
    system_prompt = get_system(PROMPT_KEY)
    max_chars = args.max_chars or int(settings.fulltext.get("max_chars", 120000))
    max_pages = int(settings.fulltext.get("max_pages", 0) or 0)

    out_cols: List[str] = ["ft_pdf_path", "ft_pdf_backend", "ft_text_chars", "ft_run_at"]
    for var in variables:
        prefix = f"ft_{var.lower()}"
        out_cols += [
            f"{prefix}_final_label",
            f"{prefix}_final_subtype_level",
            f"{prefix}_agree",
            f"{prefix}_evidence_location",
            f"{prefix}_evidence",
            f"{prefix}_confidence",
        ]
    for col in out_cols:
        if col not in df.columns:
            df[col] = ""

    if args.sample:
        targets = set(select_rows(df, args))
    else:
        targets = set(select_rows(df, args)) if (args.sample or args.limit) else set(range(len(df)))

    stamp = datetime.now().isoformat(timespec="seconds")
    n_ok = n_fail = n_nopdf = n_skip = 0

    bar = tqdm(total=len(targets), desc="Prompt8 全文复核", unit="row")
    for idx in sorted(targets):
        if not args.force and safe_cell(df.at[idx, out_cols[0]], "") and safe_cell(df.at[idx, f"ft_{variables[0].lower()}_final_label"], ""):
            n_skip += 1
            bar.update(1)
            continue

        row = df.loc[idx]
        pdf_path = resolve_pdf(row, pdf_dir, pdf_col)
        text, backend = pdf_text.extract_text(pdf_path, max_chars=max_chars, max_pages=max_pages) if pdf_path else ("", "missing")
        df.at[idx, "ft_pdf_path"] = pdf_path
        df.at[idx, "ft_pdf_backend"] = backend
        df.at[idx, "ft_text_chars"] = len(text)
        df.at[idx, "ft_run_at"] = stamp

        if not text:
            n_nopdf += 1
            for var in variables:
                df.at[idx, f"ft_{var.lower()}_final_label"] = "NO_FULLTEXT"
            bar.update(1)
            continue

        for var in variables:
            spec = TARGETS[var]
            auto_col = find_column(df, spec["auto"])
            auto_sub_col = find_column(df, spec["auto_sub"])
            gold_col = find_column(df, spec["gold"])

            auto_label = safe_cell(row.get(auto_col, ""), "") if auto_col else ""
            auto_sub = safe_cell(row.get(auto_sub_col, ""), "") if auto_sub_col else ""
            gold_label = safe_cell(row.get(gold_col, ""), "") if gold_col else ""

            allowed = P8_ALLOWED.get(var, {"labels": ["UNKNOWN"], "subtypes": ["UNKNOWN"]})
            rec = client.classify(
                system_prompt,
                get_user(
                    PROMPT_KEY,
                    target_variable=var,
                    auto_label=auto_label or "(absent)",
                    auto_subtype=auto_sub or "(absent)",
                    auto_evidence="(见对应 evidence 列)",
                    allowed_labels=" | ".join(allowed["labels"]),
                    allowed_subtypes=" | ".join(allowed["subtypes"]),
                    fulltext=text,
                ),
                schema=None if args.audit_only else P8_SCHEMA,
                schema_name="fulltext_adjudication_v2",
                prompt_version=PROMPT_VERSIONS[PROMPT_KEY],
                max_tokens=600,
                required_keys=["final_label", "evidence", "confidence"],
            )

            prefix = f"ft_{var.lower()}"
            if not rec.ok:
                df.at[idx, f"{prefix}_final_label"] = "__FAILED__"
                df.at[idx, f"{prefix}_evidence"] = f"CALL_FAILED: {rec.error}"[:400]
                n_fail += 1
                continue

            data = rec.data
            final_label = as_text(data.get("final_label"), "UNKNOWN")
            final_sub = as_text(data.get("final_subtype_or_level"), "UNKNOWN")
            agree = as_text(data.get("agree_with_abstract_only_label"), "unclear")
            loc = as_text(data.get("evidence_location"), "Introduction")

            df.at[idx, f"{prefix}_final_label"] = final_label
            df.at[idx, f"{prefix}_final_subtype_level"] = final_sub
            if gold_label:
                agree = "yes" if final_label.strip().lower() == gold_label.strip().lower() else "no"
            df.at[idx, f"{prefix}_agree"] = agree
            df.at[idx, f"{prefix}_evidence_location"] = loc
            df.at[idx, f"{prefix}_evidence"] = as_text(data.get("evidence"), "")[:1000]
            df.at[idx, f"{prefix}_confidence"] = as_confidence(data.get("confidence"))
            n_ok += 1

        bar.update(1)
        if (idx + 1) % max(1, settings.save_every) == 0:
            try:
                write_table(df, settings.path("PATH_FULLTEXT_RESULT_XLSX"))
            except Exception:
                pass

    bar.close()

    out_path = settings.path("PATH_FULLTEXT_RESULT_XLSX")
    if args.audit_only:
        out_path = out_path.with_name(f"{out_path.stem}_audit{out_path.suffix}")
    write_table(df, out_path)

    print(f"\n=== 全文复核完成 ===")
    print(f"  使用变量: {variables}")
    print(f"  成功判定: {n_ok}   调用失败: {n_fail}   无全文: {n_nopdf}   续跑跳过: {n_skip}")
    print(f"  输出: {out_path}")
    print("\n  与摘要自动结果的一致性（这是论文里的审计证据）:")
    for var in variables:
        col = f"ft_{var.lower()}_agree"
        try:
            vc = df[col].fillna("").astype(str).value_counts()
            yes, no = int(vc.get("yes", 0)), int(vc.get("no", 0))
            denom = max(yes + no, 1)
            print(f"    {var:12s} agree={yes:5d}  disagree={no:5d}  一致率={yes / denom * 100:5.2f}%")
        except Exception:
            continue
    print("\n  [论文提示] gold standard 必须来自人工标注；本脚本输出用于")
    print("             (1) 摘要编码审计; (2) 摘要结果与人工标注冲突时的仲裁;")


if __name__ == "__main__":
    sys.exit(main())
