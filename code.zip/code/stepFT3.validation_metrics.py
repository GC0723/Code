# -*- coding: utf-8 -*-
"""
脚本名：stepFT3.validation_metrics.py
原文件名：无（本脚本为新增；与人工 gold standard 比对 P/R/F1/κ/CI）

stepFT3.validation_metrics.py —— 与全文金标准比对，计算 P / R / F1 / κ / 95% CI ★新增脚本

方案第十九节③ 明确要求：
    「不要把模型自报的 confidence 当成准确率。
      真正的可靠性必须来自 412 篇 gold standard → Precision/Recall/F1/κ/CI。」

本脚本就是这条要求的具体实现：

输入
----
1. 自动编码结果表（Pipeline 输出，如 6_Orientation_out.xlsx），列名含：
       relevance_class / study_area_type / ecosystem_primary /
       service_primary / orientation_primary
2. 全文金标准表（独立人工标注，方案第十八节：PDF → 人工标注 → gold standard），
   键列为 Paper ID / UT / DOI / Title 之一，各变量列为 gold_relevance /
   gold_study_area_type / gold_ecosystem_primary / gold_service_primary /
   gold_orientation（也可用 gold_<变量名> 的任意组合）

输出
----
    validation_metrics.csv/xlsx   每个变量 × {label, subtype} 的
        n, accuracy, macro_P/R/F1, per-class P/R/F1, Cohen's κ,
        bootstrap 95% CI（accuracy 与 macro-F1）, 混淆矩阵（JSON 字符串）
    validation_confusion.xlsx     每个变量的混淆矩阵（单独 sheet）
    validation_summary.txt        可直接写进论文的英文汇总段落

特殊处理
--------
- ORIENTATION 变量额外输出 PTR 的上下界（UNCERTAIN→THEORY / →PRACTICE）以及
  gold 与 LLM 的一致性；
- 缺失预测/缺失金标准一律单列统计，不静默丢弃。

用法
----
    python stepFT3.validation_metrics.py --pred 6_Orientation_out.xlsx --gold gold.xlsx --id-col UT
    python stepFT3.validation_metrics.py --pred 5_EST_out.xlsx --gold gold.xlsx --gold-prefix gold_
    python stepFT3.validation_metrics.py --gold gold.xlsx --pred-dir .
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from llm_utils import add_common_args, find_column, load_settings, read_table, safe_cell, write_table

#: 变量名 -> (预测列候选, 金标准列候选, 亚类列候选)
VARIABLE_SPECS: Dict[str, Dict[str, Sequence[str]]] = {
    "RELEVANCE": {
        "pred": ("relevance_class",),
        "gold": ("gold_relevance", "gold_relevance_class", "relevance_class_gold"),
        "sub": (),
    },
    "STUDY_AREA_LEVEL": {
        "pred": ("study_area_type", "loc_geographic_level"),
        "gold": ("gold_study_area_type", "gold_geographic_level"),
        "sub": ("study_area_name",),
    },
    "STUDY_AREA_NAME": {
        "pred": ("study_area_name", "loc_normalized_name"),
        "gold": ("gold_study_area_name", "gold_study_area"),
        "sub": ("study_area_type",),
    },
    "ECOSYSTEM_PRIMARY": {
        "pred": ("ecosystem_primary", "Ecosystem primary classification"),
        "gold": ("gold_ecosystem_primary", "gold_ecosystem"),
        "sub": ("ecosystem_subtype",),
    },
    "ECOSYSTEM_SUBTYPE": {
        "pred": ("ecosystem_subtype", "Ecosystem sub-classification"),
        "gold": ("gold_ecosystem_subtype",),
        "sub": (),
    },
    "SERVICE_PRIMARY": {
        "pred": ("service_primary", "EST1"),
        "gold": ("gold_service_primary", "gold_esv_service"),
        "sub": ("service_subtype",),
    },
    "SERVICE_SUBTYPE": {
        "pred": ("service_subtype", "EST2"),
        "gold": ("gold_service_subtype",),
        "sub": (),
    },
    "ORIENTATION": {
        "pred": ("orientation_primary",),
        "gold": ("gold_orientation", "gold_orientation_primary"),
        "sub": ("application_type",),
    },
}

ID_CANDIDATES = ("UT", "UT (Unique WOS ID)", "Paper ID", "paper_id", "DOI", "DI", "Title", "Article Title")


# =============================================================================
# 指标计算（用 sklearn 若可用，否则用纯 numpy 实现，结果一致）
# =============================================================================
def _labels(y_true: Sequence[str], y_pred: Sequence[str]) -> List[str]:
    return sorted(set(list(y_true) + list(y_pred)))


def confusion_matrix(y_true: List[str], y_pred: List[str], labels: List[str]) -> np.ndarray:
    idx = {lab: i for i, lab in enumerate(labels)}
    cm = np.zeros((len(labels), len(labels)), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[idx[t], idx[p]] += 1
    return cm


def prf_per_class(cm: np.ndarray, labels: List[str]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, Dict[str, float]] = {}
    tp_all = cm.sum()
    for i, lab in enumerate(labels):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        support = int(cm[i, :].sum())
        out[lab] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": support,
            "prevalence": support / tp_all if tp_all else 0.0,
        }
    return out


def macro_scores(per_class: Dict[str, Dict[str, float]]) -> Tuple[float, float, float]:
    if not per_class:
        return 0.0, 0.0, 0.0
    p = np.mean([v["precision"] for v in per_class.values()])
    r = np.mean([v["recall"] for v in per_class.values()])
    f = np.mean([v["f1"] for v in per_class.values()])
    return float(p), float(r), float(f)


def cohens_kappa(y_true: List[str], y_pred: List[str], labels: List[str]) -> float:
    try:
        from sklearn.metrics import cohen_kappa_score  # type: ignore

        return float(cohen_kappa_score(y_true, y_pred, labels=labels))
    except Exception:
        cm = confusion_matrix(y_true, y_pred, labels)
        n = cm.sum()
        if n == 0:
            return float("nan")
        po = np.trace(cm) / n
        pe = float((cm.sum(axis=0) * cm.sum(axis=1)).sum()) / (n * n)
        return float((po - pe) / (1 - pe)) if pe != 1 else float("nan")


def bootstrap_ci(
    y_true: List[str],
    y_pred: List[str],
    labels: List[str],
    n_boot: int = 2000,
    seed: int = 20240101,
    alpha: float = 0.05,
) -> Dict[str, Tuple[float, float]]:
    rng = random.Random(seed)
    n = len(y_true)
    if n < 5:
        return {"accuracy": (float("nan"), float("nan")), "macro_f1": (float("nan"), float("nan"))}

    accs, f1s = [], []
    for _ in range(n_boot):
        idx = [rng.randrange(n) for _ in range(n)]
        yt = [y_true[i] for i in idx]
        yp = [y_pred[i] for i in idx]
        labs = sorted(set(yt) | set(yp))
        if len(labs) < 2:
            continue
        cm = confusion_matrix(yt, yp, labs)
        accs.append(float(np.trace(cm)) / cm.sum())
        _, _, f1 = macro_scores(prf_per_class(cm, labs))
        f1s.append(f1)

    def _ci(vals: List[float]) -> Tuple[float, float]:
        if not vals:
            return (float("nan"), float("nan"))
        vals.sort()
        lo = vals[int(alpha / 2 * len(vals))]
        hi = vals[min(len(vals) - 1, int((1 - alpha / 2) * len(vals)))]
        return (float(lo), float(hi))

    return {"accuracy": _ci(accs), "macro_f1": _ci(f1s)}


def evaluate_variable(
    name: str,
    y_true: List[str],
    y_pred: List[str],
    n_boot: int = 2000,
    extra_rows: Optional[List[Dict]] = None,
) -> Tuple[List[Dict], Dict[str, List[List[int]]], List[str]]:
    """返回 (指标行列表, {变量: 混淆矩阵}, labels)。"""
    labels = _labels(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred, labels)
    per_class = prf_per_class(cm, labels)
    acc = float(np.trace(cm)) / cm.sum() if cm.sum() else float("nan")
    macro_p, macro_r, macro_f1 = macro_scores(per_class)
    kappa = cohens_kappa(y_true, y_pred, labels)
    ci = bootstrap_ci(y_true, y_pred, labels, n_boot=n_boot)

    rows: List[Dict] = [{
        "variable": name,
        "level": "aggregate",
        "label": "",
        "n": int(cm.sum()),
        "n_classes": len(labels),
        "accuracy": round(acc, 4),
        "accuracy_ci_low": round(ci["accuracy"][0], 4),
        "accuracy_ci_high": round(ci["accuracy"][1], 4),
        "macro_precision": round(macro_p, 4),
        "macro_recall": round(macro_r, 4),
        "macro_f1": round(macro_f1, 4),
        "macro_f1_ci_low": round(ci["macro_f1"][0], 4),
        "macro_f1_ci_high": round(ci["macro_f1"][1], 4),
        "cohens_kappa": round(kappa, 4) if kappa == kappa else None,
        "support": "",
        "prevalence": "",
        "confusion_matrix": json.dumps({"labels": labels, "matrix": cm.tolist()}, ensure_ascii=False),
    }]

    for lab, m in per_class.items():
        rows.append({
            "variable": name,
            "level": "class",
            "label": lab,
            "n": int(cm.sum()),
            "n_classes": len(labels),
            "accuracy": "",
            "accuracy_ci_low": "",
            "accuracy_ci_high": "",
            "macro_precision": round(m["precision"], 4),
            "macro_recall": round(m["recall"], 4),
            "macro_f1": round(m["f1"], 4),
            "macro_f1_ci_low": "",
            "macro_f1_ci_high": "",
            "cohens_kappa": "",
            "support": int(m["support"]),
            "prevalence": round(float(m["prevalence"]), 4),
            "confusion_matrix": "",
        })

    if extra_rows:
        rows.extend(extra_rows)

    return rows, {name: cm.tolist()}, labels


# =============================================================================
# 主流程
# =============================================================================
def _align(pred: pd.DataFrame, gold: pd.DataFrame, id_col: Optional[str]) -> Tuple[pd.DataFrame, pd.DataFrame, str]:
    """按 ID 或行序对齐预测与金标准。"""
    if id_col and id_col in pred.columns and id_col in gold.columns:
        p = pred.copy()
        g = gold.copy()
        p["__key"] = p[id_col].astype(str).str.strip().str.lower()
        g["__key"] = g[id_col].astype(str).str.strip().str.lower()
        merged = p.merge(g, on="__key", how="inner", suffixes=("", "_gold"))
        if len(merged) == 0:
            raise SystemExit(f"按 {id_col} 对齐后没有匹配记录，请检查 ID 列取值。")
        return merged, merged, id_col

    if len(pred) != len(gold):
        raise SystemExit(
            f"行数不一致（预测 {len(pred)} vs 金标准 {len(gold)}），且未找到共同 ID 列。"
            "请用 --id-col 指定 ID 列，或先准备行数一致的金标准表。"
        )
    merged = pred.copy()
    for c in gold.columns:
        if c not in merged.columns:
            merged[c] = gold[c].values
    return merged, merged, "(row order)"


def main() -> None:
    settings = load_settings()
    ap = argparse.ArgumentParser(description="与全文金标准比对：P/R/F1/kappa/CI")
    ap.add_argument("--pred", default=None, help="自动编码结果表")
    ap.add_argument("--gold", default=None, help="全文金标准表（默认取 .env PATH_FULLTEXT_GOLD_XLSX）")
    ap.add_argument("--id-col", default=None, help="用于对齐的 ID 列（如 UT / DOI / Title）")
    ap.add_argument("--bootstrap", type=int, default=2000, help="bootstrap 次数")
    ap.add_argument("--out", default=None, help="指标输出表路径")
    ap.add_argument("--sheet", default=None, help="若预测表含多个步骤结果，可指定 sheet（暂支持单 sheet）")
    args = ap.parse_args()

    gold_path = Path(args.gold) if args.gold else settings.path("PATH_FULLTEXT_GOLD_XLSX")
    if not gold_path.exists():
        raise SystemExit(f"金标准文件不存在: {gold_path}\n请先用 stepFT1.fulltext_sample_builder.py 生成抽样表并完成人工标注。")

    pred_path = Path(args.pred) if args.pred else settings.path("PATH_STEP6_ORIENTATION")
    if not pred_path.exists():
        raise SystemExit(f"预测文件不存在: {pred_path}")

    out_path = Path(args.out) if args.out else settings.path("PATH_METRICS_XLSX")

    pred_df = read_table(pred_path)
    gold_df = read_table(gold_path)
    print(f"预测表: {pred_path} ({len(pred_df)} 行)")
    print(f"金标准: {gold_path} ({len(gold_df)} 行)")

    id_col = args.id_col or find_column(pd.concat([pred_df.head(0), gold_df.head(0)], axis=1), ID_CANDIDATES)
    print(f"对齐方式: {id_col}")
    merged, _, how = _align(pred_df, gold_df, id_col)
    print(f"对齐后样本量: {len(merged)}")

    all_rows: List[Dict] = []
    matrices: Dict[str, List[List[int]]] = {}
    summary_lines: List[str] = []

    for var, spec in VARIABLE_SPECS.items():
        pred_col = find_column(merged, spec["pred"])
        gold_col = find_column(merged, spec["gold"])
        if pred_col is None or gold_col is None:
            continue

        pair = merged[[pred_col, gold_col]].copy()
        pair.columns = ["pred", "gold"]
        pair["pred"] = pair["pred"].map(lambda v: safe_cell(v, ""))
        pair["gold"] = pair["gold"].map(lambda v: safe_cell(v, ""))
        valid = pair[(pair["pred"] != "") & (pair["gold"] != "")]
        n_missing = len(pair) - len(valid)
        if len(valid) < 5:
            print(f"[跳过] {var}: 有效配对样本不足 ({len(valid)})")
            continue

        y_true = valid["gold"].tolist()
        y_pred = valid["pred"].tolist()

        extra: List[Dict] = []
        if var == "ORIENTATION":
            col = pd.Series(y_pred)
            n_practice = int((col == "PRACTICE_ORIENTED").sum())
            n_uncertain = int((col == "UNCERTAIN").sum())
            denom = len(col)
            extra.append({
                "variable": var,
                "level": "ptr",
                "label": "PTR_lower(UNCERTAIN->THEORY)",
                "n": denom,
                "accuracy": round(n_practice / denom, 4) if denom else "",
                "macro_f1": "",
                "macro_precision": "",
                "macro_recall": "",
                "confusion_matrix": "",
            })
            extra.append({
                "variable": var,
                "level": "ptr",
                "label": "PTR_upper(UNCERTAIN->PRACTICE)",
                "n": denom,
                "accuracy": round((n_practice + n_uncertain) / denom, 4) if denom else "",
                "macro_f1": "",
                "macro_precision": "",
                "macro_recall": "",
                "confusion_matrix": "",
            })

        rows, cms, labels = evaluate_variable(var, y_true, y_pred, n_boot=args.bootstrap, extra_rows=extra)
        agg = rows[0]
        agg["missing_pairs"] = int(n_missing)
        agg["aligned_by"] = how
        all_rows.extend(rows)
        matrices.update(cms)

        summary_lines.append(
            f"{var}: n={agg['n']}, accuracy={agg['accuracy']} "
            f"[{agg['accuracy_ci_low']}, {agg['accuracy_ci_high']}], "
            f"macro-F1={agg['macro_f1']} [{agg['macro_f1_ci_low']}, {agg['macro_f1_ci_high']}], "
            f"kappa={agg['cohens_kappa']}, missing={n_missing}"
        )
        print(f"[{var}] n={agg['n']} acc={agg['accuracy']} macroF1={agg['macro_f1']} kappa={agg['cohens_kappa']}")

    if not all_rows:
        raise SystemExit(
            "没有可比对的变量。请确认金标准表列名形如 gold_relevance / gold_ecosystem_primary / "
            "gold_service_primary / gold_orientation / gold_study_area_type。"
        )

    metrics_df = pd.DataFrame(all_rows)
    metrics_df["generated_at"] = datetime.now().isoformat(timespec="seconds")
    metrics_df["pred_file"] = str(pred_path)
    metrics_df["gold_file"] = str(gold_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        metrics_df.to_excel(writer, sheet_name="metrics", index=False)
        for var, cm in matrices.items():
            labels = sorted(set(metrics_df.loc[(metrics_df.variable == var) & (metrics_df.level == "class"), "label"].tolist()))
            if not labels:
                continue
            cm_df = pd.DataFrame(cm, index=[f"gold::{l}" for l in labels], columns=[f"pred::{l}" for l in labels])
            cm_df.to_excel(writer, sheet_name=f"cm_{var}"[:31])
    print(f"\n已写出指标表: {out_path}")

    txt_path = out_path.with_suffix(".txt")
    header = [
        "Validation of LLM-based coding against the full-text gold standard",
        f"Predicted file: {pred_path.name}",
        f"Gold standard:  {gold_path.name}",
        f"Aligned by:     {how}",
        f"Model: {settings.model} | temperature: {settings.temperature}",
        f"Bootstrap resamples: {args.bootstrap} (95% CI)",
        "",
    ]
    txt_path.write_text("\n".join(header + summary_lines) + "\n", encoding="utf-8")
    print(f"已写出英文摘要: {txt_path}")
    print("\n=== 论文可直接引用 ===")
    for line in summary_lines:
        print("  " + line)


if __name__ == "__main__":
    sys.exit(main())
