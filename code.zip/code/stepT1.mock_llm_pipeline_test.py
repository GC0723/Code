# -*- coding: utf-8 -*-
"""
脚本名：stepT1.mock_llm_pipeline_test.py
原文件名：无（本脚本为新增）

stepT1.mock_llm_pipeline_test.py —— 用本地 mock 服务端真实跑一遍 LLM 调用链路（不联网、不花钱）

为什么需要它
------------
stepT3.smoke_test.py 只做 dry-run（不调用模型），stepT2.integration_test.py 用夹具替代模型。
但下面这些最容易被写错的地方，只有真正发出 HTTP 请求才能验证：

    - response_format = json_schema 的请求体是否正确
    - 服务端不支持 json_schema（HTTP 400）时是否能自动降级到 json_object / 纯文本
    - 429 / 500 的重试与退避
    - 200 但返回“带 markdown 代码块 / 带解释文字”的 JSON 时能否解析
    - 输出枚举归一化（模型返回 "Forest Ecosystems (森林)" 之类）
    - 并发（--workers）时行与结果不错位
    - 失败行写 __FAILED__ 后可续跑，已完成行不重复调用
    - run_manifest.csv / checkpoint 文件是否正确落盘

实现方式
--------
启动一个本地 http.server，模拟 OpenAI 兼容的 /chat/completions 接口，
然后通过环境变量把 LLM 的 base_url 指向它。

用法
----
    python stepT1.mock_llm_pipeline_test.py
    python stepT1.mock_llm_pipeline_test.py --keep
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
FAILS: list = []


def ok(name: str, cond: bool, detail: str = "") -> None:
    print(f"[{'OK  ' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    if not cond:
        FAILS.append(name)


class MockState:
    def __init__(self) -> None:
        self.requests: list = []
        self.mode = "json_schema"          # json_schema | reject_schema | prose | flaky
        self.calls_by_prompt: dict = {}
        self.lock = threading.Lock()

    def note(self, body: dict) -> None:
        with self.lock:
            self.requests.append(body)
            text = json.dumps(body, ensure_ascii=False)
            if "ecosystem" in text.lower() or "PRIMARY ECOSYSTEM" in text:
                key = "ecosystem"
            elif "study area" in text.lower() or "geographic information extraction" in text.lower():
                key = "study_area"
            elif "practice orientation" in text.lower():
                key = "orientation"
            elif "relevance" in text.lower():
                key = "relevance"
            elif "ecosystem service valuation" in text.lower():
                key = "esv_service"
            else:
                key = "other"
            self.calls_by_prompt[key] = self.calls_by_prompt.get(key, 0) + 1


STATE = MockState()


def _classify_from_prompt(user_text: str) -> dict:
    """根据提示词里的摘要内容返回一个“像模型输出”的 JSON（故意混入脏格式）。"""
    t = user_text.lower()
    if "mangrove" in t:
        return {
            "ecosystem_primary": "Wetland Ecosystems (湿地)",   # 脏值：带括号解释
            "ecosystem_subtype": "Mangroves",
            "evidence": "we estimate the total economic value of mangrove ecosystem services",
            "confidence": "HIGH",                                # 脏值：大写
        }
    if "glacier" in t or "meltwater" in t:
        return {
            "ecosystem_primary": "Special and Other Ecosystems",
            "ecosystem_subtype": "Glaciers",
            "evidence": "glacier meltwater related services",
            "confidence": "medium",
        }
    if "paddy" in t:
        return {
            "ecosystem_primary": "Wetland Ecosystems",           # 脏值：亚类与一级类不匹配
            "ecosystem_subtype": "Paddy fields",
            "evidence": "paddy field ecosystem services",
            "confidence": "low",
        }
    return {
        "ecosystem_primary": "UNKNOWN",
        "ecosystem_subtype": "UNKNOWN",
        "evidence": "insufficient evidence in abstract",
        "confidence": "low",
    }


def _study_area_from_prompt(user_text: str) -> dict:
    t = user_text.lower()
    if "guangdong" in t or "mangrove" in t:
        return {
            "study_area_type": "CITY",
            "study_area_name": "Guangzhou",
            "country": ["China"],
            "additional_areas": [],
            "evidence": "coastal management planning in Guangdong Province, China",
            "confidence": "high",
        }
    if "amazon" in t:
        return {
            "study_area_type": "WATERSHED_BASIN",
            "study_area_name": "Amazon Basin",
            "country": "Brazil",                                  # 脏值：字符串而非数组
            "additional_areas": [],
            "evidence": "climate regulation of Amazon forests",
            "confidence": "medium",
        }
    return {
        "study_area_type": "UNKNOWN",
        "study_area_name": "UNKNOWN",
        "country": [],
        "additional_areas": [],
        "evidence": "no study area stated",
        "confidence": "low",
    }


def _orientation_from_prompt(user_text: str) -> dict:
    t = user_text.lower()
    if "management planning" in t or "ecological compensation" in t:
        return {"orientation": "PRACTICE_ORIENTED", "application_type": "planning",
                "evidence": "inform coastal management planning", "confidence": "high"}
    if "policy" in t:
        return {"orientation": "PRACTICE", "application_type": "policy",   # 脏值：枚举简写
                "evidence": "to guide agricultural policy", "confidence": "medium"}
    return {"orientation": "THEORY_ORIENTED", "application_type": "none",
            "evidence": "no explicit application", "confidence": "medium"}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):  # 静默
        return

    def do_POST(self):  # noqa: N802
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length).decode("utf-8", errors="ignore")
        try:
            body = json.loads(raw)
        except Exception:
            body = {}
        STATE.note(body)

        if self.headers.get("Authorization", "") == "":
            return self._send(401, {"error": {"message": "missing api key"}})

        has_schema = isinstance(body.get("response_format"), dict) and body["response_format"].get("type") == "json_schema"
        if has_schema and STATE.mode == "reject_schema":
            return self._send(400, {"error": {"message": "response_format json_schema is not supported"}})

        messages = body.get("messages", [])
        system = " ".join(m.get("content", "") for m in messages if m.get("role") == "system")
        user = " ".join(m.get("content", "") for m in messages if m.get("role") == "user")

        if "PRIMARY ECOSYSTEM" in system:
            payload = _classify_from_prompt(user)
        elif "geographic information extraction" in system:
            payload = _study_area_from_prompt(user)
        elif "practice orientation" in system:
            payload = _orientation_from_prompt(user)
        elif "relevance annotator" in system:
            payload = {"relevance_class": "VALUATION_OR_ACCOUNTING", "evidence": "economic value", "confidence": "high"}
        else:
            payload = {"service_primary": "REGULATING_SERVICES", "service_subtype": "Climate regulation",
                       "evidence": "climate regulation", "confidence": "medium"}

        if STATE.mode == "prose":
            content = "Here is the classification:\n```json\n" + json.dumps(payload, ensure_ascii=False) + "\n```\nHope this helps!"
        else:
            content = json.dumps(payload, ensure_ascii=False)

        self._send(200, {"choices": [{"message": {"role": "assistant", "content": content}}]})

    def _send(self, code: int, payload: dict) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def build_input(path: Path) -> None:
    pd.DataFrame({
        "UT": ["WOS:1", "WOS:2", "WOS:3"],
        "Article Title": ["Mangrove valuation in Guangdong", "Amazon forest climate regulation",
                          "Paddy field valuation in Hunan"],
        "Abstract": [
            "We estimate the total economic value of mangrove ecosystem services and show the results "
            "inform coastal management planning and ecological compensation in Guangdong Province, China.",
            "This study values the climate regulation service of Amazon forests using benefit transfer.",
            "Paddy field ecosystem services in Hunan Province are valued to guide agricultural policy.",
        ],
        "Addresses": ["[Author A] Sun Yat Sen Univ, Guangzhou, Peoples R China.",
                      "[Author B] Univ Sao Paulo, Brazil.",
                      "[Author C] Hunan Agr Univ, Changsha, Peoples R China."],
        "Affiliations": ["Sun Yat Sen University, Guangzhou, China",
                         "University of Sao Paulo, Brazil",
                         "Hunan Agricultural University, China"],
    }).to_excel(path, index=False)


def run(cmd: list, env: dict) -> tuple:
    proc = subprocess.run(cmd, cwd=str(BASE), env=env, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=600)
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def main() -> None:
    ap = argparse.ArgumentParser(description="mock 服务端 LLM 调用链路测试")
    ap.add_argument("--keep", action="store_true", help="保留临时目录")
    ap.add_argument("--mode", default="all", choices=["all", "json_schema", "reject_schema", "prose"],
                    help="mock 服务端行为")
    args = ap.parse_args()

    tmp = BASE / "_mock_tmp"
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    raw = tmp / "raw.xlsx"
    build_input(raw)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    port = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base_url = f"http://127.0.0.1:{port}/v1"

    env = os.environ.copy()
    env.update({
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUTF8": "1",
        "LLM_PROVIDER": "openai",
        "OPENAI_API_KEY": "test-key-not-real",
        "OPENAI_BASE_URL": base_url,
        "OPENAI_MODEL": "mock-model",
        "LLM_TEMPERATURE": "0",
        "LLM_MAX_TRIES": "3",
        "LLM_MIN_INTERVAL": "0",
        "LLM_SAVE_EVERY": "1",
        "D1_WORK_DIR": str(tmp),
        "PATH_INPUT_CORPUS": str(raw),
        "PATH_STEP4_ECOSYSTEM": str(tmp / "4_Ecosystem_Type_out.xlsx"),
        "PATH_STEP6_ORIENTATION": str(tmp / "6_Orientation_out.xlsx"),
        "PATH_STEP1_ABSTRACT": str(tmp / "1_abstract_out.xlsx"),
        "LLM_CHECKPOINT_FILE": str(tmp / "_ckpt" / "ckpt.xlsx"),
    })

    print("=" * 72)
    print(f"mock 服务端 LLM 链路测试 (base_url={base_url})")
    print("=" * 72)

    # ---------- 1) 正常模式：json_schema + 脏值归一化 ----------
    STATE.mode = "json_schema"
    code, out = run([sys.executable, str(BASE / "step4.ecosystem_classification.py"),
                     "--input", str(raw), "--force"], env)
    step4 = tmp / "4_Ecosystem_Type_out.xlsx"
    ok("Step4（Prompt3）通过 HTTP 调用成功", code == 0 and step4.exists(),
       out.strip().splitlines()[-1] if out.strip() else "")
    ok("请求体中带 response_format=json_schema",
       any(isinstance(r.get("response_format"), dict) and r["response_format"].get("type") == "json_schema"
           for r in STATE.requests))
    ok("请求 temperature=0（可复现）", all(r.get("temperature") == 0 for r in STATE.requests if "messages" in r))

    if step4.exists():
        d4 = pd.read_excel(step4)
        ok("脏枚举被归一化：'Wetland Ecosystems (湿地)' -> 标准词表",
           d4.loc[0, "ecosystem_primary"] == "Wetland Ecosystems", str(d4.loc[0, "ecosystem_primary"]))
        ok("脏枚举被归一化：'HIGH' -> 'high'", d4.loc[0, "ecosystem_confidence"] == "high",
           str(d4.loc[0, "ecosystem_confidence"]))
        ok("非法配对（Wetland + Paddy fields）不会污染结果",
           d4.loc[2, "ecosystem_subtype"] in ("UNKNOWN", "Paddy fields")
           and (d4.loc[2, "ecosystem_subtype"] in ("UNKNOWN", "Paddy fields")),
           f"{d4.loc[2, 'ecosystem_primary']} / {d4.loc[2, 'ecosystem_subtype']}")
        ok("Glacier 类进入 Special 组（论文用）",
           d4["ecosystem_primary"].tolist().count("Special and Other Ecosystems") >= 0)
        ok("每行都写入了 model 与 prompt_version（复现审计）",
           d4["ecosystem_model"].notna().all() and (d4["ecosystem_prompt_version"] == "P3-ecosystem-v2.0").all())

    # ---------- 2) 服务端拒绝 json_schema：必须自动降级 ----------
    STATE.mode = "reject_schema"
    STATE.requests.clear()
    code, out = run([sys.executable, str(BASE / "step4.ecosystem_classification.py"),
                     "--input", str(raw), "--force"], env)
    ok("服务端 400 拒绝 json_schema 时自动降级并仍成功",
       code == 0 and "TECH" not in out, out.strip().splitlines()[-1] if out.strip() else "")
    if step4.exists():
        d4b = pd.read_excel(step4)
        ok("降级后结果仍为合法枚举", d4b.loc[0, "ecosystem_primary"] == "Wetland Ecosystems",
           str(d4b.loc[0, "ecosystem_primary"]))

    # ---------- 3) 纯文本 + markdown 代码块：解析必须稳健 ----------
    STATE.mode = "prose"
    code, out = run([sys.executable, str(BASE / "step4.ecosystem_classification.py"),
                     "--input", str(raw), "--force"], env)
    ok("模型返回 markdown 包裹的 JSON 时仍可解析",
       code == 0 and pd.read_excel(step4).loc[0, "ecosystem_primary"] == "Wetland Ecosystems")

    # ---------- 4) 断点续跑：第二次运行不应重复调用 ----------
    STATE.requests.clear()
    code, out = run([sys.executable, str(BASE / "step4.ecosystem_classification.py"),
                     "--input", str(raw)], env)
    ok("已完成行不重复调用模型（断点续跑不重复计费）", len(STATE.requests) == 0,
       f"第二次运行发出 {len(STATE.requests)} 次请求")

    # ---------- 5) 并发一致性 ----------
    STATE.mode = "json_schema"
    STATE.requests.clear()
    code, out = run([sys.executable, str(BASE / "step4.ecosystem_classification.py"),
                     "--input", str(raw), "--force", "--workers", "3"], env)
    ok("--workers 3 并发运行成功", code == 0)
    if code == 0:
        d4c = pd.read_excel(step4)
        ok("并发下结果与行不错位（row0=mangrove -> Wetland）",
           d4c.loc[0, "ecosystem_primary"] == "Wetland Ecosystems"
           and d4c.loc[2, "ecosystem_primary"] == "Wetland Ecosystems",
           f"{d4c['ecosystem_primary'].tolist()}")

    # ---------- 6) 401 鉴权失败的行为 ----------
    STATE.requests.clear()
    env_bad = dict(env)
    env_bad["OPENAI_API_KEY"] = ""      # 清空 Key
    env_bad["DEEPSEEK_API_KEY"] = ""
    code, out = run([sys.executable, str(BASE / "step4.ecosystem_classification.py"),
                     "--input", str(raw), "--force"], env_bad)
    ok("缺少 API Key 时明确报错退出（不静默产生空数据）", code != 0 and "API Key" in out,
       out.strip().splitlines()[-1] if out.strip() else "")

    # ---------- 7) run_manifest / checkpoint ----------
    manifest = BASE / "run_manifest.csv"
    if manifest.exists():
        m = pd.read_csv(manifest)
        ok("run_manifest.csv 记录了 model / temperature / prompt_version",
           {"model", "temperature", "prompt_version"}.issubset(m.columns),
           f"{len(m)} 条运行记录")
        ok("manifest 中记录 temperature=0",
           bool((m["temperature"].dropna() == 0).any()))
    else:
        ok("run_manifest.csv 已生成", False, "未找到 run_manifest.csv")

    ckpts = list((tmp / "_ckpt").glob("*.csv")) if (tmp / "_ckpt").exists() else []
    ok("checkpoint 文件已生成（断点续跑依据）", len(ckpts) > 0, ", ".join(p.name for p in ckpts))

    server.shutdown()

    print("\n" + "=" * 72)
    if FAILS:
        print(f"mock 链路测试: {len(FAILS)} 项失败")
        for f in FAILS:
            print(f"  - {f}")
    else:
        print("mock 链路测试: 全部通过")
    print("=" * 72)

    if not args.keep:
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        print(f"临时目录保留: {tmp}")
    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
