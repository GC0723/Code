# -*- coding: utf-8 -*-
"""
脚本名：stepT2.integration_test.py
原文件名：无（本脚本为新增）

stepT2.integration_test.py —— 离线全链路集成测试（不调用 API）

用途：用“夹具（fixture）替代 LLM 输出”，验证从原始语料到距离几何的整条数据流：

    0_Relevance → 1_StudyArea → 3_LocationNorm → 4_Ecosystem → 5_ESV → 6_Orientation
                → 7_Geocode（离线词典）→ 8_Distance
    以及 stepFT3.validation_metrics.py（含 gold standard 与 ORIENTATION 的 PTR 上下界）

它验证的是：
    - 列名解析与向后兼容列（research_location_v2 / EST1 / EST2 / Loc_*）
    - 枚举归一化（模型输出带后缀 / 带中文 / 大小写不一致时仍能对齐）
    - 亚类-一级类配对校验（含 BUNDLED 特例）
    - 断点续跑与失败标记
    - 输出表结构、run_manifest.csv、checkpoint 文件
    - 地理编码缓存与距离列

用法：
    python stepT2.integration_test.py
    python stepT2.integration_test.py --keep     # 保留 _integration_tmp 便于人工检查
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
FAILS: list = []


def ok(name: str, cond: bool, detail: str = "") -> None:
    print(f"[{'OK  ' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    if not cond:
        FAILS.append(name)


def build_raw(path: Path) -> None:
    df = pd.DataFrame({
        "UT": [f"WOS:{i:05d}" for i in range(1, 13)],
        "Article Title": [
            "Economic valuation of mangrove ecosystem services in Guangdong, China",
            "Valuing climate regulation of Amazon forests",
            "Mapping ecosystem services of the Loess Plateau",
            "Total economic value of 12 ecosystem services in Japan",
            "Recreation value of urban green spaces in Beijing",
            "Willingness to pay for freshwater provision in Kenya",
            "Economic value of glacier meltwater services in the Tibetan Plateau",
            "Cultural ecosystem services of karst landscapes in Guizhou",
            "Economic valuation of polar ecosystem services in Antarctica",
            "Valuation of paddy field ecosystem services in Hunan Province",
            "Natural capital accounting for German forests",
            "Ecosystem service assessment of California rangelands without valuation",
        ],
        "Abstract": [
            "We estimate the total economic value of mangrove ecosystem services and demonstrate how the results "
            "inform coastal management planning and ecological compensation in Guangdong Province, China.",
            "This study values the climate regulation service of Amazon forests using a benefit transfer approach.",
            "We map and economically value soil retention and water purification of the Loess Plateau, China.",
            "We estimate the total economic value of 12 ecosystem services in a Japanese watershed.",
            "Using a travel cost model we value recreation in urban parks of Beijing, China, to support park planning.",
            "A contingent valuation survey estimates households' willingness to pay for freshwater provision in Kenya.",
            "We quantify the economic value of glacier meltwater related services on the Tibetan Plateau, China.",
            "This paper values cultural ecosystem services of karst landscapes in Guizhou Province, China.",
            "We estimate the economic value of polar ecosystem services in Antarctica using emergy analysis.",
            "Paddy field ecosystem services in Hunan Province, China are valued to guide agricultural policy.",
            "We compile natural capital accounts for German forests to support national environmental accounting.",
            "We assess ecosystem conditions of California rangelands using field surveys; no monetary valuation "
            "is performed.",
        ],
        "Addresses": [
            "[Author A] Sun Yat Sen Univ, Guangzhou, Peoples R China.",
            "[Author B] Univ Sao Paulo, Sao Paulo, Brazil. [Author C] Sun Yat Sen Univ, Guangzhou, Peoples R China.",
            "[Author D] Chinese Acad Sci, Beijing, Peoples R China.",
            "[Author E] Univ Tokyo, Tokyo, Japan.",
            "[Author F] Peking Univ, Beijing, Peoples R China.",
            "[Author G] Univ Nairobi, Nairobi, Kenya.",
            "[Author H] Lanzhou Univ, Lanzhou, Peoples R China.",
            "[Author I] Guizhou Univ, Guiyang, Peoples R China.",
            "[Author J] Univ Oslo, Oslo, Norway.",
            "[Author K] Hunan Agr Univ, Changsha, Peoples R China.",
            "[Author L] Univ Freiburg, Freiburg, Germany.",
            "[Author M] Univ Calif Berkeley, Berkeley, CA USA.",
        ],
        "Affiliations": [
            "Sun Yat Sen University, Guangzhou, China",
            "University of Sao Paulo, Brazil; Sun Yat Sen University, China",
            "Chinese Academy of Sciences, Beijing, China",
            "University of Tokyo, Japan",
            "Peking University, Beijing, China",
            "University of Nairobi, Kenya",
            "Lanzhou University, China",
            "Guizhou University, China",
            "University of Oslo, Norway",
            "Hunan Agricultural University, China",
            "University of Freiburg, Germany",
            "University of California, Berkeley, USA",
        ],
    })
    df.to_excel(path, index=False)


#: 夹具：模拟 4 个 LLM 步骤的输出，故意混入脏值以测试归一化
FIXTURES = {
    "relevance": [
        ("VALUATION_OR_ACCOUNTING", "high"), ("VALUATION_OR_ACCOUNTING", "high"),
        ("VALUATION_OR_ACCOUNTING", "medium"), ("VALUATION_OR_ACCOUNTING", "high"),
        ("VALUATION_OR_ACCOUNTING", "medium"), ("VALUATION_OR_ACCOUNTING", "medium"),
        ("VALUATION_OR_ACCOUNTING", "low"), ("VALUATION_OR_ACCOUNTING", "low"),
        ("VALUATION_OR_ACCOUNTING", "low"), ("VALUATION_OR_ACCOUNTING", "medium"),
        ("VALUATION_OR_ACCOUNTING", "medium"),
        ("ECOSYSTEM_ASSESSMENT_NO_VALUATION", "high"),
    ],
    "study_area": [
        ("CITY", "Guangzhou", ["China"], "high"),
        ("WATERSHED_BASIN", "Amazon Basin", ["Brazil"], "medium"),
        ("MOUNTAIN_REGION", "Loess Plateau", ["China"], "medium"),
        ("COUNTRY", "Japan", ["Japan"], "high"),
        ("CITY", "Beijing", ["China"], "high"),
        ("COUNTRY", "Kenya", ["Kenya"], "high"),
        ("MOUNTAIN_REGION", "Tibetan Plateau", ["China"], "medium"),
        ("PROVINCE_STATE", "Guizhou Province", ["China"], "medium"),
        ("CONTINENT", "Antarctica", [], "medium"),
        ("PROVINCE_STATE", "Hunan Province", ["China"], "high"),
        ("COUNTRY", "Germany", ["Germany"], "high"),
        ("PROVINCE_STATE", "California", ["United States"], "medium"),
    ],
    "ecosystem": [
        ("Wetland Ecosystems", "Mangroves"), ("Forest Ecosystems", "Tropical forests"),
        ("Dryland and Grassland Ecosystems", "Steppe"),
        ("Wetland Ecosystems", "Paddy fields"),           # 脏值：亚类不属于一级类 -> 应被校正
        ("Urban and Artificial Ecosystems", "Urban green spaces"),
        ("Aquatic Ecosystems", "Springs / groundwater"),
        ("Special and Other Ecosystems", "Glaciers"),
        ("Special and Other Ecosystems", "Karst ecosystems"),
        ("Special and Other Ecosystems", "Polar ecosystems"),
        ("Agricultural Ecosystems", "Paddy fields"),
        ("Forest Ecosystems", "Temperate forests"),
        ("Dryland and Grassland Ecosystems", "Semi-arid shrublands"),
    ],
    "esv_service": [
        ("REGULATING_SERVICES", "Climate regulation"),
        ("REGULATING_SERVICES", "Climate regulation"),
        ("REGULATING_SERVICES", "Erosion prevention & soil fertility maintenance"),
        ("BUNDLED_ECOSYSTEM_SERVICES", "Bundled ecosystem services"),
        ("CULTURAL_SERVICES", "Recreation & tourism"),
        ("PROVISIONING_SERVICES", "Freshwater"),
        ("PROVISIONING_SERVICES", "Freshwater"),
        ("CULTURAL_SERVICES", "Cultural heritage"),
        ("SUPPORTING_SERVICES", "Primary production"),
        ("PROVISIONING_SERVICES", "Food"),
        ("SUPPORTING_SERVICES", "Soil formation"),
        ("SUPPORTING_SERVICES", "Habitat provision"),
    ],
    "orientation": [
        ("PRACTICE_ORIENTED", "management"), ("THEORY_ORIENTED", "none"),
        ("THEORY_ORIENTED", "none"), ("THEORY_ORIENTED", "none"),
        ("PRACTICE_ORIENTED", "planning"), ("THEORY_ORIENTED", "none"),
        ("UNCERTAIN", "unclear"), ("THEORY_ORIENTED", "none"),
        ("THEORY_ORIENTED", "none"), ("PRACTICE_ORIENTED", "policy"),
        ("PRACTICE_ORIENTED", "accounting"), ("UNCERTAIN", "unclear"),
    ],
}


def inject_fixture(df: pd.DataFrame, stage: str, columns: dict) -> None:
    """把夹具写进对应列（模拟 LLM 已经跑完的结果）。"""
    values = FIXTURES[stage]
    for col, idx in columns.items():
        df[col] = [v[idx] if idx < len(v) else "" for v in values]
    if stage == "study_area":
        df["study_area_additional"] = ""
        df["study_area_evidence"] = "fixture"
        df["study_area_model"] = "fixture"
        df["study_area_prompt_version"] = "P2-study-area-v2.0"
        df["study_area_run_at"] = "fixture"
        df["research_location_v2"] = df["study_area_name"]
    if stage == "ecosystem":
        df["ecosystem_evidence"] = "fixture"
        df["ecosystem_confidence"] = "medium"
        df["ecosystem_pair_valid"] = True
        df["ecosystem_model"] = "fixture"
        df["ecosystem_prompt_version"] = "P3-ecosystem-v2.0"
        df["ecosystem_run_at"] = "fixture"
        df["Ecosystem primary classification"] = df["ecosystem_primary"]
        df["Ecosystem sub-classification"] = df["ecosystem_subtype"]
    if stage == "esv_service":
        df["service_evidence"] = "fixture"
        df["service_confidence"] = "medium"
        df["service_pair_valid"] = True
        df["service_bundled_flag"] = df["service_primary"] == "BUNDLED_ECOSYSTEM_SERVICES"
        df["service_model"] = "fixture"
        df["service_prompt_version"] = "P4-esv-service-v2.0"
        df["service_run_at"] = "fixture"
        df["EST1"] = df["service_primary"]
        df["EST2"] = df["service_subtype"]
    if stage == "orientation":
        df["orientation_evidence"] = "fixture"
        df["orientation_confidence"] = "medium"
        df["orientation_model"] = "fixture"
        df["orientation_prompt_version"] = "P5-orientation-v2.0"
        df["orientation_run_at"] = "fixture"
    if stage == "relevance":
        df["relevance_evidence"] = "fixture"
        df["relevance_model"] = "fixture"
        df["relevance_prompt_version"] = "P1-relevance-v2.0"
        df["relevance_run_at"] = "fixture"


def run(cmd: list, env: dict) -> tuple:
    import subprocess

    proc = subprocess.run(cmd, cwd=str(BASE), env=env, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=600)
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def main() -> None:
    ap = argparse.ArgumentParser(description="离线全链路集成测试")
    ap.add_argument("--keep", action="store_true", help="保留临时目录")
    args = ap.parse_args()

    tmp = BASE / "_integration_tmp"
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)

    raw = tmp / "raw_corpus.xlsx"
    build_raw(raw)

    env = os.environ.copy()
    env.update({
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUTF8": "1",
        "D1_WORK_DIR": str(tmp),
        "PATH_INPUT_CORPUS": str(raw),
        "PATH_STEP0_RELEVANCE": str(tmp / "0_Relevance_out.xlsx"),
        "PATH_STEP1_ABSTRACT": str(tmp / "1_abstract_out.xlsx"),
        "PATH_STEP2_AFFILIATION": str(tmp / "2_Affiliations_out.xlsx"),
        "PATH_STEP3_LOCATION": str(tmp / "3_Location_out.xlsx"),
        "PATH_STEP4_ECOSYSTEM": str(tmp / "4_Ecosystem_Type_out.xlsx"),
        "PATH_STEP5_ESV": str(tmp / "5_EST_out.xlsx"),
        "PATH_STEP6_ORIENTATION": str(tmp / "6_Orientation_out.xlsx"),
        "PATH_STEP7_GEOCODE": str(tmp / "7_Geocoded.xlsx"),
        "PATH_STEP8_DISTANCE": str(tmp / "8_Distance_out.xlsx"),
        "PATH_FULLTEXT_DIR": str(tmp / "fulltext"),
        "PATH_FULLTEXT_GOLD_XLSX": str(tmp / "FT_2_gold_standard.xlsx"),
        "PATH_METRICS_XLSX": str(tmp / "9_Validation_Metrics.xlsx"),
        "LLM_CHECKPOINT_FILE": str(tmp / "_ckpt" / "ckpt.xlsx"),
        "GEOCODER": "gazetteer",
        "GEOCODE_CACHE_FILE": str(tmp / "geocode_cache.csv"),
        "GEOCODE_GAZETTEER": str(tmp / "gazetteer_extra.csv"),
        "GEOCODE_OVERRIDES": str(tmp / "geocode_overrides.csv"),
    })

    print("=" * 72)
    print("全链路离线集成测试（fixture 代替 LLM；地理编码使用离线词典）")
    print("=" * 72)

    has_key = bool(os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("OPENAI_API_KEY"))

    # ---------- Step 0：相关性判定（fixture）→ 生成 ESV 子集数据库 ----------
    # 模拟真实 step0 的两份输出：
    #   0_Relevance_out.xlsx 全量（含 OUT_OF_SCOPE / 未货币化记录）—— 审计用
    #   0_Corpus_ESV.xlsx    仅 VALUATION_OR_ACCOUNTING            —— step1~step8 唯一输入
    from llm_utils import ESV_KEEP_CLASS, is_esv_corpus, require_esv_corpus

    df = pd.read_excel(raw)
    inject_fixture(df, "relevance", {"relevance_class": 0, "relevance_confidence": 1})
    step0 = tmp / "0_Relevance_out.xlsx"
    df.to_excel(step0, index=False)

    corpus = tmp / "0_Corpus_ESV.xlsx"
    sub = df[df["relevance_class"] == ESV_KEEP_CLASS].reset_index(drop=True)
    sub["esv_filter_pass"] = True
    sub["source_corpus_n"] = len(df)
    sub["esv_selection_rule"] = f"relevance_class == {ESV_KEEP_CLASS} (step0)"
    sub.to_excel(corpus, index=False)
    env["PATH_STEP0_CORPUS"] = str(corpus)
    env["PATH_STEP0_RELEVANCE"] = str(step0)

    ok("step0 生成 ESV 子集数据库，且被识别为合规输入库", is_esv_corpus(corpus))
    ok("全量审计文件（含非 ESV 记录）不会被误当作下游输入库", not is_esv_corpus(step0))
    try:
        require_esv_corpus(step0)
        ok("守卫应拒绝未过滤的全量语料", False, "未抛出异常")
    except SystemExit as exc:
        ok("守卫拒绝未过滤的全量语料并提示先跑 step0", "step0" in str(exc))

    # 真实脚本入口验证：step1 / step2 只接受 ESV 子集数据库
    code_ok, out_ok = run(
        [sys.executable, str(BASE / "step1.study_area_extraction.py"), "--input", str(corpus), "--dry-run"], env
    )
    ok("step1 接受 ESV 子集数据库（dry-run 通过）", code_ok == 0 and "[dry-run]" in out_ok,
       (out_ok.strip().splitlines() or [""])[-1])

    code_bad, out_bad = run(
        [sys.executable, str(BASE / "step2.affiliation_geolocation_llm.py"), "--input", str(step0), "--dry-run"], env
    )
    ok("step2 拒绝未经过滤的语料并给出修复指引", code_bad != 0 and "step0" in out_bad,
       (out_bad.strip().splitlines() or [""])[-1])

    # ---------- Step 1：研究区域（fixture）→ 触发真实列写入逻辑 ----------
    from llm_utils import (
        as_confidence,
        as_name_list,
        join_list,
        normalize_enum_value,
        split_wos_addresses,
    )
    from llm_prompts import P2_AREA_LEVELS, P3_PRIMARY_ENUM, P3_SUBTYPE_MAP, P4_PRIMARY_ENUM, P4_SUBTYPE_MAP

    rows = []
    for i in range(len(df)):
        t, name, countries, conf = FIXTURES["study_area"][i]
        rows.append({
            "study_area_type": normalize_enum_value(t, P2_AREA_LEVELS, "UNKNOWN"),
            "study_area_name": name,
            "study_area_country": join_list(as_name_list(countries)),
            "study_area_additional": "",
            "study_area_evidence": "fixture",
            "study_area_confidence": as_confidence(conf),
            "study_area_model": "fixture",
            "study_area_prompt_version": "P2-study-area-v2.0",
            "study_area_run_at": "fixture",
            "research_location_v2": name,
            "Loc_Lat": "",
            "Loc_Lon": "",
        })
    step1 = tmp / "1_abstract_out.xlsx"
    df1 = pd.concat([df, pd.DataFrame(rows)], axis=1)
    df1.to_excel(step1, index=False)
    ok("Step1 输出包含 study_area_name 列", "study_area_name" in df1.columns)

    # ---------- Step 3：研究区域标准化（真实脚本，force 重跑以归一化） ----------
    code, out = run([sys.executable, str(BASE / "step3.study_area_normalization.py"), "--input", str(step1), "--force"], env)
    step3 = tmp / "3_Location_out.xlsx"
    if has_key:
        ok("Step3 脚本执行成功", code == 0 and step3.exists(), out.strip().splitlines()[-1] if out.strip() else "")
    else:
        ok("Step3 无 Key 时明确报错而不静默继续", "API Key" in out,
           out.strip().splitlines()[-1] if out.strip() else "")

    # 无 API Key 时直接用归一化函数补齐 Step3，保证后续步骤可继续测试
    if not step3.exists() or "loc_geographic_level" not in pd.read_excel(step3).columns:
        d3 = pd.read_excel(step1)
        d3["loc_original_name"] = d3["study_area_name"]
        d3["loc_normalized_name"] = d3["study_area_name"]
        d3["loc_geographic_level"] = d3["study_area_type"]
        d3["loc_country"] = d3["study_area_country"]
        d3["loc_region"] = ""
        d3["loc_ambiguity_flag"] = False
        d3["loc_evidence"] = "fixture"
        d3["loc_confidence"] = "medium"
        d3["loc_model"] = "fixture"
        d3["loc_prompt_version"] = "P7-location-norm-v2.0"
        d3["loc_run_at"] = "fixture"
        d3["Loc_Country"] = d3["study_area_country"]
        d3["Loc_Region"] = ""
        d3["Loc_Lat"] = ""
        d3["Loc_Lon"] = ""
        d3["Loc_Confidence"] = "medium"
        d3.to_excel(step3, index=False)

    # ---------- Step 4：生态系统（用真实配对校验函数） ----------
    d4 = pd.read_excel(step3)
    prim, sub, pair_ok = [], [], []
    for i in range(len(d4)):
        p, s = FIXTURES["ecosystem"][i]
        p = normalize_enum_value(p, P3_PRIMARY_ENUM, "UNKNOWN")
        allowed = P3_SUBTYPE_MAP.get(p, ["UNKNOWN"])
        s = normalize_enum_value(s, allowed, "UNKNOWN")
        prim.append(p)
        sub.append(s)
        pair_ok.append(s in allowed)
    d4["ecosystem_primary"] = prim
    d4["ecosystem_subtype"] = sub
    d4["ecosystem_pair_valid"] = pair_ok
    d4["ecosystem_evidence"] = "fixture"
    d4["ecosystem_confidence"] = "medium"
    d4["ecosystem_model"] = "fixture"
    d4["ecosystem_prompt_version"] = "P3-ecosystem-v2.0"
    d4["ecosystem_run_at"] = "fixture"
    d4["Ecosystem primary classification"] = prim
    d4["Ecosystem sub-classification"] = sub
    step4 = tmp / "4_Ecosystem_Type_out.xlsx"
    d4.to_excel(step4, index=False)

    ok("Step4 脏亚类被安全处理（不合法配对 -> UNKNOWN，绝不硬猜）",
       (d4.loc[3, "ecosystem_subtype"] == "UNKNOWN")
       or (d4.loc[3, "ecosystem_subtype"] in P3_SUBTYPE_MAP[d4.loc[3, "ecosystem_primary"]]),
       f"输入 Wetland+Paddy fields -> {d4.loc[3, 'ecosystem_primary']} / {d4.loc[3, 'ecosystem_subtype']}")
    ok("Step4 全部记录的一级类-亚类配对合法",
       bool(all(s in P3_SUBTYPE_MAP[p] for p, s in zip(d4["ecosystem_primary"], d4["ecosystem_subtype"]))))
    specials = d4.loc[d4["ecosystem_primary"] == "Special and Other Ecosystems", "ecosystem_subtype"].tolist()
    ok("Special 组包含 Glaciers / Karst / Polar（论文 glacier/karst/polar 计数有依据）",
       {"Glaciers", "Karst ecosystems", "Polar ecosystems"}.issubset(set(specials)), str(specials))

    # ---------- Step 5：生态系统服务（含 BUNDLED） ----------
    d5 = pd.read_excel(step4)
    sp, ss, sp_ok, bundled = [], [], [], []
    for i in range(len(d5)):
        p, s = FIXTURES["esv_service"][i]
        p = normalize_enum_value(p, P4_PRIMARY_ENUM, "UNKNOWN")
        allowed = P4_SUBTYPE_MAP.get(p, ["UNKNOWN"])
        s = normalize_enum_value(s, allowed, "UNKNOWN")
        if p == "BUNDLED_ECOSYSTEM_SERVICES":
            s = "Bundled ecosystem services"
        sp.append(p)
        ss.append(s)
        sp_ok.append(s in allowed)
        bundled.append(p == "BUNDLED_ECOSYSTEM_SERVICES")
    d5["service_primary"] = sp
    d5["service_subtype"] = ss
    d5["service_pair_valid"] = sp_ok
    d5["service_bundled_flag"] = bundled
    d5["service_evidence"] = "fixture"
    d5["service_confidence"] = "medium"
    d5["service_model"] = "fixture"
    d5["service_prompt_version"] = "P4-esv-service-v2.0"
    d5["service_run_at"] = "fixture"
    d5["EST1"] = sp
    d5["EST2"] = ss
    step5 = tmp / "5_EST_out.xlsx"
    d5.to_excel(step5, index=False)
    ok("Step5 出现 BUNDLED_ECOSYSTEM_SERVICES 类别", "BUNDLED_ECOSYSTEM_SERVICES" in set(sp))

    # ---------- Step 6：理论/实践（真实脚本，--force 用 fixture 列覆盖） ----------
    d6 = pd.read_excel(step5)
    d6["orientation_primary"] = [v[0] for v in FIXTURES["orientation"]]
    d6["application_type"] = [v[1] for v in FIXTURES["orientation"]]
    d6["orientation_evidence"] = "fixture"
    d6["orientation_confidence"] = "medium"
    d6["orientation_model"] = "fixture"
    d6["orientation_prompt_version"] = "P5-orientation-v2.0"
    d6["orientation_run_at"] = "fixture"
    step6 = tmp / "6_Orientation_out.xlsx"
    d6.to_excel(step6, index=False)
    code, out = run([sys.executable, str(BASE / "step6.theory_practice_orientation.py"), "--input", str(step6)], env)
    if has_key:
        ok("Step6 PTR 上下界已输出（PTR_lower / PTR_upper）",
           ("PTR_lower" in out and "PTR_upper" in out), [l.strip() for l in out.splitlines() if "PTR_" in l][:2])
    else:
        # 无 Key 时不能调用 LLM：直接验证 PTR 上下界计算函数本身
        # 注意：脚本名带点号（step6.…）不能直接 import，需按文件路径加载模块
        import importlib.util

        spec = importlib.util.spec_from_file_location(
            "step6_orientation", str(BASE / "step6.theory_practice_orientation.py")
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.print_ptr_bounds(step6)
        ok("Step6 无 Key 时报错明确（不写坏数据）", "API Key" in out,
           out.strip().splitlines()[-1] if out.strip() else "")

    # ---------- Step 7：地理编码（离线词典 + 覆盖表） ----------
    # 覆盖表（geocode_overrides.csv）代表“人工核查后的坐标”，优先级最高；
    # 这里用它把测试语料固定在已知城市，从而让距离计算产生确定、可验证的结果。
    overrides = tmp / "geocode_overrides.csv"
    pd.DataFrame([
        {"name": "Guangzhou", "country": "China", "region": "Guangdong Province",
         "lat": 23.1291, "lon": 113.2644, "level": "city", "confidence": 0.95},
        {"name": "Tokyo", "country": "Japan", "region": "Tokyo Metropolis",
         "lat": 35.6762, "lon": 139.6503, "level": "city", "confidence": 0.95},
        {"name": "Nairobi", "country": "Kenya", "region": "Nairobi",
         "lat": -1.2921, "lon": 36.8219, "level": "city", "confidence": 0.95},
    ]).to_csv(overrides, index=False, encoding="utf-8-sig")

    # 让 fixture 的研究区域名落到已知城市（城市级 -> 距离更有意义；同城 -> 0 km）
    d6["study_area_name"] = ["Guangzhou", "Amazon Basin", "Loess Plateau", "Tokyo", "Beijing", "Nairobi",
                             "Tibetan Plateau", "Guiyang", "Antarctica", "Changsha", "Germany", "California"]
    d6["loc_normalized_name"] = d6["study_area_name"]
    d6["study_area_country"] = ["China", "Brazil", "China", "Japan", "China", "Kenya", "China", "China", "",
                                "China", "Germany", "United States"]
    # Step 2 runs in parallel; Step 7 must join its affil_* columns by paper ID.
    affiliation = d6[["UT"]].copy()
    affiliation["affil_normalized_location"] = ["Guangzhou", "Sao Paulo", "Beijing", "Tokyo", "Beijing", "Nairobi",
                                                "Lanzhou", "Guiyang", "Oslo", "Changsha", "Freiburg", "Berkeley"]
    affiliation["affil_country"] = ["China", "Brazil", "China", "Japan", "China", "Kenya",
                                    "China", "China", "Norway", "China", "Germany", "United States"]
    affiliation["affil_region"] = ""
    affiliation_path = tmp / "2_Affiliations_out.xlsx"
    affiliation.to_excel(affiliation_path, index=False)
    d6["year"] = 2020
    d6.to_excel(step6, index=False)

    code, out = run([sys.executable, str(BASE / "step7.gis_geocoding.py"), "--input", str(step6),
                     "--affiliation-input", str(affiliation_path), "--provider", "gazetteer"], env)
    step7 = tmp / "7_Geocoded.xlsx"
    ok("Step7 地理编码脚本执行成功", code == 0 and step7.exists(), out.strip().splitlines()[-1] if out.strip() else "")
    if step7.exists():
        g = pd.read_excel(step7)
        n_geo = int(g["geo_study_lat"].notna().sum())
        ok("Step7 存在 geo_*_source 列（坐标可追溯）", "geo_study_source" in g.columns)
        ok("Step7 按 UT 合并 Step 2 机构结果", "affil_normalized_location" in g.columns and g["affil_normalized_location"].notna().all())
        ok("Step7 离线词典/覆盖表命中记录数 > 0", n_geo > 0, f"{n_geo}/{len(g)}")
        ok("Step7 坐标与来源成对（无来源不写坐标）",
           bool(((g["geo_study_lat"].notna()) == (g["geo_study_source"] != "none")).all()))
        ok("Step7 覆盖表优先于内置词典（人工修正生效）",
           "override" in set(g["geo_study_source"].dropna().astype(str)), 
           str(g["geo_study_source"].value_counts().to_dict()))

        # ---------- Step 8：距离 ----------
        code, out = run([sys.executable, str(BASE / "step8.author_studyarea_distance.py"), "--input", str(step7)], env)
        step8 = tmp / "8_Distance_out.xlsx"
        ok("Step8 距离脚本执行成功", code == 0 and step8.exists())
        if step8.exists():
            dist = pd.read_excel(step8)
            ok("Step8 生成距离列与有效性标记",
               {"study_author_distance_km", "distance_valid_flag", "cross_country_flag",
                "study_author_distance_log"}.issubset(dist.columns))
            valid = dist["study_author_distance_km"].dropna()
            ok("Step8 至少计算出一条有效距离", len(valid) > 0, f"{len(valid)} 条")
            ok("Step8 距离非负", bool((valid >= 0).all()))
            print("      距离示例: " + ", ".join(f"{v:.1f} km" for v in valid.head(5)))

            # ---------- validate_outputs：构造 gold standard 并计算指标 ----------
            gold = dist[["UT"]].copy()
            gold["gold_relevance"] = dist["relevance_class"]
            gold["gold_study_area_type"] = dist["study_area_type"]
            gold["gold_ecosystem_primary"] = dist["ecosystem_primary"]
            gold["gold_service_primary"] = dist["service_primary"]
            # 故意引入 2 处不一致，检验指标能被算出来（而不是全 1）
            gold.loc[2, "gold_ecosystem_primary"] = "Forest Ecosystems"
            gold.loc[5, "gold_orientation" if "gold_orientation" in gold else "gold_service_primary"] = \
                gold.loc[5, "gold_service_primary"]
            gold["gold_orientation"] = dist["orientation_primary"]
            gold.loc[0, "gold_orientation"] = "THEORY_ORIENTED"
            gold_path = tmp / "FT_2_gold_standard.xlsx"
            gold.to_excel(gold_path, index=False)

            code, out = run([sys.executable, str(BASE / "stepFT3.validation_metrics.py"), "--pred", str(step8),
                             "--gold", str(gold_path), "--id-col", "UT", "--bootstrap", "200"], env)
            metrics_path = tmp / "9_Validation_Metrics.xlsx"
            ok("validate_outputs 执行成功", code == 0 and metrics_path.exists(),
               out.strip().splitlines()[-1] if out.strip() else "")
            if metrics_path.exists():
                m = pd.read_excel(metrics_path, sheet_name="metrics")
                agg = m[m["level"] == "aggregate"]
                ok("指标表包含各核心变量（ECOSYSTEM_PRIMARY / ORIENTATION）",
                   {"ECOSYSTEM_PRIMARY", "ORIENTATION"}.issubset(set(agg["variable"])),
                   ", ".join(agg["variable"].tolist()))
                ori = agg[agg["variable"] == "ORIENTATION"]
                if len(ori):
                    kappa = ori.iloc[0]["cohens_kappa"]
                    ok("ORIENTATION 的 kappa 已计算", pd.notna(kappa), f"kappa={kappa}")
                ptr = m[m["level"] == "ptr"]
                ok("指标表包含 PTR 上下界行", len(ptr) == 2,
                   ", ".join(ptr["label"].tolist()) if len(ptr) else "缺失")
                cm_sheets = [s for s in pd.ExcelFile(metrics_path).sheet_names if s.startswith("cm_")]
                ok("指标表包含混淆矩阵 sheet", len(cm_sheets) > 0, ", ".join(cm_sheets))

    # ---------- make_fulltext_sample（抽样表生成） ----------
    code, out = run([sys.executable, str(BASE / "stepFT1.fulltext_sample_builder.py"), "--input", str(step6), "--n", "8",
                     "--blind", "--seed", "7"], env)
    sample = tmp / "FT_1_sample_for_review.xlsx"
    blind = tmp / "FT_1_sample_for_review_BLIND.xlsx"
    ok("make_fulltext_sample 生成盲标表与密钥表", blind.exists() and (tmp / "FT_1_sample_for_review_KEY.xlsx").exists(),
       out.strip().splitlines()[-1] if out.strip() else "")
    if blind.exists():
        b = pd.read_excel(blind)
        ok("盲标表不含自动结果列（避免锚定）", not any(c.startswith("auto_") for c in b.columns))
        ok("盲标表含 gold_* 待填列", any(c.startswith("gold_") for c in b.columns))

    # ---------- 审计文件 ----------
    manifest = BASE / "run_manifest.csv"
    if manifest.exists():
        ok("run_manifest.csv 已生成（可复现审计）", True, f"{len(pd.read_csv(manifest))} 条记录")
    else:
        print("[INFO] 本次测试未触发 run_manifest（Step3/6 未产生 API 调用）")

    print("\n" + "=" * 72)
    if FAILS:
        print(f"集成测试: {len(FAILS)} 项失败")
        for f in FAILS:
            print(f"  - {f}")
    else:
        print("集成测试: 全部通过")
    print("=" * 72)

    if not args.keep:
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        print(f"临时目录保留: {tmp}")

    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
