# -*- coding: utf-8 -*-
"""
脚本名：stepT3.smoke_test.py
原文件名：无（本脚本为新增）

stepT3.smoke_test.py —— 离线自检（不联网、不消耗 API 额度）

一次性验证整套脚本是否可运行、提示词是否合法、JSON Schema 是否可用、
以及“干跑（dry-run）”链路是否通畅。请在任何一次正式重跑之前先执行本脚本。

检查项
------
 1. 依赖包版本（pandas / requests / openpyxl / tqdm / numpy；可选 sklearn / pyproj / geopy / PyMuPDF）
 2. run 配置（provider / model / temperature / JSON Schema 开关 / 路径）
 3. 8 套提示词的版本、SHA1 指纹、Schema 完整性、枚举配对
 4. 各脚本 --dry-run（在临时生成的样例 Excel 上运行，不需要真实数据）
 5. 全文 PDF 文本抽取后端可用性
 6. 指标计算函数自测（含 kappa / bootstrap CI）

用法
----
    python stepT3.smoke_test.py
    python stepT3.smoke_test.py --keep    # 保留临时测试文件用于排查
"""

from __future__ import annotations

import argparse
import importlib
import os
import subprocess
import sys
import tempfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
FAILURES = []
WARNINGS = []


def check(name: str, ok: bool, detail: str = "", warn_only: bool = False) -> None:
    mark = "OK  " if ok else ("WARN" if warn_only else "FAIL")
    line = f"[{mark}] {name}"
    if detail:
        line += f" — {detail}"
    print(line)
    if not ok:
        (WARNINGS if warn_only else FAILURES).append(name)


def check_deps() -> None:
    print("\n=== 1. 依赖 ===")
    required = {"pandas": "pandas", "requests": "requests", "openpyxl": "openpyxl", "tqdm": "tqdm", "numpy": "numpy"}
    for mod, pip_name in required.items():
        try:
            m = importlib.import_module(mod)
            check(f"必需依赖 {mod}", True, f"v{getattr(m, '__version__', '?')}")
        except Exception as exc:
            check(f"必需依赖 {mod}", False, f"pip install {pip_name} ({exc})")
    for mod, why in (
        ("sklearn", "stepFT3.validation_metrics.py 的 P/R/F1/κ（缺失时使用内置实现）"),
        ("pyproj", "step8.author_studyarea_distance.py 的椭球精确距离（缺失时使用 Haversine）"),
        ("geopy", "step7.gis_geocoding.py 的在线地理编码（缺失时使用 HTTP 直连）"),
        ("fitz", "stepFT2.fulltext_adjudication.py 的 PDF 抽取（缺失时可用 pdftotext）"),
    ):
        try:
            importlib.import_module(mod)
            check(f"可选依赖 {mod}", True, why)
        except Exception:
            check(f"可选依赖 {mod}", False, why, warn_only=True)


def check_settings() -> None:
    print("\n=== 2. 运行配置 ===")
    from llm_utils import load_settings
    from llm_prompts import prompt_fingerprint, PROMPTS

    s = load_settings(reload=True)
    check("provider", s.provider in ("deepseek", "openai"), s.provider)
    check("model", bool(s.model), s.model)
    check("temperature == 0（可复现要求）", s.temperature == 0.0, f"temperature={s.temperature}",
          warn_only=(s.temperature != 0.0))
    check("API Key 未硬编码在代码中", True,
          "已从环境变量/.env 读取；" + ("已检测到 Key" if s.has_api_key else "未检测到 Key（正式运行前需配置）"))
    check("JSON Schema 约束已启用", s.use_json_schema, f"use_json_schema={s.use_json_schema}")
    print(f"      工作目录: {s.work_dir}")
    for key in ("PATH_STEP0_RELEVANCE", "PATH_STEP1_ABSTRACT", "PATH_STEP2_AFFILIATION", "PATH_STEP3_LOCATION",
                "PATH_STEP4_ECOSYSTEM", "PATH_STEP5_ESV", "PATH_STEP6_ORIENTATION", "PATH_STEP7_GEOCODE",
                "PATH_STEP8_DISTANCE", "PATH_FULLTEXT_GOLD_XLSX", "PATH_METRICS_XLSX"):
        print(f"      {key} = {s.paths.get(key)}")
    check("提示词注册表", len(PROMPTS) >= 8, f"{len(PROMPTS)} 套: {', '.join(sorted(PROMPTS))}")


def check_prompts() -> None:
    print("\n=== 3. 提示词与 JSON Schema ===")
    from llm_prompts import (
        P3_SUBTYPE_MAP,
        P4_SUBTYPE_MAP,
        PROMPTS,
        prompt_fingerprint,
    )

    for key, p in sorted(PROMPTS.items()):
        # 版本 + 指纹
        ok = bool(p["version"]) and len(prompt_fingerprint(key)) == 12
        check(f"prompt {key}", ok, f"{p['version']} sha1={prompt_fingerprint(key)}")

        # schema 与 prompt 中声明字段一致
        schema = p["schema"]
        declared = set(p["outputs"])
        in_schema = set(schema["properties"].keys())
        check(f"  {key}: schema 字段与输出列一致", declared.issubset(in_schema),
              f"outputs={sorted(declared)} schema={sorted(in_schema)}")

        # enum 字段都带 enum（除自由文本 evidence）
        for field_name, spec in schema["properties"].items():
            if field_name in ("evidence", "final_label", "final_subtype_or_level"):
                continue
            if spec.get("type") == "string" and "enum" not in spec and field_name not in ("country", "region",
                                                                                          "city",
                                                                                          "normalized_location",
                                                                                          "study_area_name",
                                                                                          "original_name",
                                                                                          "normalized_name"):
                WARNINGS.append(f"{key}.{field_name} 没有 enum 约束")

    # 亚类必须属于一级类
    bad = [s for p, subs in P3_SUBTYPE_MAP.items() for s in subs if not s]
    check("P3 亚类词表非空且配对完整", not bad, f"{sum(len(v) for v in P3_SUBTYPE_MAP.values())} 个亚类")
    check("P3 已移除 Agricultural 中的 Drylands（原 taxonomy 冲突）",
          "Drylands" not in P3_SUBTYPE_MAP.get("Agricultural Ecosystems", []),
          "干旱区统一归入 Dryland and Grassland Ecosystems")
    for special in ("Karst ecosystems", "Permafrost ecosystems", "Glaciers", "Polar ecosystems"):
        check(f"P3 Special 组包含 {special}", special in P3_SUBTYPE_MAP["Special and Other Ecosystems"])
    check("P4 支持 BUNDLED_ECOSYSTEM_SERVICES",
          "BUNDLED_ECOSYSTEM_SERVICES" in P4_SUBTYPE_MAP,
          "避免“必须二选一/唯一服务”造成的人为分类错误")

    # 旧的无效字段必须彻底消失
    from llm_prompts import PROMPTS as _P

    blob = " ".join(_P[k]["system"] + _P[k]["user"] for k in _P)
    check("提示词中不再出现 research_methods", "research_methods" not in blob)
    check("提示词中不再出现 research_conclusions", "research_conclusions" not in blob)


def check_schema_generation() -> None:
    print("\n=== 4. 结构化输出 schema ===")
    from llm_prompts import PROMPTS
    from llm_utils import relaxed_schema

    for key, field_name in (
        ("ecosystem", "ecosystem_primary"),
        ("esv_service", "service_primary"),
        ("orientation", "orientation"),
    ):
        schema = relaxed_schema(PROMPTS[key]["schema"])
        spec = schema["properties"].get(field_name, {})
        ok = schema.get("type") == "object" and "enum" in spec
        check(f"{key}: enum 约束保留在宽松 schema 中", ok, f"{field_name} -> {spec.get('enum', '')}")


def check_pipeline_dry_run(tmp: Path) -> None:
    print("\n=== 5. 脚本 dry-run（临时样例数据） ===")
    import pandas as pd

    sample = tmp / "sample_input.xlsx"
    df = pd.DataFrame({
        "UT": ["WOS:0001", "WOS:0002", "WOS:0003"],
        "Article Title": [
            "Economic valuation of mangrove ecosystem services in Southern China",
            "Mapping ecosystem services in the Amazon Basin",
            "A review of remote sensing methods",
        ],
        "Abstract": [
            "We estimate the total economic value of mangrove ecosystem services and show that the results "
            "inform coastal management planning and ecological compensation in Guangdong Province, China.",
            "This study maps five ecosystem services across the Amazon Basin using a spatial model; "
            "no monetary valuation is performed.",
            "We review remote sensing techniques for land cover classification.",
        ],
        "Addresses": ["[Author A] Sun Yat Sen Univ, Guangzhou, Peoples R China.",
                      "[Author B] Univ Sao Paulo, Sao Paulo, Brazil.",
                      "[Author C] Peking Univ, Beijing, Peoples R China."],
        "Affiliations": ["Sun Yat Sen University, Guangzhou, China",
                         "University of Sao Paulo, Brazil",
                         "Peking University, Beijing, China"],
    })
    df.to_excel(sample, index=False)

    # ESV 子集数据库（模拟 step0 的第二份输出）：
    # step1 / step2 的默认输入必须是它，因此样例里要带 relevance_class 列。
    esv_corpus = tmp / "0_Corpus_ESV.xlsx"
    esv_df = df.copy()
    esv_df["relevance_class"] = "VALUATION_OR_ACCOUNTING"
    esv_df["esv_filter_pass"] = True
    esv_df["source_corpus_n"] = len(df)
    esv_df["esv_selection_rule"] = "relevance_class == VALUATION_OR_ACCOUNTING (step0)"
    esv_df.to_excel(esv_corpus, index=False)

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["PATH_STEP0_RELEVANCE"] = str(tmp / "0_rel.xlsx")
    env["PATH_STEP0_CORPUS"] = str(esv_corpus)
    env["PATH_STEP1_ABSTRACT"] = str(tmp / "1_area.xlsx")
    env["PATH_STEP2_AFFILIATION"] = str(tmp / "2_affil.xlsx")
    env["PATH_STEP3_LOCATION"] = str(tmp / "3_loc.xlsx")
    env["PATH_STEP4_ECOSYSTEM"] = str(tmp / "4_eco.xlsx")
    env["PATH_STEP5_ESV"] = str(tmp / "5_esv.xlsx")
    env["PATH_STEP6_ORIENTATION"] = str(tmp / "6_ori.xlsx")
    env["PATH_STEP7_GEOCODE"] = str(tmp / "7_geo.xlsx")
    env["PATH_STEP8_DISTANCE"] = str(tmp / "8_dist.xlsx")
    env["PATH_METRICS_XLSX"] = str(tmp / "9_metrics.xlsx")
    env["D1_WORK_DIR"] = str(tmp)
    env["LLM_CHECKPOINT_FILE"] = str(tmp / "_ckpt" / "ckpt.xlsx")

    scripts = [
        ("step0.relevance_screening.py", ["--input", str(sample), "--dry-run"]),
        # step1 / step2 必须读 ESV 子集数据库（输入库守卫）
        ("step1.study_area_extraction.py", ["--input", str(esv_corpus), "--dry-run"]),
        ("step2.affiliation_geolocation_llm.py", ["--input", str(esv_corpus), "--dry-run"]),
        ("step4.ecosystem_classification.py", ["--input", str(sample), "--dry-run"]),
        ("step5.esv_service_classification.py", ["--input", str(sample), "--dry-run"]),
        ("step6.theory_practice_orientation.py", ["--input", str(sample), "--dry-run"]),
    ]
    for script, argv in scripts:
        path = BASE / script
        if not path.exists():
            check(f"dry-run {script}", False, "脚本缺失")
            continue
        proc = subprocess.run([sys.executable, str(path)] + argv, cwd=str(BASE), env=env,
                              capture_output=True, text=True, encoding="utf-8", errors="replace",
                              timeout=180)
        ok = proc.returncode == 0 and "[dry-run]" in (proc.stdout or "")
        detail = "" if ok else (proc.stdout or "")[-300:] + (proc.stderr or "")[-400:]
        check(f"dry-run {script}", ok, detail)

    # 输入库守卫：未经过 step0 的语料必须被拒绝（避免各步骤分母不一致）
    guard_script = BASE / "step1.study_area_extraction.py"
    if guard_script.exists():
        proc = subprocess.run([sys.executable, str(guard_script), "--input", str(sample), "--dry-run"],
                              cwd=str(BASE), env=env, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=180)
        combined = (proc.stdout or "") + (proc.stderr or "")
        check("输入库守卫拒绝未经 step0 过滤的语料",
              proc.returncode != 0 and "step0" in combined,
              "已被正确拦截" if proc.returncode != 0 else combined[-200:])

    # 研究区域标准化需要上游列，用样例直接造一个
    loc_input = tmp / "1_for_loc.xlsx"
    stage1 = pd.DataFrame({
        "UT": df["UT"],
        "Article Title": df["Article Title"],
        "study_area_name": ["Guangdong Province", "Amazon Basin", "UNKNOWN"],
        "study_area_country": ["China", "Brazil; Peru; Colombia", ""],
    })
    stage1.to_excel(loc_input, index=False)
    proc = subprocess.run(
        [sys.executable, str(BASE / "step3.study_area_normalization.py"), "--input", str(loc_input), "--dry-run"],
        cwd=str(BASE), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
    )
    check("dry-run step3.study_area_normalization.py",
          proc.returncode == 0 and "[dry-run]" in (proc.stdout or ""),
          (proc.stdout or "")[-200:] + (proc.stderr or "")[-400:])

    # 地理编码 / 距离 / 校验 三步的 dry-run 或参数检查
    geo_in = tmp / "3_for_geo.xlsx"
    pd.DataFrame({
        "UT": df["UT"],
        "loc_normalized_name": ["Guangzhou", "Amazon Basin", "UNKNOWN"],
        "loc_country": ["China", "Brazil", ""],
        "loc_region": ["", "", ""],
        "affil_normalized_location": ["Guangzhou, China", "Sao Paulo, Brazil", "Beijing, China"],
    }).to_excel(geo_in, index=False)
    proc = subprocess.run(
        [sys.executable, str(BASE / "step7.gis_geocoding.py"), "--input", str(geo_in), "--provider", "gazetteer",
         "--dry-run"],
        cwd=str(BASE), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
    )
    check("dry-run step7.gis_geocoding.py（仅本地词典，不联网）",
          proc.returncode == 0 and "[dry-run]" in (proc.stdout or ""),
          (proc.stdout or "")[-200:] + (proc.stderr or "")[-400:])

    proc = subprocess.run(
        [sys.executable, str(BASE / "step8.author_studyarea_distance.py"), "--input", str(geo_in), "--dry-run"],
        cwd=str(BASE), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
    )
    check("dry-run step8.author_studyarea_distance.py", proc.returncode == 0 and "[dry-run]" in (proc.stdout or ""),
          (proc.stdout or "")[-200:] + (proc.stderr or "")[-400:])

    # ---- 真实功能验证：地理编码（本地词典，离线）+ 距离计算 ----
    geo_out = tmp / "7_geo_real.xlsx"
    proc = subprocess.run(
        [sys.executable, str(BASE / "step7.gis_geocoding.py"), "--input", str(geo_in), "--provider", "gazetteer",
         "--output", str(geo_out)],
        cwd=str(BASE), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300,
    )
    ok = proc.returncode == 0 and geo_out.exists()
    detail = ""
    if ok:
        gdf = pd.read_excel(geo_out)
        n_geo = int(gdf["geo_study_lat"].notna().sum())
        ok = n_geo >= 2
        detail = f"研究区域已定位 {n_geo}/{len(gdf)}（本地词典，离线）"
    else:
        detail = (proc.stdout or "")[-200:] + (proc.stderr or "")[-400:]
    check("功能验证 step7.gis_geocoding.py（离线词典命中）", ok, detail)

    if geo_out.exists():
        dist_out = tmp / "8_dist_real.xlsx"
        proc = subprocess.run(
            [sys.executable, str(BASE / "step8.author_studyarea_distance.py"), "--input", str(geo_out), "--output", str(dist_out)],
            cwd=str(BASE), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300,
        )
        ok = proc.returncode == 0 and dist_out.exists()
        detail = ""
        if ok:
            ddf = pd.read_excel(dist_out)
            ok = "study_author_distance_km" in ddf.columns and ddf["study_author_distance_km"].notna().any()
            valid = ddf["study_author_distance_km"].dropna()
            detail = f"有效距离 {len(valid)}/{len(ddf)}，示例: {', '.join(f'{v:.0f} km' for v in valid.head(3))}"
        else:
            detail = (proc.stdout or "")[-200:] + (proc.stderr or "")[-400:]
        check("功能验证 step8.author_studyarea_distance.py（Haversine 距离）", ok, detail)


def _load_module_by_path(filename: str):
    """
    按文件路径加载脚本模块。

    本代码包的脚本采用 stepN.<name>.py 命名（点号），无法用普通 import 引入，
    因此统一用 importlib 从路径加载。
    """
    import importlib.util

    path = BASE / filename
    spec = importlib.util.spec_from_file_location(filename.replace(".", "_").replace("-", "_"), str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载模块: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def check_metrics_module() -> None:
    print("\n=== 6. 指标计算自测（无需数据） ===")
    try:
        import numpy as np  # noqa: F401

        metrics = _load_module_by_path("stepFT3.validation_metrics.py")
        bootstrap_ci = metrics.bootstrap_ci
        cohens_kappa = metrics.cohens_kappa
        confusion_matrix = metrics.confusion_matrix
        macro_scores = metrics.macro_scores
        prf_per_class = metrics.prf_per_class
    except Exception as exc:
        check("导入 stepFT3.validation_metrics.py", False, str(exc))
        return

    truth = ["PRACTICE_ORIENTED"] * 20 + ["THEORY_ORIENTED"] * 60 + ["UNCERTAIN"] * 20
    pred = ["PRACTICE_ORIENTED"] * 25 + ["THEORY_ORIENTED"] * 55 + ["UNCERTAIN"] * 20
    labels = sorted(set(truth) | set(pred))
    cm = confusion_matrix(truth, pred, labels)
    per_class = prf_per_class(cm, labels)
    p, r, f1 = macro_scores(per_class)
    kappa = cohens_kappa(truth, pred, labels)
    ci = bootstrap_ci(truth, pred, labels, n_boot=200)
    check("混淆矩阵维度正确", cm.shape == (3, 3), str(cm.tolist()))
    check("macro P/R/F1 落在 [0,1]", all(0 <= v <= 1 for v in (p, r, f1)), f"P={p:.3f} R={r:.3f} F1={f1:.3f}")
    check("Cohen's kappa 已计算", kappa == kappa, f"kappa={kappa:.3f}")
    check("bootstrap 95% CI 有效", ci["accuracy"][0] <= ci["accuracy"][1],
          f"accuracy CI=[{ci['accuracy'][0]:.3f}, {ci['accuracy'][1]:.3f}]")


def check_pdf() -> None:
    print("\n=== 7. 全文 PDF 文本抽取 ===")
    try:
        import pdf_text

        backends = pdf_text.available_backends()
        check("PDF 抽取后端", bool(backends),
              ", ".join(backends) if backends else
              "无可用后端：请安装 poppler(pdftotext) 或执行 pip install pymupdf",
              warn_only=True)
    except Exception as exc:
        check("导入 pdf_text", False, str(exc))


def main() -> None:
    ap = argparse.ArgumentParser(description="离线自检")
    ap.add_argument("--keep", action="store_true", help="保留临时测试文件")
    ap.add_argument("--tmpdir", default=None, help="临时测试目录（默认脚本目录下的 _smoke_tmp）")
    args = ap.parse_args()

    print("=" * 72)
    print("LLM 编码流水线 离线自检（不联网、不消耗 API 额度）")
    print("=" * 72)

    check_deps()
    check_settings()
    check_prompts()
    check_schema_generation()

    # 默认把临时文件放在脚本目录内（避免系统临时目录的写入权限问题）
    tmp = Path(args.tmpdir) if args.tmpdir else (BASE / "_smoke_tmp")
    if tmp.exists():
        import shutil as _shutil

        _shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True, exist_ok=True)
    try:
        check_pipeline_dry_run(tmp)
        if args.keep:
            print(f"\n临时文件保留在: {tmp}")
    finally:
        if not args.keep:
            import shutil as _shutil

            _shutil.rmtree(tmp, ignore_errors=True)

    check_metrics_module()
    check_pdf()

    print("\n" + "=" * 72)
    if FAILURES:
        print(f"自检结果: {len(FAILURES)} 项失败")
        for f in FAILURES:
            print(f"  - {f}")
    else:
        print("自检结果: 核心检查全部通过")
    if WARNINGS:
        print(f"警告 {len(WARNINGS)} 项（不阻塞运行）:")
        for w in WARNINGS:
            print(f"  - {w}")
    print("=" * 72)
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
